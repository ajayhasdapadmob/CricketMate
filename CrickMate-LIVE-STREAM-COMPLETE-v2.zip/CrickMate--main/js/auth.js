import {
    auth,
    db
} from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";


console.log(
    "🔐 CRICKMATE AUTH.JS STARTED"
);


/* =========================================================
   AUTH STATE
========================================================= */

export function watchAuth(callback) {

    return onAuthStateChanged(
        auth,
        (user) => {

            if (user) {

                console.log(
                    "👤 User logged in:",
                    user.email
                );

            } else {

                console.log(
                    "👤 No user logged in"
                );

            }

            if (typeof callback === "function") {

                callback(user);

            }

        }
    );

}


/* =========================================================
   LOGOUT
========================================================= */

export async function logoutUser() {

    try {

        await signOut(auth);

        console.log(
            "✅ User logged out"
        );

        window.location.href =
            "./index.html";

    } catch (error) {

        console.error(
            "❌ Logout error:",
            error
        );

    }

}