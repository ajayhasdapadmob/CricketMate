// =====================================================
// CRICKMATE - MATCH.JS
// MATCH DETAILS + SCORE + COMMENTARY
// =====================================================

import { db } from "./firebase.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE MATCH.JS STARTED");


// =====================================================
// URL
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


let matchId =
    params.get("matchId") ||
    params.get("match") ||
    localStorage.getItem("currentMatchId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

}


if (matchId) {

    matchId =
        matchId.trim();

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);

console.log(
    "🏏 Match ID:",
    matchId
);


// =====================================================
// ELEMENTS
// =====================================================

const loading =
    document.getElementById(
        "loading"
    );

const errorBox =
    document.getElementById(
        "error"
    );

const matchPage =
    document.getElementById(
        "matchPage"
    );

const backBtn =
    document.getElementById(
        "backBtn"
    );

const matchNumberEl =
    document.getElementById(
        "matchNumber"
    );

const team1El =
    document.getElementById(
        "team1"
    );

const team2El =
    document.getElementById(
        "team2"
    );

const scoreAEl =
    document.getElementById(
        "scoreA"
    );

const scoreBEl =
    document.getElementById(
        "scoreB"
    );

const statusEl =
    document.getElementById(
        "status"
    );

const winnerEl =
    document.getElementById(
        "winner"
    );

const tournamentEl =
    document.getElementById(
        "tournament"
    );

const dateEl =
    document.getElementById(
        "date"
    );

const timeEl =
    document.getElementById(
        "time"
    );

const venueEl =
    document.getElementById(
        "venue"
    );

const resultEl =
    document.getElementById(
        "result"
    );

const commentaryEl =
    document.getElementById(
        "commentary"
    );

const liveScoreBtn =
    document.getElementById(
        "liveScoreBtn"
    );

const commentaryBtn =
    document.getElementById(
        "commentaryBtn"
    );


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    backBtn.href =
        tournamentId
        ?
        `live.html?tournamentId=${encodeURIComponent(
            tournamentId
        )}`
        :
        "live.html";

}


// =====================================================
// ERROR
// =====================================================

function showError(
    text
) {

    console.error(
        "❌",
        text
    );


    if (loading) {

        loading.style.display =
            "none";

    }


    if (matchPage) {

        matchPage.style.display =
            "none";

    }


    if (errorBox) {

        errorBox.style.display =
            "block";

        errorBox.className =
            "error";

        errorBox.innerHTML =
            `❌ ${escapeHtml(text)}`;

    }

}


// =====================================================
// VALIDATE
// =====================================================

if (!tournamentId) {

    showError(
        "Tournament ID missing."
    );

}
else if (!matchId) {

    showError(
        "Match ID missing."
    );

}
else {

    loadMatch();

}


// =====================================================
// LOAD MATCH
// =====================================================

async function loadMatch() {

    console.log(
        "🔥 Loading match..."
    );


    try {

        const matchRef =
            doc(
                db,
                "tournaments",
                tournamentId,
                "matches",
                matchId
            );


        console.log(
            "📂 Firebase path:",
            `tournaments/${tournamentId}/matches/${matchId}`
        );


        const snap =
            await getDoc(
                matchRef
            );


        if (!snap.exists()) {

            showError(
                "Match not found in Firebase."
            );

            return;

        }


        const match =
            snap.data();


        console.log(
            "✅ MATCH FOUND:",
            match
        );


        displayMatch(
            match
        );


    }
    catch (error) {

        console.error(
            "❌ MATCH LOAD ERROR:",
            error
        );


        showError(
            error.message ||
            "Unable to load match."
        );

    }

}


// =====================================================
// DISPLAY MATCH
// =====================================================

function displayMatch(
    match
) {


    const team1 =
        match.team1Name ||
        match.teamA ||
        match.team1 ||
        "Team 1";


    const team2 =
        match.team2Name ||
        match.teamB ||
        match.team2 ||
        "Team 2";


    const scoreA =
        match.scoreA ||
        "0/0";


    const scoreB =
        match.scoreB ||
        "0/0";


    const status =
        match.status ||
        "Scheduled";


    const matchNumber =
        match.matchNumber ||
        match.matchNo ||
        match.number ||
        "Match";


    const tournamentName =
        match.tournamentName ||
        match.tournament ||
        "Tournament";


    const date =
        match.date ||
        match.matchDate ||
        "";


    const time =
        match.time ||
        match.matchTime ||
        "";


    const venue =
        match.venue ||
        "Not available";


    const result =
        match.result ||
        "";


    const winner =
        match.winner ||
        "";


    // =================================================
    // BASIC DATA
    // =================================================

    if (matchNumberEl) {

        matchNumberEl.textContent =
            `🏏 Match ${matchNumber}`;

    }


    if (team1El) {

        team1El.textContent =
            team1;

    }


    if (team2El) {

        team2El.textContent =
            team2;

    }


    if (scoreAEl) {

        scoreAEl.textContent =
            formatScore(
                scoreA
            );

    }


    if (scoreBEl) {

        scoreBEl.textContent =
            formatScore(
                scoreB
            );

    }


    if (statusEl) {

        statusEl.textContent =
            status;

    }


    if (tournamentEl) {

        tournamentEl.textContent =
            tournamentName;

    }


    if (dateEl) {

        dateEl.textContent =
            formatDate(
                date
            );

    }


    if (timeEl) {

        timeEl.textContent =
            time;

    }


    if (venueEl) {

        venueEl.textContent =
            venue;

    }


    if (resultEl) {

        resultEl.textContent =
            result ||
            "No result yet";

    }


    // =================================================
    // WINNER
    // =================================================

    if (
        winner &&
        winner !== "Tie"
    ) {

        if (winnerEl) {

            winnerEl.style.display =
                "block";

            winnerEl.textContent =
                `🏆 Winner: ${winner}`;

        }

    }
    else if (
        winner === "Tie"
    ) {

        if (winnerEl) {

            winnerEl.style.display =
                "block";

            winnerEl.textContent =
                "🤝 Match Tied";

        }

    }


    // =================================================
    // BUTTONS
    // =================================================

    const liveURL =
        `live-score.html?tournamentId=${
            encodeURIComponent(
                tournamentId
            )
        }&matchId=${
            encodeURIComponent(
                matchId
            )
        }`;


    const commentaryURL =
        `commentary.html?tournamentId=${
            encodeURIComponent(
                tournamentId
            )
        }&matchId=${
            encodeURIComponent(
                matchId
            )
        }`;


    if (liveScoreBtn) {

        liveScoreBtn.href =
            liveURL;

    }


    if (commentaryBtn) {

        commentaryBtn.href =
            commentaryURL;

    }


    // =================================================
    // COMMENTARY
    // =================================================

    renderCommentary(
        match
    );


    // =================================================
    // SHOW PAGE
    // =================================================

    if (loading) {

        loading.style.display =
            "none";

    }


    if (errorBox) {

        errorBox.style.display =
            "none";

    }


    if (matchPage) {

        matchPage.style.display =
            "block";

    }


    console.log(
        "✅ MATCH PAGE DISPLAYED"
    );

}


// =====================================================
// COMMENTARY
// =====================================================

function renderCommentary(
    match
) {

    if (!commentaryEl) {

        return;

    }


    let balls = [];


    if (
        Array.isArray(
            match.balls
        )
    ) {

        balls =
            [...match.balls];

    }


    if (!balls.length) {

        commentaryEl.innerHTML = `

            <div class="empty">

                📝 No commentary yet.

                <br>

                <small>
                    Ball-by-ball commentary will appear
                    when scoring starts.
                </small>

            </div>

        `;

        return;

    }


    // Newest first

    balls.reverse();


    commentaryEl.innerHTML =
        balls
            .map(
                ball => {

                    const number =
                        ball.number ||
                        "Ball";


                    const text =
                        ball.commentary ||
                        ball.comment ||
                        ball.description ||
                        "Ball played";


                    let runs = "";


                    if (
                        ball.runs !==
                        undefined
                    ) {

                        runs =
                            ` (${ball.runs} runs)`;

                    }


                    return `

                        <div class="commentary">

                            <div class="ball">

                                🏏 Ball
                                ${escapeHtml(number)}

                            </div>


                            <div class="comment">

                                ${escapeHtml(text)}

                                ${
                                    runs
                                    ?
                                    `<strong>
                                        ${escapeHtml(runs)}
                                     </strong>`
                                    :
                                    ""
                                }

                            </div>

                        </div>

                    `;

                }
            )
            .join("");

}


// =====================================================
// SCORE FORMAT
// =====================================================

function formatScore(
    value
) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "0/0";

    }


    if (
        typeof value ===
        "object"
    ) {

        const runs =
            value.runs ||
            0;


        const wickets =
            value.wickets ||
            0;


        return `${runs}/${wickets}`;

    }


    return String(
        value
    );

}


// =====================================================
// DATE
// =====================================================

function formatDate(
    value
) {

    if (!value) {

        return "-";

    }


    try {

        if (
            typeof value.toDate ===
            "function"
        ) {

            return value
                .toDate()
                .toLocaleDateString();

        }


        const date =
            new Date(value);


        if (
            !isNaN(
                date.getTime()
            )
        ) {

            return date
                .toLocaleDateString();

        }

    }
    catch (error) {

        console.warn(
            "Date format error:",
            error
        );

    }


    return String(
        value
    );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE MATCH.JS READY"
);