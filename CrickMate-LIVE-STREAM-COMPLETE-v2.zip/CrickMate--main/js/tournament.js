// =====================================================
// CRICKMATE - TOURNAMENT.JS
// =====================================================

import {
    db
} from "./firebase.js";

import {
    doc,
    getDoc,
    collection,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏆 CRICKMATE TOURNAMENT.JS STARTED");


// =====================================================
// GET TOURNAMENT ID
// =====================================================

const params =
    new URLSearchParams(window.location.search);


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("currentTournamentId") ||
    localStorage.getItem("tournamentId");


// =====================================================
// CLEAN + SAVE TOURNAMENT ID
// =====================================================

if (tournamentId) {

    tournamentId =
        tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// ELEMENTS
// =====================================================

const loading =
    document.getElementById("loading");


const content =
    document.getElementById("content");


// =====================================================
// CHECK ID
// =====================================================

if (!tournamentId) {

    if (loading) {

        loading.innerHTML = `

            <div class="error">

                <h3>
                    ⚠️ Tournament ID Missing
                </h3>

                <p>
                    Please open a tournament from Dashboard.
                </p>

            </div>

        `;

    }

    throw new Error(
        "Tournament ID missing"
    );

}


// =====================================================
// TOURNAMENT QUERY
// =====================================================

const tournamentQuery =
    `id=${encodeURIComponent(tournamentId)}`;


// =====================================================
// PAGE URLS
// =====================================================

const teamsURL =
    `./teams.html?tournamentId=${encodeURIComponent(tournamentId)}`;


const matchesURL =
    `./matches.html?tournamentId=${encodeURIComponent(tournamentId)}`;


const pointsURL =
    `./points.html?tournamentId=${encodeURIComponent(tournamentId)}`;


const statsURL =
    `./player-stats.html?tournamentId=${encodeURIComponent(tournamentId)}`;


const createMatchURL =
    `./create-match.html?tournamentId=${encodeURIComponent(tournamentId)}`;


const liveURL =
    `./live-score.html?tournamentId=${encodeURIComponent(tournamentId)}`;


// =====================================================
// SAFE SET LINK
// =====================================================

function setLink(
    id,
    url
) {

    const element =
        document.getElementById(id);

    if (element) {

        element.href =
            url;

    }

}


// =====================================================
// SET LINKS
// =====================================================

setLink(
    "headerBack",
    "./dashboard.html"
);


setLink(
    "overviewLink",
    `./tournament.html?${tournamentQuery}`
);


setLink(
    "teamsLink",
    teamsURL
);


setLink(
    "matchesLink",
    matchesURL
);


setLink(
    "pointsLink",
    pointsURL
);


setLink(
    "statsLink",
    statsURL
);


setLink(
    "addTeamLink",
    teamsURL
);


setLink(
    "createMatchLink",
    createMatchURL
);


setLink(
    "liveLink",
    liveURL
);


setLink(
    "quickPointsLink",
    pointsURL
);


// =====================================================
// DEBUG LINKS
// =====================================================

console.log(
    "👥 Teams URL:",
    teamsURL
);

console.log(
    "🏏 Matches URL:",
    matchesURL
);

console.log(
    "📊 Points URL:",
    pointsURL
);

console.log(
    "📈 Stats URL:",
    statsURL
);


// =====================================================
// LOAD TOURNAMENT
// =====================================================

async function loadTournament() {

    try {

        console.log(
            "🔥 Loading tournament:",
            tournamentId
        );


        const tournamentRef =
            doc(
                db,
                "tournaments",
                tournamentId
            );


        const tournamentSnap =
            await getDoc(
                tournamentRef
            );


        if (!tournamentSnap.exists()) {

            if (loading) {

                loading.innerHTML = `

                    <div class="error">

                        <h3>
                            ❌ Tournament Not Found
                        </h3>

                        <p>
                            This tournament does not exist.
                        </p>

                    </div>

                `;

            }

            return;

        }


        const tournament =
            tournamentSnap.data();


        console.log(
            "✅ Tournament:",
            tournament
        );


        // =================================================
        // BASIC DATA
        // =================================================

        setText(
            "tournamentName",
            tournament.tournamentName ||
            tournament.name ||
            "Unnamed Tournament"
        );


        setText(
            "description",
            tournament.description ||
            "Complete tournament information"
        );


        setText(
            "infoFormat",
            tournament.type ||
            tournament.format ||
            "-"
        );


        setText(
            "infoMatchType",
            tournament.matchType ||
            "T20"
        );


        setText(
            "infoOvers",
            tournament.overs
            ? `${tournament.overs} overs`
            : "0 overs"
        );


        setText(
            "infoStartDate",
            formatDate(
                tournament.startDate
            )
        );


        setText(
            "infoEndDate",
            formatDate(
                tournament.endDate
            )
        );


        setText(
            "startDateStat",
            formatDate(
                tournament.startDate
            )
        );


        setText(
            "infoVenue",
            tournament.venue ||
            "-"
        );


        setText(
            "infoCity",
            tournament.city ||
            "-"
        );


        setText(
            "infoOrganizer",
            tournament.organizer ||
            tournament.organizerName ||
            "-"
        );


        // =================================================
        // BADGES
        // =================================================

        const badges =
            document.getElementById(
                "badges"
            );


        if (badges) {

            badges.innerHTML = `

                <span class="badge">
                    🏆 ${
                        escapeHtml(
                            tournament.type ||
                            tournament.format ||
                            "Tournament"
                        )
                    }
                </span>

                <span class="badge">
                    🏏 ${
                        escapeHtml(
                            tournament.matchType ||
                            "T20"
                        )
                    }
                </span>

                <span class="badge">
                    👥
                    <span id="badgeTeams">
                        0
                    </span>
                    Teams
                </span>

                <span class="badge">
                    ⏱
                    ${
                        tournament.overs ||
                        0
                    }
                    Overs
                </span>

            `;

        }


        // =================================================
        // STATUS
        // =================================================

        const status =
            String(
                tournament.status ||
                "active"
            ).toLowerCase();


        const statusElement =
            document.getElementById(
                "status"
            );


        if (statusElement) {

            if (
                status ===
                "completed"
            ) {

                statusElement.textContent =
                    "🏁 COMPLETED";


                statusElement.style.background =
                    "#e2e8f0";


                statusElement.style.color =
                    "#475569";

            }
            else {

                statusElement.textContent =
                    "🔴 ACTIVE";

            }

        }


        // =================================================
        // SHOW CONTENT
        // =================================================

        if (loading) {

            loading.style.display =
                "none";

        }


        if (content) {

            content.style.display =
                "block";

        }


        // =================================================
        // REALTIME
        // =================================================

        listenTeams();

        listenMatches();

    }

    catch (error) {

        console.error(
            "❌ TOURNAMENT LOAD ERROR:",
            error
        );


        if (loading) {

            loading.innerHTML = `

                <div class="error">

                    <h3>
                        ❌ Unable to Load Tournament
                    </h3>

                    <p>
                        ${escapeHtml(
                            error.message ||
                            "Unknown error"
                        )}
                    </p>

                </div>

            `;

        }

    }

}


// =====================================================
// TEAMS COUNT
// =====================================================

function listenTeams() {

    console.log(
        "👥 Loading teams..."
    );


    const teamsRef =
        collection(
            db,
            "tournaments",
            tournamentId,
            "teams"
        );


    onSnapshot(

        teamsRef,

        (snapshot) => {

            const count =
                snapshot.size;


            console.log(
                "👥 TEAMS:",
                count
            );


            setText(
                "teamsCount",
                count
            );


            setText(
                "infoTeams",
                count
            );


            const badge =
                document.getElementById(
                    "badgeTeams"
                );


            if (badge) {

                badge.textContent =
                    count;

            }

        },

        (error) => {

            console.error(
                "❌ TEAM COUNT ERROR:",
                error
            );

        }

    );

}


// =====================================================
// MATCH COUNT
// =====================================================

function listenMatches() {

    console.log(
        "🏏 Loading matches..."
    );


    const matchesRef =
        collection(
            db,
            "tournaments",
            tournamentId,
            "matches"
        );


    onSnapshot(

        matchesRef,

        (snapshot) => {

            const count =
                snapshot.size;


            console.log(
                "🏏 MATCH COUNT:",
                count
            );


            setText(
                "matchesCount",
                count
            );


            // =================================================
            // LIVE COUNT
            // =================================================

            let liveCount =
                0;


            snapshot.forEach(
                (matchDoc) => {

                    const match =
                        matchDoc.data();


                    const status =
                        String(
                            match.status ||
                            ""
                        ).toLowerCase();


                    if (
                        status === "live" ||
                        status === "ongoing"
                    ) {

                        liveCount++;

                    }

                }
            );


            setText(
                "liveCount",
                liveCount
            );


            // =================================================
            // RECENT MATCHES
            // =================================================

            const matchesBox =
                document.getElementById(
                    "matchesBox"
                );


            if (!matchesBox) {

                return;

            }


            if (
                snapshot.empty
            ) {

                matchesBox.innerHTML = `

                    <div style="
                        text-align:center;
                        padding:20px;
                    ">

                        <div style="
                            font-size:40px;
                        ">
                            🏏
                        </div>

                        <h3>
                            No matches yet
                        </h3>

                        <p>
                            Matches will appear here
                            after they are created.
                        </p>

                    </div>

                `;

                return;

            }


            const matches =
                [];


            snapshot.forEach(
                (matchDoc) => {

                    matches.push({

                        id:
                            matchDoc.id,

                        ...matchDoc.data()

                    });

                }
            );


            // =================================================
            // SORT
            // =================================================

            matches.sort(
                (a, b) => {

                    const aTime =
                        getTimestamp(
                            a.createdAt
                        );


                    const bTime =
                        getTimestamp(
                            b.createdAt
                        );


                    return (
                        bTime -
                        aTime
                    );

                }
            );


            const recent =
                matches.slice(
                    0,
                    5
                );


            matchesBox.innerHTML =
                "";


            recent.forEach(
                (match) => {

                    const item =
                        document.createElement(
                            "div"
                        );


                    item.style.padding =
                        "12px";


                    item.style.borderBottom =
                        "1px solid #e2e8f0";


                    item.style.textAlign =
                        "left";


                    const team1 =
                        match.team1Name ||
                        match.teamA ||
                        "Team 1";


                    const team2 =
                        match.team2Name ||
                        match.teamB ||
                        "Team 2";


                    const score1 =
                        match.scoreA ||
                        "—";


                    const score2 =
                        match.scoreB ||
                        "—";


                    const result =
                        match.result ||
                        "";


                    const status =
                        match.status ||
                        "scheduled";


                    item.innerHTML = `

                        <strong>
                            🏏
                            ${escapeHtml(team1)}
                            vs
                            ${escapeHtml(team2)}
                        </strong>

                        <br>

                        <span style="
                            font-size:13px;
                            color:#475569;
                        ">
                            ${escapeHtml(score1)}
                            -
                            ${escapeHtml(score2)}
                        </span>

                        <br>

                        <small>
                            ${escapeHtml(status)}
                        </small>

                        ${
                            result
                            ?
                            `
                            <br>

                            <strong style="
                                color:#15803d;
                            ">
                                🏆
                                ${escapeHtml(result)}
                            </strong>
                            `
                            :
                            ""
                        }

                        <br>

                        <a
                            href="
                                ./live-score.html?tournamentId=${encodeURIComponent(tournamentId)}&matchId=${encodeURIComponent(match.id)}
                            "
                            style="
                                display:inline-block;
                                margin-top:8px;
                                text-decoration:none;
                                font-weight:bold;
                            "
                        >
                            📊 View Score
                        </a>

                    `;


                    matchesBox.appendChild(
                        item
                    );

                }
            );

        },

        (error) => {

            console.error(
                "❌ MATCH COUNT ERROR:",
                error
            );

        }

    );

}


// =====================================================
// SET TEXT SAFELY
// =====================================================

function setText(
    id,
    value
) {

    const element =
        document.getElementById(id);


    if (element) {

        element.textContent =
            value;

    }

}


// =====================================================
// TIMESTAMP
// =====================================================

function getTimestamp(
    value
) {

    if (!value) {

        return 0;

    }


    if (
        typeof value.seconds ===
        "number"
    ) {

        return value.seconds;

    }


    if (
        value instanceof Date
    ) {

        return value.getTime();

    }


    return 0;

}


// =====================================================
// FORMAT DATE
// =====================================================

function formatDate(
    value
) {

    if (!value) {

        return "-";

    }


    if (
        typeof value ===
        "string"
    ) {

        const date =
            new Date(
                value
            );


        if (
            isNaN(
                date.getTime()
            )
        ) {

            return value;

        }


        return date.toLocaleDateString(
            "en-IN",
            {
                day:
                    "2-digit",

                month:
                    "short",

                year:
                    "numeric"
            }
        );

    }


    if (
        value &&
        typeof value.toDate ===
        "function"
    ) {

        return value
            .toDate()
            .toLocaleDateString(
                "en-IN",
                {
                    day:
                        "2-digit",

                    month:
                        "short",

                    year:
                        "numeric"
                }
            );

    }


    return "-";

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(
        value
    )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// START
// =====================================================

loadTournament();


console.log(
    "✅ CRICKMATE TOURNAMENT READY"
);