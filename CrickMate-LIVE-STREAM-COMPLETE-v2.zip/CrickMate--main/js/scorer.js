// =====================================================
// CRICKMATE - SCORER.JS
// SCORER DASHBOARD
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs,
    doc,
    getDoc,
    query,
    orderBy
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE SCORER.JS STARTED");


// =====================================================
// URL PARAMETERS
// =====================================================

const params =
    new URLSearchParams(window.location.search);


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// ELEMENTS
// =====================================================

const loadingEl =
    document.getElementById("loading");

const messageEl =
    document.getElementById("message");

const resultsContainer =
    document.getElementById("resultsContainer");

const tournamentNameEl =
    document.getElementById("tournamentName");

const matchCountEl =
    document.getElementById("matchCount");

const backBtn =
    document.getElementById("backBtn");


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "success"
) {

    if (!messageEl) {
        console.log(text);
        return;
    }

    messageEl.textContent =
        text;

    messageEl.className =
        `message show ${type}`;

}


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            `admin-matches.html?tournamentId=${encodeURIComponent(
                tournamentId
            )}`;

    }
    else {

        backBtn.href =
            "index.html";

    }

}


// =====================================================
// VALIDATION
// =====================================================

if (!tournamentId) {

    console.error(
        "❌ Tournament ID missing"
    );

    showMessage(
        "Tournament ID missing.",
        "error"
    );

    if (loadingEl) {

        loadingEl.textContent =
            "❌ Tournament ID missing.";

    }

}
else {

    loadScorer();

}


// =====================================================
// LOAD SCORER
// =====================================================

async function loadScorer() {

    console.log(
        "🚀 SCORER PAGE STARTING..."
    );


    try {

        await loadTournament();

        await loadMatches();


        if (loadingEl) {

            loadingEl.style.display =
                "none";

        }


        console.log(
            "✅ CRICKMATE SCORER.JS READY"
        );

    }
    catch (error) {

        console.error(
            "❌ SCORER LOAD ERROR:",
            error
        );


        showMessage(
            error.message ||
            "Unable to load scorer.",
            "error"
        );


        if (loadingEl) {

            loadingEl.textContent =
                "❌ Unable to load scorer.";

        }

    }

}


// =====================================================
// LOAD TOURNAMENT
// =====================================================

async function loadTournament() {

    console.log(
        "🏆 Loading tournament..."
    );


    try {

        const tournamentRef =
            doc(
                db,
                "tournaments",
                tournamentId
            );


        const tournamentSnap =
            await getDoc(
                tournamentRef
            );


        if (!tournamentSnap.exists()) {

            console.warn(
                "⚠️ Tournament document not found"
            );

            if (tournamentNameEl) {

                tournamentNameEl.textContent =
                    "CrickMate Tournament";

            }

            return;

        }


        const tournament =
            tournamentSnap.data();


        console.log(
            "📂 TOURNAMENT DATA:",
            tournament
        );


        const tournamentName =
            tournament.name ||
            tournament.tournamentName ||
            tournament.title ||
            "CrickMate Tournament";


        if (tournamentNameEl) {

            tournamentNameEl.textContent =
                tournamentName;

        }

    }
    catch (error) {

        console.error(
            "❌ TOURNAMENT LOAD ERROR:",
            error
        );

    }

}


// =====================================================
// LOAD MATCHES
// =====================================================

async function loadMatches() {

    console.log(
        "🏏 Loading scorer matches..."
    );


    if (!resultsContainer) {

        console.error(
            "❌ resultsContainer not found"
        );

        return;

    }


    resultsContainer.innerHTML = `
        <div class="loading">
            🔄 Loading matches...
        </div>
    `;


    const matchesRef =
        collection(
            db,
            "tournaments",
            tournamentId,
            "matches"
        );


    console.log(
        "📂 Loading matches from:",
        `tournaments/${tournamentId}/matches`
    );


    let matchesSnap;


    try {

        const matchesQuery =
            query(
                matchesRef,
                orderBy(
                    "matchNumber",
                    "asc"
                )
            );


        matchesSnap =
            await getDocs(
                matchesQuery
            );

    }
    catch (error) {

        console.warn(
            "⚠️ Ordered query failed. Loading normally...",
            error
        );


        matchesSnap =
            await getDocs(
                matchesRef
            );

    }


    console.log(
        "🏏 MATCH COUNT:",
        matchesSnap.size
    );


    if (matchCountEl) {

        matchCountEl.textContent =
            `${matchesSnap.size} Match${
                matchesSnap.size === 1
                ? ""
                : "es"
            }`;

    }


    if (matchesSnap.empty) {

        resultsContainer.innerHTML = `
            <div class="empty">
                🏏 No matches found.
            </div>
        `;

        return;

    }


    const matches = [];


    matchesSnap.forEach(
        matchDoc => {

            matches.push({

                id:
                    matchDoc.id,

                ...matchDoc.data()

            });

        }
    );


    // =================================================
    // SORT MATCHES
    // =================================================

    matches.sort(
        (a, b) => {

            const numberA =
                Number(
                    a.matchNumber ||
                    a.matchNo ||
                    0
                );

            const numberB =
                Number(
                    b.matchNumber ||
                    b.matchNo ||
                    0
                );

            return numberA - numberB;

        }
    );


    resultsContainer.innerHTML = "";


    matches.forEach(
        (match, index) => {

            const card =
                createMatchCard(
                    match,
                    index
                );


            resultsContainer.appendChild(
                card
            );

        }
    );


    console.log(
        `✅ ${matches.length} MATCHES DISPLAYED`
    );

}


// =====================================================
// CREATE MATCH CARD
// =====================================================

function createMatchCard(
    match,
    index
) {

    const card =
        document.createElement(
            "div"
        );


    card.className =
        "match-card";


    const matchNumber =
        match.matchNumber ||
        match.matchNo ||
        index + 1;


    const team1 =
        match.team1Name ||
        match.teamA ||
        "Team 1";


    const team2 =
        match.team2Name ||
        match.teamB ||
        "Team 2";


    const scoreA =
        formatScore(
            match.scoreA
        );


    const scoreB =
        formatScore(
            match.scoreB
        );


    const status =
        match.status ||
        "Scheduled";


    const result =
        match.result ||
        "";


    const date =
        match.matchDate ||
        match.date ||
        "";


    const venue =
        match.venue ||
        "";


    const statusClass =
        getStatusClass(
            status
        );


    card.innerHTML = `

        <div class="match-top">

            <div>
                <strong>
                    Match ${escapeHtml(
                        String(matchNumber)
                    )}
                </strong>

                ${
                    date
                    ?
                    `<span class="match-date">
                        ${escapeHtml(
                            String(date)
                        )}
                    </span>`
                    :
                    ""
                }

            </div>

            <span class="
                status-badge
                ${statusClass}
            ">
                ${escapeHtml(
                    String(status)
                )}
            </span>

        </div>


        ${
            venue
            ?
            `<div class="venue">
                📍 ${escapeHtml(
                    String(venue)
                )}
            </div>`
            :
            ""
        }


        <div class="teams">

            <div class="team">

                <div class="team-name">
                    ${escapeHtml(
                        String(team1)
                    )}
                </div>

                <div class="score">
                    ${escapeHtml(
                        String(scoreA)
                    )}
                </div>

            </div>


            <div class="vs">
                VS
            </div>


            <div class="team">

                <div class="team-name">
                    ${escapeHtml(
                        String(team2)
                    )}
                </div>

                <div class="score">
                    ${escapeHtml(
                        String(scoreB)
                    )}
                </div>

            </div>

        </div>


        ${
            result
            ?
            `
            <div class="result">
                🏆 ${escapeHtml(
                    String(result)
                )}
            </div>
            `
            :
            ""
        }


        <div class="actions">

            <button
                class="live-btn"
                data-match-id="${escapeHtml(
                    match.id
                )}"
            >
                🏏 Live Scoring
            </button>


            <button
                class="scorecard-btn"
                data-match-id="${escapeHtml(
                    match.id
                )}"
            >
                📊 Scorecard
            </button>

        </div>

    `;


    // =================================================
    // LIVE SCORE BUTTON
    // =================================================

    const liveBtn =
        card.querySelector(
            ".live-btn"
        );


    if (liveBtn) {

        liveBtn.addEventListener(
            "click",
            () => {

                openLiveScore(
                    match.id
                );

            }
        );

    }


    // =================================================
    // SCORECARD BUTTON
    // =================================================

    const scorecardBtn =
        card.querySelector(
            ".scorecard-btn"
        );


    if (scorecardBtn) {

        scorecardBtn.addEventListener(
            "click",
            () => {

                openScorecard(
                    match.id
                );

            }
        );

    }


    return card;

}


// =====================================================
// FORMAT SCORE
// =====================================================

function formatScore(
    value
) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "0/0";

    }


    if (
        typeof value === "object"
    ) {

        const runs =
            Number(
                value.runs || 0
            );

        const wickets =
            Number(
                value.wickets || 0
            );

        return `${runs}/${wickets}`;

    }


    return String(value);

}


// =====================================================
// STATUS CLASS
// =====================================================

function getStatusClass(
    status
) {

    const value =
        String(
            status || ""
        ).toLowerCase();


    if (
        value.includes("complete") ||
        value.includes("finished")
    ) {

        return "completed";

    }


    if (
        value.includes("live") ||
        value.includes("progress")
    ) {

        return "live";

    }


    return "scheduled";

}


// =====================================================
// OPEN LIVE SCORE
// =====================================================

function openLiveScore(
    matchId
) {

    if (!tournamentId || !matchId) {

        return;

    }


    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentMatchId",
        matchId
    );


    window.location.href =
        `live-score.html?tournamentId=${encodeURIComponent(
            tournamentId
        )}&matchId=${encodeURIComponent(
            matchId
        )}`;

}


// =====================================================
// OPEN SCORECARD
// =====================================================

function openScorecard(
    matchId
) {

    if (!tournamentId || !matchId) {

        return;

    }


    localStorage.setItem(
        "currentMatchId",
        matchId
    );


    window.location.href =
        `scorecard.html?tournamentId=${encodeURIComponent(
            tournamentId
        )}&matchId=${encodeURIComponent(
            matchId
        )}`;

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}