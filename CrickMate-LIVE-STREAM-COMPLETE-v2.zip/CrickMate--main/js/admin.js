// =====================================================
// CRICKMATE - ADMIN.JS
// ADMIN DASHBOARD
// =====================================================

import {
    db,
    auth
} from "./firebase.js";

import {
    onAuthStateChanged,
    signInWithEmailAndPassword,
    signOut
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";


console.log(
    "🛠️ CRICKMATE ADMIN.JS STARTED"
);


// =====================================================
// ELEMENTS
// =====================================================

const firebaseStatus =
    document.getElementById(
        "firebaseStatus"
    );

const message =
    document.getElementById(
        "message"
    );


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "info"
) {

    if (!message) {
        return;
    }

    message.className =
        `message ${type}`;

    message.textContent =
        text;

}


// =====================================================
// FIREBASE CHECK
// =====================================================

async function checkFirebase() {

    console.log(
        "🔥 Checking Firebase..."
    );

    try {

        const tournamentsRef =
            collection(
                db,
                "tournaments"
            );


        const snapshot =
            await getDocs(
                tournamentsRef
            );


        console.log(
            "🏆 TOURNAMENT COUNT:",
            snapshot.size
        );


        if (firebaseStatus) {

            firebaseStatus.textContent =
                `✅ Firebase connected • ${snapshot.size} tournament(s) found`;

        }


        showMessage(
            "✅ CrickMate Admin Dashboard is ready.",
            "success"
        );

    }
    catch (error) {

        console.error(
            "❌ Firebase error:",
            error
        );


        if (firebaseStatus) {

            firebaseStatus.textContent =
                "❌ Firebase connection failed";

        }


        showMessage(
            error.message ||
            "Unable to connect to Firebase.",
            "error"
        );

    }

}


// =====================================================
// START
// =====================================================

checkFirebase();


console.log(
    "✅ CRICKMATE ADMIN.JS READY"
);