// =====================================================
// CRICKMATE - LIVE STREAM.JS
// FINAL WEBRTC BROADCASTER
// OFFER + ANSWER + ICE
// =====================================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    collection,
    doc,
    getDocs,
    setDoc,
    deleteDoc,
    onSnapshot,
    addDoc
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log(
    "🔥 CRICKMATE LIVE STREAM FINAL START"
);


// =====================================================
// ELEMENTS
// =====================================================

const matchSelect =
    document.getElementById("matchSelect");

const matchInfo =
    document.getElementById("matchInfo");

const teamA =
    document.getElementById("teamA");

const teamB =
    document.getElementById("teamB");

const cameraPreview =
    document.getElementById("cameraPreview");

const cameraOff =
    document.getElementById("cameraOff");

const streamStatus =
    document.getElementById("streamStatus");

const startLiveBtn =
    document.getElementById("startLiveBtn");

const stopLiveBtn =
    document.getElementById("stopLiveBtn");

const message =
    document.getElementById("message");

const watchLiveBtn =
    document.getElementById("watchLiveBtn");


// =====================================================
// TOURNAMENT
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId");


if (!tournamentId) {

    tournamentId =
        localStorage.getItem(
            "tournamentId"
        );

}


if (!tournamentId) {

    tournamentId =
        localStorage.getItem(
            "crickmateTournamentId"
        );

}


console.log(
    "🏆 TOURNAMENT:",
    tournamentId
);


// =====================================================
// GLOBALS
// =====================================================

let currentUser = null;

let currentMatchId = null;

let localStream = null;

let peerConnection = null;

let currentStreamRef = null;

let answerUnsubscribe = null;

let candidateUnsubscribe = null;

let pendingAnswerCandidates = [];

let remoteAnswerSet = false;


// =====================================================
// WEBRTC
// =====================================================

const rtcConfig = {

    iceServers: [

        {
            urls:
                "stun:stun.l.google.com:19302"
        },

        {
            urls:
                "stun:stun1.l.google.com:19302"
        }

    ]

};


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    error = false
) {

    if (!message) return;

    message.textContent =
        text;

    message.style.display =
        "block";

    message.classList.toggle(
        "error",
        error
    );

}


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(
    auth,
    async user => {

        currentUser =
            user;


        console.log(
            "🔐 USER:",
            user
        );


        if (!user) {

            showMessage(
                "Please login first. Live control requires login.",
                true
            );


            if (startLiveBtn) {

                startLiveBtn.disabled =
                    true;

            }


            return;

        }


        if (startLiveBtn) {

            startLiveBtn.disabled =
                false;

        }


        if (!tournamentId) {

            showMessage(
                "Tournament ID missing.",
                true
            );

            return;

        }


        await loadMatches();

    }
);


// =====================================================
// LOAD MATCHES
// =====================================================

async function loadMatches() {

    try {

        matchSelect.innerHTML =
            `
            <option value="">
                ⏳ Loading matches...
            </option>
            `;


        const matchesRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "matches"
            );


        const snapshot =
            await getDocs(
                matchesRef
            );


        matchSelect.innerHTML =
            `
            <option value="">
                Select Match
            </option>
            `;


        if (snapshot.empty) {

            matchSelect.innerHTML =
                `
                <option value="">
                    No matches found
                </option>
                `;

            return;

        }


        snapshot.forEach(
            matchDoc => {

                const data =
                    matchDoc.data();


                const a =
                    getTeamA(data);

                const b =
                    getTeamB(data);


                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    matchDoc.id;


                option.textContent =
                    `${a} VS ${b}`;


                option.dataset.teamA =
                    a;

                option.dataset.teamB =
                    b;


                matchSelect.appendChild(
                    option
                );

            }
        );


    } catch (error) {

        console.error(
            "❌ MATCH ERROR:",
            error
        );


        showMessage(
            "Unable to load matches.",
            true
        );

    }

}


// =====================================================
// MATCH SELECT
// =====================================================

matchSelect?.addEventListener(
    "change",
    () => {

        currentMatchId =
            matchSelect.value;


        const option =
            matchSelect.options[
                matchSelect.selectedIndex
            ];


        if (
            !currentMatchId ||
            !option
        ) {

            matchInfo.style.display =
                "none";

            return;

        }


        teamA.textContent =
            option.dataset.teamA ||
            "Team A";


        teamB.textContent =
            option.dataset.teamB ||
            "Team B";


        matchInfo.style.display =
            "block";

    }
);


// =====================================================
// START BUTTON
// =====================================================

startLiveBtn?.addEventListener(
    "click",
    startLive
);


// =====================================================
// START LIVE
// =====================================================

async function startLive() {

    console.log(
        "🔴 START LIVE"
    );


    if (!currentUser) {

        showMessage(
            "Please login first.",
            true
        );

        return;

    }


    if (!tournamentId) {

        showMessage(
            "Tournament ID missing.",
            true
        );

        return;

    }


    if (!currentMatchId) {

        showMessage(
            "Please select a match first.",
            true
        );

        return;

    }


    try {

        startLiveBtn.disabled =
            true;


        showMessage(
            "📷 Requesting camera permission..."
        );


        // =================================================
        // CAMERA
        // =================================================

        localStream =
            await navigator.mediaDevices
                .getUserMedia({

                    video: {

                        facingMode:
                            "environment",

                        width: {
                            ideal: 1280
                        },

                        height: {
                            ideal: 720
                        }

                    },

                    audio: true

                });


        console.log(
            "✅ CAMERA READY"
        );


        cameraPreview.srcObject =
            localStream;


        cameraPreview.muted =
            true;


        cameraPreview.playsInline =
            true;


        cameraPreview.autoplay =
            true;


        cameraPreview
            .play()
            .catch(
                () => {}
            );


        if (cameraOff) {

            cameraOff.style.display =
                "none";

        }


        streamStatus.innerHTML =
            "📷 Camera ready. Connecting...";


        // =================================================
        // STREAM DOCUMENT
        // =================================================

        currentStreamRef =
            doc(
                db,
                "tournaments",
                tournamentId,
                "matches",
                currentMatchId,
                "stream",
                "live"
            );


        // =================================================
        // CREATE PEER
        // =================================================

        peerConnection =
            new RTCPeerConnection(
                rtcConfig
            );


        // =================================================
        // ADD TRACKS
        // =================================================

        localStream
            .getTracks()
            .forEach(
                track => {

                    peerConnection.addTrack(
                        track,
                        localStream
                    );

                }
            );


        // =================================================
        // OFFER ICE
        // =================================================

        const offerCandidatesRef =
            collection(
                currentStreamRef,
                "offerCandidates"
            );


        peerConnection.onicecandidate =
            async event => {

                if (!event.candidate) {

                    return;

                }


                try {

                    await addDoc(
                        offerCandidatesRef,
                        event.candidate.toJSON()
                    );


                    console.log(
                        "🧊 OFFER ICE SAVED"
                    );

                } catch (error) {

                    console.error(
                        "❌ OFFER ICE ERROR:",
                        error
                    );

                }

            };


        // =================================================
        // CONNECTION STATE
        // =================================================

        peerConnection
            .onconnectionstatechange =
            () => {

                if (!peerConnection) {

                    return;

                }


                const state =
                    peerConnection
                        .connectionState;


                console.log(
                    "🔗 BROADCASTER STATE:",
                    state
                );


                if (
                    state === "connected"
                ) {

                    streamStatus.innerHTML =
                        `<span class="live">
                            🔴 LIVE • Viewer Connected
                         </span>`;

                }


                if (
                    state === "connecting"
                ) {

                    streamStatus.innerHTML =
                        "⏳ Connecting viewer...";

                }


                if (
                    state === "disconnected"
                ) {

                    streamStatus.innerHTML =
                        "⚠️ Viewer disconnected";

                }


                if (
                    state === "failed"
                ) {

                    streamStatus.innerHTML =
                        "❌ WebRTC connection failed";

                }

            };


        // =================================================
        // CREATE OFFER
        // =================================================

        const offer =
            await peerConnection
                .createOffer();


        await peerConnection
            .setLocalDescription(
                offer
            );


        console.log(
            "✅ LOCAL OFFER CREATED"
        );


        // =================================================
        // SAVE OFFER
        // =================================================

        await setDoc(
            currentStreamRef,
            {

                active:
                    true,

                tournamentId:
                    tournamentId,

                matchId:
                    currentMatchId,

                createdBy:
                    currentUser.uid,

                createdAt:
                    new Date(),

                offer: {

                    type:
                        offer.type,

                    sdp:
                        offer.sdp

                }

            }
        );


        console.log(
            "✅ OFFER SAVED"
        );


        // =================================================
        // ANSWER LISTENER
        // =================================================

        answerUnsubscribe =
            onSnapshot(
                currentStreamRef,

                async snapshot => {

                    if (!snapshot.exists()) {

                        return;

                    }


                    const data =
                        snapshot.data();


                    if (
                        !data.answer
                    ) {

                        return;

                    }


                    if (
                        remoteAnswerSet
                    ) {

                        return;

                    }


                    try {

                        await peerConnection
                            .setRemoteDescription(
                                new RTCSessionDescription(
                                    data.answer
                                )
                            );


                        remoteAnswerSet =
                            true;


                        console.log(
                            "✅ VIEWER ANSWER SET"
                        );


                        // =================================================
                        // ADD QUEUED ANSWER ICE
                        // =================================================

                        for (
                            const candidate
                            of pendingAnswerCandidates
                        ) {

                            try {

                                await peerConnection
                                    .addIceCandidate(
                                        candidate
                                    );

                            } catch (error) {

                                console.error(
                                    "❌ QUEUED ICE:",
                                    error
                                );

                            }

                        }


                        pendingAnswerCandidates =
                            [];


                        streamStatus.innerHTML =
                            `<span class="live">
                                🔴 LIVE • Connected
                             </span>`;


                    } catch (error) {

                        console.error(
                            "❌ ANSWER ERROR:",
                            error
                        );

                    }

                }
            );


        // =================================================
        // ANSWER ICE LISTENER
        // =================================================

        const answerCandidatesRef =
            collection(
                currentStreamRef,
                "answerCandidates"
            );


        candidateUnsubscribe =
            onSnapshot(
                answerCandidatesRef,

                async snapshot => {

                    for (
                        const change
                        of snapshot.docChanges()
                    ) {

                        if (
                            change.type !==
                            "added"
                        ) {

                            continue;

                        }


                        const data =
                            change.doc.data();


                        const candidate =
                            new RTCIceCandidate(
                                data
                            );


                        if (
                            remoteAnswerSet
                        ) {

                            try {

                                await peerConnection
                                    .addIceCandidate(
                                        candidate
                                    );


                                console.log(
                                    "🧊 ANSWER ICE ADDED"
                                );

                            } catch (error) {

                                console.error(
                                    "❌ ICE ERROR:",
                                    error
                                );

                            }

                        } else {

                            pendingAnswerCandidates
                                .push(
                                    candidate
                                );


                            console.log(
                                "🧊 ANSWER ICE QUEUED"
                            );

                        }

                    }

                }
            );


        // =================================================
        // UI
        // =================================================

        startLiveBtn.style.display =
            "none";


        if (stopLiveBtn) {

            stopLiveBtn.style.display =
                "block";

        }


        streamStatus.innerHTML =
            `<span class="live">
                🔴 LIVE • Waiting for viewer
             </span>`;


        showMessage(
            "🔴 Live started successfully!"
        );


        console.log(
            "🔥🔥 LIVE STREAM READY"
        );


    } catch (error) {

        console.error(
            "❌ START LIVE ERROR:",
            error
        );


        startLiveBtn.disabled =
            false;


        if (
            error.name ===
            "NotAllowedError"
        ) {

            showMessage(
                "Camera/Microphone permission denied.",
                true
            );

        } else {

            showMessage(
                "Unable to start live: " +
                error.message,
                true
            );

        }

    }

}


// =====================================================
// CRICKMATE - LIVE STREAM
// CAMERA + WEBRTC BROADCASTER
// FIREBASE AUTH + FIRESTORE
// =====================================================

import { auth, db } from "./firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    collection,
    doc,
    getDocs,
    setDoc,
    deleteDoc,
    onSnapshot,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

console.log("=================================");
console.log("🎥 CRICKMATE LIVE STREAM JS");
console.log("✅ JAVASCRIPT FILE LOADED");
console.log("=================================");


// =====================================================
// ELEMENTS
// =====================================================

const matchSelect =
    document.getElementById("matchSelect");

const matchInfo =
    document.getElementById("matchInfo");

const teamA =
    document.getElementById("teamA");

const teamB =
    document.getElementById("teamB");

const cameraPreview =
    document.getElementById("cameraPreview");

const cameraOff =
    document.getElementById("cameraOff");

const streamStatus =
    document.getElementById("streamStatus");

const startCameraBtn =
    document.getElementById("startCameraBtn");

const startLiveBtn =
    document.getElementById("startLiveBtn");

const stopLiveBtn =
    document.getElementById("stopLiveBtn");

const message =
    document.getElementById("message");

const watchLiveBtn =
    document.getElementById("watchLiveBtn");


// =====================================================
// GLOBAL
// =====================================================

let currentUser = null;
let tournamentId = null;
let currentMatchId = null;

let localStream = null;
let peerConnection = null;

let currentStreamRef = null;

let answerUnsubscribe = null;
let candidateUnsubscribe = null;

let remoteAnswerSet = false;
let pendingAnswerCandidates = [];


// =====================================================
// WEBRTC
// =====================================================

const rtcConfig = {

    iceServers: [

        {
            urls: "stun:stun.l.google.com:19302"
        },

        {
            urls: "stun:stun1.l.google.com:19302"
        }

    ]

};


// =====================================================
// TOURNAMENT ID
// =====================================================

function getTournamentId() {

    const params =
        new URLSearchParams(
            window.location.search
        );

    let id =
        params.get("tournamentId");

    if (!id) {

        id =
            localStorage.getItem(
                "tournamentId"
            );

    }

    if (!id) {

        id =
            localStorage.getItem(
                "crickmateTournamentId"
            );

    }

    if (!id) {

        id =
            localStorage.getItem(
                "selectedTournamentId"
            );

    }

    if (!id) {

        id =
            localStorage.getItem(
                "currentTournamentId"
            );

    }

    return id;

}


tournamentId =
    getTournamentId();

console.log(
    "🏆 TOURNAMENT ID:",
    tournamentId
);


// =====================================================
// MESSAGE
// =====================================================

function showMessage(text, error = false) {

    if (!message) return;

    message.textContent =
        text;

    message.style.display =
        "block";

    message.classList.toggle(
        "error",
        error
    );

}


// =====================================================
// STATUS
// =====================================================

function setStatus(text) {

    if (!streamStatus) return;

    streamStatus.textContent =
        text;

}


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(
    auth,
    async user => {

        console.log(
            "🔐 AUTH STATE:",
            user
                ? user.email
                : "NOT LOGGED IN"
        );

        currentUser =
            user;

        if (!user) {

            if (startCameraBtn) {
                startCameraBtn.disabled = true;
            }

            if (startLiveBtn) {
                startLiveBtn.disabled = true;
            }

            showMessage(
                "Please login first.",
                true
            );

            return;
        }


        console.log(
            "✅ USER LOGGED IN:",
            user.email
        );


        // -------------------------------------------------
        // GET TOURNAMENT AGAIN
        // -------------------------------------------------

        tournamentId =
            getTournamentId();


        console.log(
            "🏆 FINAL TOURNAMENT ID:",
            tournamentId
        );


        if (!tournamentId) {

            showMessage(
                "Tournament ID missing. URL me ?tournamentId=ID add kijiye.",
                true
            );

            setStatus(
                "Tournament ID missing."
            );

            return;
        }


        if (startCameraBtn) {
            startCameraBtn.disabled = false;
        }


        if (startLiveBtn) {
            startLiveBtn.disabled =
                !localStream;
        }


        await loadMatches();

    }
);


// =====================================================
// LOAD MATCHES
// =====================================================

async function loadMatches() {

    if (!tournamentId) {

        showMessage(
            "Tournament ID missing.",
            true
        );

        return;
    }


    try {

        setStatus(
            "⏳ Loading matches..."
        );


        const matchesRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "matches"
            );


        const snapshot =
            await getDocs(
                matchesRef
            );


        if (!matchSelect) return;


        matchSelect.innerHTML =
            `
            <option value="">
                Select Match
            </option>
            `;


        if (snapshot.empty) {

            matchSelect.innerHTML =
                `
                <option value="">
                    No matches found
                </option>
                `;

            showMessage(
                "No matches found.",
                true
            );

            return;
        }


        snapshot.forEach(
            matchDoc => {

                const data =
                    matchDoc.data();


                const a =
                    getTeamA(data);

                const b =
                    getTeamB(data);


                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    matchDoc.id;


                option.textContent =
                    `${a} VS ${b}`;


                option.dataset.teamA =
                    a;

                option.dataset.teamB =
                    b;


                matchSelect.appendChild(
                    option
                );

            }
        );


        console.log(
            "✅ MATCHES LOADED:",
            snapshot.size
        );


        setStatus(
            "Select a match."
        );

    }
    catch (error) {

        console.error(
            "❌ MATCH ERROR:",
            error
        );

        showMessage(
            "Unable to load matches: " +
            error.message,
            true
        );

    }

}


// =====================================================
// MATCH SELECT
// =====================================================

matchSelect?.addEventListener(
    "change",
    () => {

        currentMatchId =
            matchSelect.value;


        const option =
            matchSelect.options[
                matchSelect.selectedIndex
            ];


        if (
            !currentMatchId ||
            !option
        ) {

            if (matchInfo) {
                matchInfo.style.display =
                    "none";
            }

            return;
        }


        if (teamA) {

            teamA.textContent =
                option.dataset.teamA ||
                "Team A";

        }


        if (teamB) {

            teamB.textContent =
                option.dataset.teamB ||
                "Team B";

        }


        if (matchInfo) {

            matchInfo.style.display =
                "block";

        }


        console.log(
            "🏏 MATCH SELECTED:",
            currentMatchId
        );


        if (localStream && startLiveBtn) {

            startLiveBtn.disabled =
                false;

        }

    }
);


// =====================================================
// START CAMERA
// =====================================================

startCameraBtn?.addEventListener(
    "click",
    startCamera
);


async function startCamera() {

    console.log(
        "📷 START CAMERA CLICKED"
    );


    if (!currentUser) {

        showMessage(
            "Please login first.",
            true
        );

        return;
    }


    if (
        !navigator.mediaDevices ||
        !navigator.mediaDevices.getUserMedia
    ) {

        showMessage(
            "Camera API is not available. HTTPS required.",
            true
        );

        return;
    }


    try {

        startCameraBtn.disabled =
            true;


        setStatus(
            "📷 Requesting camera permission..."
        );


        // -------------------------------------------------
        // CAMERA + MICROPHONE
        // -------------------------------------------------

        localStream =
            await navigator.mediaDevices
                .getUserMedia({

                    video: {
                        facingMode: {
                            ideal: "environment"
                        },

                        width: {
                            ideal: 1280
                        },

                        height: {
                            ideal: 720
                        }
                    },

                    audio: true

                });


        console.log(
            "✅ CAMERA + MICROPHONE READY"
        );


        cameraPreview.srcObject =
            localStream;


        cameraPreview.muted =
            true;

        cameraPreview.playsInline =
            true;

        cameraPreview.autoplay =
            true;


        try {

            await cameraPreview.play();

        }
        catch (e) {

            console.log(
                "VIDEO PLAY:",
                e
            );

        }


        if (cameraOff) {

            cameraOff.style.display =
                "none";

        }


        if (startLiveBtn) {

            startLiveBtn.disabled =
                !currentMatchId;

        }


        setStatus(
            "📷 Camera is ready."
        );


        showMessage(
            "📷 Camera started successfully."
        );


    }
    catch (error) {

        console.error(
            "❌ CAMERA ERROR:",
            error
        );


        startCameraBtn.disabled =
            false;


        if (
            error.name ===
            "NotAllowedError"
        ) {

            showMessage(
                "Camera permission denied. Browser settings me Camera + Microphone Allow kijiye.",
                true
            );

        }
        else if (
            error.name ===
            "NotFoundError"
        ) {

            showMessage(
                "Camera ya microphone device nahi mila.",
                true
            );

        }
        else {

            showMessage(
                "Camera error: " +
                error.message,
                true
            );

        }

    }

}


// =====================================================
// START LIVE
// =====================================================

startLiveBtn?.addEventListener(
    "click",
    startLive
);


async function startLive() {

    console.log(
        "🔴 START LIVE CLICKED"
    );


    if (!currentUser) {

        showMessage(
            "Please login first.",
            true
        );

        return;
    }


    if (!tournamentId) {

        tournamentId =
            getTournamentId();

    }


    if (!tournamentId) {

        showMessage(
            "Tournament ID missing.",
            true
        );

        return;
    }


    if (!currentMatchId) {

        showMessage(
            "Please select a match first.",
            true
        );

        return;
    }


    if (!localStream) {

        showMessage(
            "Pehle START CAMERA dabaiye.",
            true
        );

        return;
    }


    try {

        startLiveBtn.disabled =
            true;


        setStatus(
            "🎥 Creating live stream..."
        );


        // -------------------------------------------------
        // STREAM REF
        // -------------------------------------------------

        currentStreamRef =
            doc(
                db,
                "tournaments",
                tournamentId,
                "matches",
                currentMatchId,
                "stream",
                "live"
            );


        // -------------------------------------------------
        // PEER
        // -------------------------------------------------

        peerConnection =
            new RTCPeerConnection(
                rtcConfig
            );


        remoteAnswerSet =
            false;

        pendingAnswerCandidates =
            [];


        // -------------------------------------------------
        // CAMERA TRACKS
        // -------------------------------------------------

        localStream
            .getTracks()
            .forEach(
                track => {

                    peerConnection.addTrack(
                        track,
                        localStream
                    );

                }
            );


        // -------------------------------------------------
        // OFFER ICE
        // -------------------------------------------------

        const offerCandidatesRef =
            collection(
                currentStreamRef,
                "offerCandidates"
            );


        peerConnection.onicecandidate =
            async event => {

                if (!event.candidate) {
                    return;
                }


                try {

                    await addDoc(
                        offerCandidatesRef,
                        event.candidate.toJSON()
                    );

                }
                catch (error) {

                    console.error(
                        "❌ OFFER ICE ERROR:",
                        error
                    );

                }

            };


        // -------------------------------------------------
        // CONNECTION
        // -------------------------------------------------

        peerConnection
            .onconnectionstatechange =
            () => {

                if (!peerConnection) return;


                const state =
                    peerConnection.connectionState;


                console.log(
                    "🔗 WEBRTC:",
                    state
                );


                if (
                    state ===
                    "connected"
                ) {

                    setStatus(
                        "🔴 LIVE • Viewer Connected"
                    );

                }


                if (
                    state ===
                    "connecting"
                ) {

                    setStatus(
                        "⏳ Connecting viewer..."
                    );

                }


                if (
                    state ===
                    "failed"
                ) {

                    setStatus(
                        "❌ WebRTC connection failed."
                    );

                }

            };


        // -------------------------------------------------
        // CREATE OFFER
        // -------------------------------------------------

        const offer =
            await peerConnection
                .createOffer();


        await peerConnection
            .setLocalDescription(
                offer
            );


        // -------------------------------------------------
        // SAVE STREAM
        // -------------------------------------------------

        await setDoc(
            currentStreamRef,
            {

                active: true,

                tournamentId:
                    tournamentId,

                matchId:
                    currentMatchId,

                createdBy:
                    currentUser.uid,

                createdByEmail:
                    currentUser.email,

                offer: {

                    type:
                        offer.type,

                    sdp:
                        offer.sdp

                },

                createdAt:
                    serverTimestamp()

            }
        );


        console.log(
            "✅ LIVE OFFER SAVED"
        );


 // -------------------------------------------------
        // ANSWER LISTENER
        // -------------------------------------------------

        answerUnsubscribe =
            onSnapshot(
                currentStreamRef,
                async snapshot => {

                    if (!snapshot.exists()) {
                        return;
                    }


                    const data =
                        snapshot.data();


                    if (
                        !data.answer ||
                        remoteAnswerSet
                    ) {

                        return;
                    }


                    try {

                        await peerConnection
                            .setRemoteDescription(
                                new RTCSessionDescription(
                                    data.answer
                                )
                            );


                        remoteAnswerSet =
                            true;


                        console.log(
                            "✅ VIEWER ANSWER RECEIVED"
                        );


                        for (
                            const candidate
                            of pendingAnswerCandidates
                        ) {

                            try {

                                await peerConnection
                                    .addIceCandidate(
                                        candidate
                                    );

                            }
                            catch (error) {

                                console.error(
                                    error
                                );

                            }

                        }


                        pendingAnswerCandidates =
                            [];


                    }
                    catch (error) {

                        console.error(
                            "❌ ANSWER ERROR:",
                            error
                        );

                    }

                }
            );


        // -------------------------------------------------
        // ANSWER ICE
        // -------------------------------------------------

        const answerCandidatesRef =
            collection(
                currentStreamRef,
                "answerCandidates"
            );


        candidateUnsubscribe =
            onSnapshot(
                answerCandidatesRef,
                async snapshot => {

                    for (
                        const change
                        of snapshot.docChanges()
                    ) {

                        if (
                            change.type !==
                            "added"
                        ) {
                            continue;
                        }


                        const candidate =
                            new RTCIceCandidate(
                                change.doc.data()
                            );


                        if (remoteAnswerSet) {

                            try {

                                await peerConnection
                                    .addIceCandidate(
                                        candidate
                                    );

                            }
                            catch (error) {

                                console.error(
                                    "❌ ICE ERROR:",
                                    error
                                );

                            }

                        }
                        else {

                            pendingAnswerCandidates
                                .push(candidate);

                        }

                    }

                }
            );


        // -------------------------------------------------
        // UI
        // -------------------------------------------------

        startLiveBtn.style.display =
            "none";


        if (stopLiveBtn) {

            stopLiveBtn.style.display =
                "block";

        }


        setStatus(
            "🔴 LIVE • Waiting for viewer"
        );


        showMessage(
            "🔴 Live started successfully!"
        );


    }
    catch (error) {

        console.error(
            "❌ START LIVE ERROR:",
            error
        );


        if (startLiveBtn) {

            startLiveBtn.disabled =
                false;

        }


        showMessage(
            "Unable to start live: " +
            error.message,
            true
        );

    }

}


// =====================================================
// STOP LIVE
// =====================================================

stopLiveBtn?.addEventListener(
    "click",
    stopLive
);


async function stopLive() {

    console.log(
        "⛔ STOP LIVE"
    );


    try {

        if (answerUnsubscribe) {

            answerUnsubscribe();
            answerUnsubscribe = null;

        }


        if (candidateUnsubscribe) {

            candidateUnsubscribe();
            candidateUnsubscribe = null;

        }


        if (localStream) {

            localStream
                .getTracks()
                .forEach(
                    track => track.stop()
                );

            localStream = null;

        }


        if (peerConnection) {

            peerConnection.close();
            peerConnection = null;

        }


        if (currentStreamRef) {

            try {

                await deleteDoc(
                    currentStreamRef
                );

            }
            catch (error) {

                console.error(
                    "❌ STREAM DELETE:",
                    error
                );

            }

            currentStreamRef = null;

        }


        remoteAnswerSet = false;
        pendingAnswerCandidates = [];


        if (cameraPreview) {

            cameraPreview.srcObject =
                null;

        }


        if (cameraOff) {

            cameraOff.style.display =
                "flex";

        }


        if (stopLiveBtn) {

            stopLiveBtn.style.display =
                "none";

        }


        if (startCameraBtn) {

            startCameraBtn.disabled =
                false;

        }


        if (startLiveBtn) {

            startLiveBtn.style.display =
                "block";

            startLiveBtn.disabled =
                true;

        }


        setStatus(
            "Camera is not started"
        );


        showMessage(
            "Live stopped."
        );


    }
    catch (error) {

        console.error(
            "❌ STOP ERROR:",
            error
        );

    }

}


// =====================================================
// OPEN WATCH LIVE
// =====================================================

watchLiveBtn?.addEventListener(
    "click",
    function(event) {

        event.preventDefault();

        console.log("👀 OPEN WATCH LIVE CLICKED");

        if (!tournamentId) {

            showMessage(
                "❌ Tournament ID missing.",
                true
            );

            return;
        }

        if (!selectedMatchId) {

            showMessage(
                "❌ Pehle match select kijiye.",
                true
            );

            return;
        }

        const watchUrl =
            "./watch-live.html" +
            "?tournamentId=" +
            encodeURIComponent(tournamentId) +
            "&matchId=" +
            encodeURIComponent(selectedMatchId);

        console.log(
            "👀 WATCH LIVE URL:",
            watchUrl
        );

        window.location.href =
            watchUrl;

    }
);


// =====================================================
// TEAM HELPERS
// =====================================================

function getTeamA(data) {

    return (
        data.teamAName ||
        data.teamA ||
        data.team1Name ||
        data.team1 ||
        data.homeTeamName ||
        data.homeTeam ||
        "Team A"
    );

}


function getTeamB(data) {

    return (
        data.teamBName ||
        data.teamB ||
        data.team2Name ||
        data.team2 ||
        data.awayTeamName ||
        data.awayTeam ||
        "Team B"
    );

}


// =====================================================
// PAGE EXIT
// =====================================================

window.addEventListener(
    "beforeunload",
    () => {

        if (localStream) {

            localStream
                .getTracks()
                .forEach(
                    track => track.stop()
                );

        }


        if (peerConnection) {

            peerConnection.close();

        }

    }
);


console.log(
    "🚀 CRICKMATE LIVE STREAM READY"
);