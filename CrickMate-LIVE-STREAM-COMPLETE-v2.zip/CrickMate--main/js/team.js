// =====================================================
// CRICKMATE - TEAM.JS
// TEAM DETAILS + PLAYERS + AUTOMATIC TEAM STATS
// =====================================================

import { db } from "./firebase.js";

import {
    doc,
    getDoc,
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("👤 CRICKMATE TEAM.JS STARTED");


// =====================================================
// URL PARAMETERS
// =====================================================

const params =
    new URLSearchParams(window.location.search);


// =====================================================
// GET TOURNAMENT ID
// =====================================================

let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


// =====================================================
// GET TEAM ID
// =====================================================

let teamId =
    params.get("teamId") ||
    localStorage.getItem("currentTeamId");


// =====================================================
// CLEAN IDs
// =====================================================

if (tournamentId) {

    tournamentId =
        tournamentId.trim();

}

if (teamId) {

    teamId =
        teamId.trim();

}


// =====================================================
// LOG
// =====================================================

console.log(
    "🏆 Tournament ID:",
    tournamentId
);

console.log(
    "👥 Team ID:",
    teamId
);


// =====================================================
// SAVE IDs
// =====================================================

if (tournamentId) {

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}

if (teamId) {

    localStorage.setItem(
        "currentTeamId",
        teamId
    );

}


// =====================================================
// CONTAINER
// =====================================================

const teamContainer =
    document.getElementById(
        "teamContainer"
    ) ||
    document.getElementById(
        "teamDetails"
    ) ||
    document.querySelector(
        ".team-details"
    );


// =====================================================
// ERROR
// =====================================================

function showError(message) {

    console.error(
        "❌",
        message
    );

    if (!teamContainer) {
        return;
    }

    teamContainer.innerHTML = `

        <div class="error-box">

            <div class="error-icon">
                ⚠️
            </div>

            <h2>
                Unable to Load Team
            </h2>

            <p>
                ${escapeHtml(message)}
            </p>

            <button
                id="backTeams"
                class="back-button"
            >
                ← Back to Teams
            </button>

        </div>

    `;


    document
        .getElementById("backTeams")
        ?.addEventListener(
            "click",
            () => {

                window.location.href =
                    `teams.html?tournamentId=${encodeURIComponent(tournamentId)}`;

            }
        );

}


// =====================================================
// VALIDATION
// =====================================================

if (!tournamentId) {

    showError(
        "Tournament ID missing."
    );

}
else if (!teamId) {

    showError(
        "Team ID missing. Please open this page from Teams."
    );

}
else {

    loadTeam();

}


// =====================================================
// LOAD TEAM
// =====================================================

async function loadTeam() {

    console.log(
        "🔥 Loading team..."
    );

    console.log(
        "📂 Team path:",
        `tournaments/${tournamentId}/teams/${teamId}`
    );


    try {

        // =================================================
        // TEAM DOCUMENT
        // =================================================

        const teamRef =
            doc(
                db,
                "tournaments",
                tournamentId,
                "teams",
                teamId
            );


        const teamSnap =
            await getDoc(
                teamRef
            );


        if (!teamSnap.exists()) {

            showError(
                "Team not found in Firebase."
            );

            return;

        }


        const team =
            teamSnap.data();


        console.log(
            "✅ Team loaded:",
            team
        );


        // =================================================
        // LOAD PLAYERS
        // =================================================

        const players =
            await loadAllPlayers(team);


        console.log(
            "👥 Players:",
            players.length
        );


        // =================================================
        // LOAD MATCH STATS
        // =================================================

        const stats =
            await calculateTeamStats(
                team
            );


        console.log(
            "📊 Team Stats:",
            stats
        );


        // =================================================
        // DISPLAY
        // =================================================

        displayTeam(
            team,
            players,
            stats
        );

    }
    catch (error) {

        console.error(
            "❌ Error loading team:",
            error
        );

        showError(
            error.message ||
            "Failed to load team."
        );

    }

}


// =====================================================
// LOAD ALL PLAYERS
// =====================================================

async function loadAllPlayers(team) {

    const players = [];

    const existingIds = new Set();


    // =================================================
    // METHOD 1
    // player1 → player15
    // =================================================

    for (
        let i = 1;
        i <= 15;
        i++
    ) {

        const value =
            team[`player${i}`];


        if (
            value !== undefined &&
            value !== null &&
            String(value).trim() !== ""
        ) {

            const name =
                String(value).trim();


            players.push({

                number:
                    players.length + 1,

                name:
                    name,

                role:
                    i === 1
                    ?
                    "Captain"
                    :
                    "Player"

            });

        }

    }


    // =================================================
    // METHOD 2
    // players ARRAY
    // =================================================

    if (
        Array.isArray(team.players)
    ) {

        team.players.forEach(
            (player) => {

                if (
                    player === null ||
                    player === undefined
                ) {

                    return;

                }


                let playerName = "";
                let role = "Player";


                if (
                    typeof player === "string"
                ) {

                    playerName =
                        player.trim();

                }
                else {

                    playerName =
                        player.playerName ||
                        player.name ||
                        player.fullName ||
                        player.player ||
                        "";

                    role =
                        player.role ||
                        player.playerRole ||
                        "Player";

                }


                playerName =
                    String(playerName).trim();


                if (
                    playerName &&
                    !existingIds.has(
                        playerName.toLowerCase()
                    )
                ) {

                    players.push({

                        number:
                            players.length + 1,

                        name:
                            playerName,

                        role:
                            role

                    });


                    existingIds.add(
                        playerName.toLowerCase()
                    );

                }

            }
        );

    }


    // =================================================
    // METHOD 3
    // PLAYERS SUBCOLLECTION
    //
    // tournaments/
    //   tournamentId/
    //     teams/
    //       teamId/
    //         players/
    // =================================================

    try {

        console.log(
            "🔥 Loading players subcollection..."
        );


        const playersRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "teams",
                teamId,
                "players"
            );


        const playersSnap =
            await getDocs(
                playersRef
            );


        console.log(
            "👤 PLAYER SUBCOLLECTION COUNT:",
            playersSnap.size
        );


        playersSnap.forEach(
            (playerDoc) => {

                const player =
                    playerDoc.data();


                console.log(
                    "👤 PLAYER:",
                    playerDoc.id,
                    player
                );


                const playerName =
                    player.playerName ||
                    player.name ||
                    player.fullName ||
                    player.player ||
                    player.playerFullName ||
                    "";


                if (!playerName) {

                    return;

                }


                const cleanName =
                    String(
                        playerName
                    ).trim();


                const alreadyExists =
                    players.some(
                        (p) =>
                            String(
                                p.name
                            )
                            .trim()
                            .toLowerCase() ===
                            cleanName.toLowerCase()
                    );


                if (
                    !alreadyExists
                ) {

                    players.push({

                        number:
                            players.length + 1,

                        name:
                            cleanName,

                        role:
                            player.role ||
                            player.playerRole ||
                            "Player",

                        playerId:
                            playerDoc.id

                    });

                }

            }
        );

    }
    catch (error) {

        console.warn(
            "⚠️ Players subcollection not available:",
            error.message
        );

    }


    // =================================================
    // REMOVE DUPLICATES
    // =================================================

    const uniquePlayers = [];
    const names = new Set();


    players.forEach(
        (player) => {

            const key =
                String(
                    player.name
                )
                .trim()
                .toLowerCase();


            if (
                !key ||
                names.has(key)
            ) {

                return;

            }


            names.add(key);


            uniquePlayers.push({

                number:
                    uniquePlayers.length + 1,

                name:
                    player.name,

                role:
                    player.role ||
                    "Player",

                playerId:
                    player.playerId ||
                    ""

            });

        }
    );


    return uniquePlayers;

}


// =====================================================
// CALCULATE TEAM STATS
// =====================================================

async function calculateTeamStats(team) {

    const stats = {

        matches: 0,

        wins: 0,

        losses: 0,

        draws: 0,

        points: 0,

        nrr: 0

    };


    try {

        const matchesRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "matches"
            );


        const matchesSnap =
            await getDocs(
                matchesRef
            );


        console.log(
            "🏏 Total matches found:",
            matchesSnap.size
        );


        let totalRunsFor = 0;
        let totalOversFor = 0;

        let totalRunsAgainst = 0;
        let totalOversAgainst = 0;


        const currentTeamName =
            String(
                team.teamName ||
                team.name ||
                ""
            )
            .trim();


        matchesSnap.forEach(
            (matchDoc) => {

                const match =
                    matchDoc.data();


                const status =
                    String(
                        match.status ||
                        ""
                    )
                    .toLowerCase()
                    .trim();


                const isCompleted =
                    status === "completed" ||
                    !!match.winner ||
                    !!match.result;


                if (!isCompleted) {

                    return;

                }


                const team1Id =
                    String(
                        match.team1Id ||
                        ""
                    );


                const team2Id =
                    String(
                        match.team2Id ||
                        ""
                    );


                const team1Name =
                    String(
                        match.team1Name ||
                        match.teamA ||
                        ""
                    )
                    .trim();


                const team2Name =
                    String(
                        match.team2Name ||
                        match.teamB ||
                        ""
                    )
                    .trim();


                const isTeam1 =
                    team1Id === teamId ||
                    team1Name.toLowerCase() ===
                    currentTeamName.toLowerCase();


                const isTeam2 =
                    team2Id === teamId ||
                    team2Name.toLowerCase() ===
                    currentTeamName.toLowerCase();


                if (
                    !isTeam1 &&
                    !isTeam2
                ) {

                    return;

                }


                stats.matches++;


                // =================================================
                // WINNER
                // =================================================

                const winner =
                    String(
                        match.winner ||
                        ""
                    )
                    .trim();


                const winnerLower =
                    winner.toLowerCase();


                const won =
                    winner === teamId ||
                    winnerLower ===
                    currentTeamName.toLowerCase();


                // =================================================
                // DRAW / TIE
                // =================================================

                const resultText =
                    String(
                        match.result ||
                        ""
                    )
                    .toLowerCase();


                const isDraw =
                    resultText.includes("draw") ||
                    resultText.includes("tie");


                if (isDraw) {

                    stats.draws++;

                    stats.points += 1;

                }
                else if (won) {

                    stats.wins++;

                    stats.points += 3;

                }
                else {

                    stats.losses++;

                }


                // =================================================
                // SCORE
                // =================================================

                let scoreFor = null;
                let scoreAgainst = null;


                if (isTeam1) {

                    scoreFor =
                        parseScore(
                            match.scoreA
                        );

                    scoreAgainst =
                        parseScore(
                            match.scoreB
                        );

                }
                else {

                    scoreFor =
                        parseScore(
                            match.scoreB
                        );

                    scoreAgainst =
                        parseScore(
                            match.scoreA
                        );

                }


                if (scoreFor) {

                    totalRunsFor +=
                        scoreFor.runs;

                }


                if (scoreAgainst) {

                    totalRunsAgainst +=
                        scoreAgainst.runs;

                }


                const matchOvers =
                    Number(
                        match.overs ||
                        0
                    );


                if (
                    scoreFor &&
                    matchOvers > 0
                ) {

                    totalOversFor +=
                        matchOvers;

                }


                if (
                    scoreAgainst &&
                    matchOvers > 0
                ) {

                    totalOversAgainst +=
                        matchOvers;

                }

            }
        );


        if (
            totalOversFor > 0 &&
            totalOversAgainst > 0
        ) {

            stats.nrr =
                (
                    totalRunsFor /
                    totalOversFor
                ) -
                (
                    totalRunsAgainst /
                    totalOversAgainst
                );

        }

    }
    catch (error) {

        console.error(
            "❌ Stats error:",
            error
        );

    }


    return stats;

}


// =====================================================
// PARSE SCORE
// =====================================================

function parseScore(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return null;

    }


    const text =
        String(value);


    const match =
        text.match(
            /(\d+)\s*\/\s*(\d+)/
        );


    if (!match) {

        return null;

    }


    return {

        runs:
            Number(match[1]),

        wickets:
            Number(match[2])

    };

}


// =====================================================
// DISPLAY TEAM
// =====================================================

function displayTeam(
    team,
    players,
    stats
) {

    if (!teamContainer) {

        console.error(
            "❌ teamContainer not found"
        );

        return;

    }


    const teamName =
        team.teamName ||
        team.name ||
        "Unnamed Team";


    const captain =
        team.captainName ||
        team.captain ||
        team.captainNameFull ||
        "Not Available";


    const mobile =
        team.mobile ||
        team.phone ||
        team.mobileNumber ||
        "Not Available";


    const email =
        team.email ||
        team.emailId ||
        "Not Available";


    const city =
        team.city ||
        team.area ||
        team.address ||
        "";


    const logo =
        team.logo ||
        team.logoUrl ||
        team.teamLogo ||
        "";


    localStorage.setItem(
        "currentTeamName",
        teamName
    );


    // =================================================
    // PLAYERS HTML
    // =================================================

    let playersHTML = "";


    if (
        players.length === 0
    ) {

        playersHTML = `

            <div class="no-players">

                <div style="
                    font-size:40px;
                    margin-bottom:8px;
                ">
                    👤
                </div>

                <h3>
                    No Players Added
                </h3>

                <p>
                    Player information has not been added yet.
                </p>

            </div>

        `;

    }
    else {

        playersHTML = `

            <div class="players-grid">

                ${
                    players
                        .map(
                            (player) => {

                                const role =
                                    player.role ||
                                    "Player";


                                return `

                                    <div class="player-card">

                                        <div class="player-number">
                                            ${player.number}
                                        </div>

                                        <div class="player-info">

                                            <div class="player-name">
                                                ${escapeHtml(player.name)}
                                            </div>

                                            <div class="player-role">

                                                ${
                                                    String(role)
                                                        .toLowerCase()
                                                        .includes("captain")
                                                    ?
                                                    "👑 Captain"
                                                    :
                                                    "🏏 Player"
                                                }

                                            </div>

                                        </div>

                                    </div>

                                `;

                            }
                        )
                        .join("")
                }

            </div>

        `;

    }


    // =================================================
    // MAIN HTML
    // =================================================

    teamContainer.innerHTML = `

        <div class="team-profile">

            <div class="team-logo-large">

                ${
                    logo

                    ?

                    `
                    <img
                        src="${escapeHtml(logo)}"
                        alt="${escapeHtml(teamName)}"
                        onerror="this.style.display='none';"
                    >
                    `

                    :

                    `
                    🏏
                    `
                }

            </div>


            <h1>
                ${escapeHtml(teamName)}
            </h1>


            <div class="team-subtitle">
                Cricket Team
            </div>


            ${
                city
                ?
                `
                <div class="team-city">
                    📍 ${escapeHtml(city)}
                </div>
                `
                :
                ""
            }

        </div>


        <div class="section-card">

            <h2>
                👥 Team Information
            </h2>


            <div class="details-grid">

                <div class="detail-item">

                    <span class="detail-label">
                        👑 Captain
                    </span>

                    <strong>
                        ${escapeHtml(captain)}
                    </strong>

                </div>


                <div class="detail-item">

                    <span class="detail-label">
                        📱 Mobile
                    </span>

                    <strong>
                        ${escapeHtml(mobile)}
                    </strong>

                </div>


                <div class="detail-item">

                    <span class="detail-label">
                        📧 Email
                    </span>

                    <strong>
                        ${escapeHtml(email)}
                    </strong>

                </div>

            </div>

        </div>


        <div class="section-card">

            <h2>
                📊 Team Stats
            </h2>


            <div class="stats-grid">

                <div class="stat-card">

                    <div class="stat-number">
                        ${stats.matches}
                    </div>

                    <div class="stat-label">
                        Matches
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-number">
                        ${stats.wins}
                    </div>

                    <div class="stat-label">
                        Wins
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-number">
                        ${stats.losses}
                    </div>

                    <div class="stat-label">
                        Losses
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-number">
                        ${stats.draws}
                    </div>

                    <div class="stat-label">
                        Draws
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-number">
                        ${stats.points}
                    </div>

                    <div class="stat-label">
                        Points
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-number">

                        ${
                            stats.nrr >= 0
                            ? "+"
                            : ""
                        }${stats.nrr.toFixed(3)}

                    </div>

                    <div class="stat-label">
                        NRR
                    </div>

                </div>

            </div>

        </div>


        <!-- =========================================
             PLAYERS
        ========================================== -->

        <div class="section-card">

            <div class="section-title-row">

                <h2>
                    🏏 Players
                </h2>

                <span class="player-count">
                    ${players.length}
                </span>

            </div>


            ${playersHTML}

        </div>


        <button
            id="backToTeams"
            class="back-button main-back"
        >
            ← Back to Teams
        </button>

    `;


    // =================================================
    // BACK
    // =================================================

    document
        .getElementById(
            "backToTeams"
        )
        ?.addEventListener(
            "click",
            () => {

                window.location.href =
                    `teams.html?tournamentId=${encodeURIComponent(tournamentId)}`;

            }
        );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE TEAM.JS READY"
);