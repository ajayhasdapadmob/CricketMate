// =====================================================
// CRICKMATE - WATCH LIVE V2
// Multi-viewer WebRTC receiver + live score overlay
// =====================================================
import { db } from "./firebase.js";
import { collection, doc, getDocs, getDoc, setDoc, updateDoc, deleteDoc, onSnapshot, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

console.log("📺 CRICKMATE WATCH LIVE V2");
const $=id=>document.getElementById(id);
const matchSelect=$("matchSelect"),matchInfo=$("matchInfo"),liveVideo=$("liveVideo"),offline=$("offline"),liveBadge=$("liveBadge"),status=$("status"),scoreboard=$("scoreboard");
const scoreTeamA=$("scoreTeamA"),scoreA=$("scoreA"),oversA=$("oversA"),scoreTeamB=$("scoreTeamB"),scoreB=$("scoreB"),oversB=$("oversB"),batter1Name=$("batter1Name"),batter1Score=$("batter1Score"),batter2Name=$("batter2Name"),batter2Score=$("batter2Score"),bowlerName=$("bowlerName"),bowlerStats=$("bowlerStats");
const videoScoreOverlay=$("videoScoreOverlay"),videoTeamA=$("videoTeamA"),videoScoreA=$("videoScoreA"),videoOversA=$("videoOversA"),videoTeamB=$("videoTeamB"),videoScoreB=$("videoScoreB"),videoOversB=$("videoOversB"),videoBatter1=$("videoBatter1"),videoBatter2=$("videoBatter2"),videoBowler=$("videoBowler");

const p=new URLSearchParams(location.search);
const tournamentId=p.get("tournamentId")||localStorage.getItem("tournamentId")||localStorage.getItem("crickmateTournamentId");
let selectedMatchId=p.get("matchId")||localStorage.getItem("matchId")||"";
let currentStreamRef=null,streamUnsub=null,candidateUnsub=null,scoreUnsub=null,peerConnection=null,viewerRef=null,remoteReady=false,pendingCandidates=[],reconnectTimer=null,connecting=false,currentSessionId=null;
const rtcConfig={iceServers:[{urls:"stun:stun.l.google.com:19302"},{urls:"stun:stun1.l.google.com:19302"}],iceCandidatePoolSize:10};
function getTeamA(d){return d.teamAName||d.teamA||d.team1Name||d.team1||d.homeTeam||d.homeTeamName||"Team A";}
function getTeamB(d){return d.teamBName||d.teamB||d.team2Name||d.team2||d.awayTeam||d.awayTeamName||"Team B";}
function id(){return crypto.randomUUID?.()||(Date.now().toString(36)+Math.random().toString(36).slice(2));}
function setStatus(t,err=false){if(!status)return;status.textContent=t;status.classList.toggle("live",!err&&t.includes("LIVE"));status.style.color=err?"#fca5a5":"";}
function setLive(){offline&&(offline.style.display="none");liveBadge?.classList.add("show");scoreboard?.classList.add("show");videoScoreOverlay?.classList.add("show");setStatus("🔴 LIVE • Connected");}
function setOffline(t="📺 Live stream is offline"){offline&&(offline.style.display="flex");liveBadge?.classList.remove("show");setStatus(t);}

async function loadMatches(){
  if(!matchSelect||!tournamentId)return;
  try{const snap=await getDocs(collection(db,"tournaments",tournamentId,"matches"));matchSelect.innerHTML='<option value="">Select a match</option>';snap.forEach(s=>{const d=s.data(),o=document.createElement("option");o.value=s.id;o.textContent=`${getTeamA(d)} VS ${getTeamB(d)}`;if(s.id===selectedMatchId)o.selected=true;matchSelect.appendChild(o);});if(!selectedMatchId&&snap.size===1){selectedMatchId=snap.docs[0].id;matchSelect.value=selectedMatchId;}if(selectedMatchId)await loadSelectedMatch();}catch(e){console.error(e);setOffline("❌ Unable to load matches");}}
matchSelect?.addEventListener("change",async()=>{selectedMatchId=matchSelect.value;localStorage.setItem("matchId",selectedMatchId);await loadSelectedMatch();});
async function loadSelectedMatch(){if(!selectedMatchId||!tournamentId)return;matchInfo?.classList.remove("hidden");const ref=doc(db,"tournaments",tournamentId,"matches",selectedMatchId);const snap=await getDoc(ref);if(snap.exists()){const d=snap.data();const a=getTeamA(d),b=getTeamB(d);document.querySelectorAll("#teamA,#scoreTeamA,#videoTeamA").forEach(x=>x.textContent=a);document.querySelectorAll("#teamB,#scoreTeamB,#videoTeamB").forEach(x=>x.textContent=b);listenScore(ref);await connectToLiveStream();}}

async function connectToLiveStream(){
  if(!tournamentId||!selectedMatchId||connecting)return;connecting=true;
  try{
    const ref=doc(db,"tournaments",tournamentId,"matches",selectedMatchId,"stream","live");currentStreamRef=ref;
    const snap=await getDoc(ref);
    if(!snap.exists()||snap.data().active!==true){setOffline("📺 Waiting for broadcaster...");watchStreamDocument(ref);return;}
    await startViewer(ref,snap.data());watchStreamDocument(ref);
  }catch(e){console.error(e);setOffline("📺 Unable to connect. Retrying...");scheduleReconnect();}finally{connecting=false;}}
function watchStreamDocument(ref){streamUnsub?.();streamUnsub=onSnapshot(ref,async snap=>{if(!snap.exists()){setOffline("📺 Waiting for broadcaster...");closePeerConnection();return;}const d=snap.data();if(d.active!==true){closePeerConnection();setOffline("📺 Live stream is offline");return;}if(!peerConnection||currentSessionId!==d.sessionId){try{await startViewer(ref,d);}catch(e){console.error(e);scheduleReconnect();}}},e=>{console.error(e);setOffline("❌ Stream listener error");});}

async function startViewer(streamRef,streamData){
  closePeerConnection(); currentSessionId=streamData.sessionId||"legacy"; remoteReady=false; pendingCandidates=[];
  const viewerId=id(); viewerRef=doc(collection(streamRef,"viewers"),viewerId);
  peerConnection=new RTCPeerConnection(rtcConfig);
  peerConnection.ontrack=e=>{const rs=e.streams?.[0]||new MediaStream([e.track]);liveVideo.srcObject=rs;liveVideo.autoplay=true;liveVideo.playsInline=true;liveVideo.muted=false;liveVideo.play().catch(()=>{});setLive();};
  peerConnection.onicecandidate=async e=>{if(e.candidate)await addDoc(collection(viewerRef,"offerCandidates"),e.candidate.toJSON()).catch(console.error);};
  peerConnection.onconnectionstatechange=()=>{const s=peerConnection?.connectionState;if(s==="connected")setLive();if(s==="failed"||s==="disconnected")scheduleReconnect();};
  // Receive-only tracks are required so the offer contains media sections.
  peerConnection.addTransceiver("video",{direction:"recvonly"});
  peerConnection.addTransceiver("audio",{direction:"recvonly"});
  const offer=await peerConnection.createOffer();await peerConnection.setLocalDescription(offer);
  candidateUnsub=onSnapshot(collection(streamRef,"answerCandidates"),()=>{});
  const answerCandidatesRef=collection(viewerRef,"answerCandidates");
  candidateUnsub=onSnapshot(answerCandidatesRef,async snap=>{for(const c of snap.docChanges())if(c.type==="added"){const cand=new RTCIceCandidate(c.doc.data());if(remoteReady){await peerConnection?.addIceCandidate(cand).catch(()=>{});}else pendingCandidates.push(cand);}},e=>console.error(e));
  await setDoc(viewerRef,{active:true,sessionId:currentSessionId,createdAt:serverTimestamp(),offer:{type:offer.type,sdp:offer.sdp}});
  await waitForAnswer(viewerRef);
}

function waitForAnswer(ref){return new Promise((resolve,reject)=>{let done=false;const unsub=onSnapshot(ref,async snap=>{const d=snap.data();if(!d?.answer||done)return;done=true;unsub();try{await peerConnection.setRemoteDescription(new RTCSessionDescription(d.answer));remoteReady=true;for(const c of pendingCandidates)await peerConnection.addIceCandidate(c).catch(()=>{});pendingCandidates=[];setStatus("⏳ Connecting to live...");resolve();}catch(e){reject(e);}} ,reject);setTimeout(()=>{if(!done){unsub();reject(new Error("Viewer answer timeout"));}},20000);});}
function scheduleReconnect(){if(reconnectTimer)return;closePeerConnection();reconnectTimer=setTimeout(async()=>{reconnectTimer=null;await connectToLiveStream();},3000);}
function closePeerConnection(){candidateUnsub?.();candidateUnsub=null;streamUnsub&&0;try{peerConnection?.close();}catch{}peerConnection=null;remoteReady=false;pendingCandidates=[];if(viewerRef){updateDoc(viewerRef,{active:false,closedAt:serverTimestamp()}).catch(()=>{});viewerRef=null;}}
function stopWatching(){if(streamUnsub){streamUnsub();streamUnsub=null;}if(scoreUnsub){scoreUnsub();scoreUnsub=null;}if(reconnectTimer){clearTimeout(reconnectTimer);reconnectTimer=null;}closePeerConnection();if(liveVideo)liveVideo.srcObject=null;setOffline();}

function listenScore(ref){scoreUnsub?.();scoreUnsub=onSnapshot(ref,s=>{if(s.exists())updateScoreboard(s.data());});}
function formatScore(v){if(v==null||v==="")return"0/0";return typeof v==="object"?`${v.runs??0}/${v.wickets??0}`:String(v);}
function formatPlayerScore(v){return v&&typeof v==="object"?`${v.runs??0}* (${v.balls??0})`:`${v??0}*`;}
function getRuns(v){return v&&typeof v==="object"?(v.runs??0):(v??0);}
function updateScoreboard(d){
  const a=getTeamA(d),b=getTeamB(d),sa=formatScore(d.scoreA??d.teamAScore??d.score1),sb=formatScore(d.scoreB??d.teamBScore??d.score2),oa=d.oversA??d.teamAOvers??d.overs1??"0.0",ob=d.oversB??d.teamBOvers??d.overs2??"0.0";
  if(scoreTeamA)scoreTeamA.textContent=a;if(scoreTeamB)scoreTeamB.textContent=b;if(scoreA)scoreA.textContent=sa;if(scoreB)scoreB.textContent=sb;if(oversA)oversA.textContent=`${oa} Overs`;if(oversB)oversB.textContent=`${ob} Overs`;
  const n1=d.batter1Name||d.currentBatter1||"Batter 1",n2=d.batter2Name||d.currentBatter2||"Batter 2",r1=d.batter1Score??d.currentBatter1Score??0,r2=d.batter2Score??d.currentBatter2Score??0,bow=d.bowlerName||d.currentBowler||"Bowler";
  if(batter1Name)batter1Name.textContent=n1;if(batter1Score)batter1Score.textContent=formatPlayerScore(r1);if(batter2Name)batter2Name.textContent=n2;if(batter2Score)batter2Score.textContent=formatPlayerScore(r2);if(bowlerName)bowlerName.textContent=bow;if(bowlerStats)bowlerStats.textContent=`${d.bowlerOvers??0} Overs • ${d.bowlerRuns??0} Runs • ${d.bowlerWickets??0} Wickets`;
  if(videoTeamA)videoTeamA.textContent=a;if(videoTeamB)videoTeamB.textContent=b;if(videoScoreA)videoScoreA.textContent=sa;if(videoScoreB)videoScoreB.textContent=sb;if(videoOversA)videoOversA.textContent=`${oa} Ov`;if(videoOversB)videoOversB.textContent=`${ob} Ov`;if(videoBatter1)videoBatter1.textContent=`${n1} ${getRuns(r1)}*`;if(videoBatter2)videoBatter2.textContent=`${n2} ${getRuns(r2)}*`;if(videoBowler)videoBowler.textContent=bow;
}
window.addEventListener("beforeunload",()=>{try{if(viewerRef)updateDoc(viewerRef,{active:false});}catch{}closePeerConnection();});
loadMatches();
