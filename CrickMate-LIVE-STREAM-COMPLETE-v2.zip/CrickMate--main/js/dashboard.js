// =====================================================
// CRICKMATE - DASHBOARD.JS
// FINAL - GO LIVE + TOURNAMENT FIX
// =====================================================

import {
    auth,
    db
} from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🔥 CRICKMATE DASHBOARD START");
console.log("🎥 GO LIVE SYSTEM READY");


// =====================================================
// ELEMENTS
// =====================================================

const userName =
    document.getElementById("userName");

const userEmail =
    document.getElementById("userEmail");

const welcomeTitle =
    document.getElementById("welcomeTitle");

const quickGoLive =
    document.getElementById("quickGoLive");

const quickTournament =
    document.getElementById("quickTournament");

const quickTeam =
    document.getElementById("quickTeam");

const quickMatch =
    document.getElementById("quickMatch");

const createTournamentBtn =
    document.getElementById("createTournamentBtn");

const viewAllBtn =
    document.getElementById("viewAllBtn");

const logoutBtn =
    document.getElementById("logoutBtn");

const tournamentContainer =
    document.getElementById("tournamentContainer");

const tournamentCount =
    document.getElementById("tournamentCount");

const teamCount =
    document.getElementById("teamCount");

const matchCount =
    document.getElementById("matchCount");


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(
    auth,
    async (user) => {

        console.log(
            "🔐 DASHBOARD USER:",
            user
        );

        if (!user) {

            console.warn(
                "⚠️ USER NOT LOGGED IN"
            );

            window.location.href =
                "./login.html";

            return;
        }


        // =================================================
        // USER INFO
        // =================================================

        const email =
            user.email || "";

        const name =
            email
                ? email.split("@")[0]
                : "CrickMate User";


        if (userName) {
            userName.textContent = name;
        }


        if (userEmail) {
            userEmail.textContent = email;
        }


        if (welcomeTitle) {

            welcomeTitle.textContent =
                `Welcome back, ${name}!`;

        }


        // =================================================
        // LOAD EVERYTHING
        // =================================================

        await loadDashboardData();

    }
);


// =====================================================
// LOAD DASHBOARD DATA
// =====================================================

async function loadDashboardData() {

    console.log(
        "🏆 Loading ALL tournaments..."
    );


    try {

        const tournamentsRef =
            collection(
                db,
                "tournaments"
            );


        const snapshot =
            await getDocs(
                tournamentsRef
            );


        console.log(
            "🏆 FIREBASE TOURNAMENT COUNT:",
            snapshot.size
        );


        // =================================================
        // TOURNAMENT COUNT
        // =================================================

        if (tournamentCount) {

            tournamentCount.textContent =
                snapshot.size;

        }


        // =================================================
        // EMPTY
        // =================================================

        if (snapshot.empty) {

            if (tournamentContainer) {

                tournamentContainer.innerHTML = `

                    <div class="loading-card">

                        <p>
                            No tournaments found.
                        </p>

                    </div>

                `;

            }

            return;
        }


        // =================================================
        // RENDER TOURNAMENTS
        // =================================================

        await renderTournaments(
            snapshot
        );

    } catch (error) {

        console.error(
            "❌ DASHBOARD LOAD ERROR:",
            error
        );


        if (tournamentContainer) {

            tournamentContainer.innerHTML = `

                <div class="loading-card">

                    <p>
                        ❌ Could not load tournaments.
                    </p>

                </div>

            `;

        }

    }

}


// =====================================================
// RENDER TOURNAMENTS
// =====================================================

async function renderTournaments(
    snapshot
) {

    if (!tournamentContainer) {
        return;
    }


    tournamentContainer.innerHTML = "";


    let totalMatches = 0;
    let totalTeams = 0;


    // =================================================
    // LOAD EACH TOURNAMENT
    // =================================================

    for (
        const docSnap
        of snapshot.docs
    ) {

        const data =
            docSnap.data();


        const tournamentId =
            docSnap.id;


        const name =
            data.name ||
            data.tournamentName ||
            data.title ||
            "Unnamed Tournament";


        const status =
            data.status ||
            "Active";


        // =================================================
        // LOAD TEAMS
        // =================================================

        let teams = [];

        try {

            const teamsSnapshot =
                await getDocs(
                    collection(
                        db,
                        "tournaments",
                        tournamentId,
                        "teams"
                    )
                );


            teams =
                teamsSnapshot.docs;


            totalTeams +=
                teamsSnapshot.size;

        } catch (error) {

            console.warn(
                "⚠️ Teams load failed:",
                tournamentId
            );

        }


        // =================================================
        // LOAD MATCHES
        // =================================================

        let matches = [];

        try {

            const matchesSnapshot =
                await getDocs(
                    collection(
                        db,
                        "tournaments",
                        tournamentId,
                        "matches"
                    )
                );


            matches =
                matchesSnapshot.docs;


            totalMatches +=
                matchesSnapshot.size;

        } catch (error) {

            console.warn(
                "⚠️ Matches load failed:",
                tournamentId
            );

        }


        console.log(
            "🏆 TOURNAMENT:",
            name,
            "| ID:",
            tournamentId,
            "| TEAMS:",
            teams.length,
            "| MATCHES:",
            matches.length
        );


        // =================================================
        // CARD
        // =================================================

        const card =
            document.createElement(
                "div"
            );


        card.className =
            "tournament-card";


        card.innerHTML = `

            <div>

                <h3>
                    🏆 ${escapeHtml(name)}
                </h3>

                <p>
                    ${escapeHtml(status)}
                </p>

                <div style="
                    display:flex;
                    gap:15px;
                    margin-top:8px;
                    font-size:13px;
                    color:#64748b;
                ">

                    <span>
                        👥 ${teams.length} Teams
                    </span>

                    <span>
                        🏏 ${matches.length} Matches
                    </span>

                </div>

            </div>


            <button
                type="button"
                class="outline-btn openTournamentBtn"
            >
                Open Tournament →
            </button>

        `;


        const openBtn =
            card.querySelector(
                ".openTournamentBtn"
            );


        if (openBtn) {

            openBtn.addEventListener(
                "click",
                () => {

                    localStorage.setItem(
                        "tournamentId",
                        tournamentId
                    );


                    localStorage.setItem(
                        "crickmateTournamentId",
                        tournamentId
                    );


                    window.location.href =
                        "./tournament.html?tournamentId=" +
                        encodeURIComponent(
                            tournamentId
                        );

                }
            );

        }


        tournamentContainer.appendChild(
            card
        );

    }


    // =================================================
    // UPDATE STATS
    // =================================================

    if (teamCount) {

        teamCount.textContent =
            totalTeams;

    }


    if (matchCount) {

        matchCount.textContent =
            totalMatches;

    }


    console.log(
        "👥 TOTAL TEAMS:",
        totalTeams
    );


    console.log(
        "🏏 TOTAL MATCHES:",
        totalMatches
    );

}


// =====================================================
// GO LIVE
// =====================================================

if (quickGoLive) {

    console.log(
        "🎥 GO LIVE BUTTON READY"
    );


    quickGoLive.addEventListener(
        "click",
        async () => {

            console.log(
                "🎥 GO LIVE CLICKED"
            );


            // =============================================
            // AUTH CHECK
            // =============================================

            const user =
                auth.currentUser;


            if (!user) {

                console.error(
                    "❌ USER NOT LOGGED IN"
                );


                window.location.href =
                    "./login.html";


                return;
            }


            console.log(
                "🔐 LOGGED USER:",
                user.uid
            );


            try {

                // =========================================
                // LOAD ALL TOURNAMENTS
                // =========================================

                const tournamentsRef =
                    collection(
                        db,
                        "tournaments"
                    );


                const tournamentSnapshot =
                    await getDocs(
                        tournamentsRef
                    );


                console.log(
                    "🏆 TOURNAMENTS:",
                    tournamentSnapshot.size
                );


                if (
                    tournamentSnapshot.empty
                ) {

                    alert(
                        "No tournament found in Firebase."
                    );

                    return;
                }


                // =========================================
                // FIND TOURNAMENT WITH MATCH
                // =========================================

                let selectedTournament =
                    null;


                for (
                    const tournamentDoc
                    of tournamentSnapshot.docs
                ) {

                    const tournamentId =
                        tournamentDoc.id;


                    try {

                        const matchesSnapshot =
                            await getDocs(
                                collection(
                                    db,
                                    "tournaments",
                                    tournamentId,
                                    "matches"
                                )
                            );


                        console.log(
                            "🏏",
                            tournamentId,
                            "MATCHES:",
                            matchesSnapshot.size
                        );


                        if (
                            !matchesSnapshot.empty
                        ) {

                            selectedTournament =
                                tournamentDoc;


                            break;

                        }

                    } catch (error) {

                        console.warn(
                            "⚠️ Match check failed:",
                            tournamentId,
                            error
                        );

                    }

                }


                // =========================================
                // IF NO TOURNAMENT HAS MATCH
                // =========================================

                if (!selectedTournament) {

                    // Use first tournament
                    selectedTournament =
                        tournamentSnapshot.docs[0];

                    console.warn(
                        "⚠️ No tournament with matches found."
                    );

                }


                // =========================================
                // GET ID
                // =========================================

                const tournamentId =
                    selectedTournament.id;


                console.log(
                    "🏆 SELECTED TOURNAMENT:",
                    tournamentId
                );


                // =========================================
                // SAVE ID
                // =========================================

                localStorage.setItem(
                    "tournamentId",
                    tournamentId
                );


                localStorage.setItem(
                    "crickmateTournamentId",
                    tournamentId
                );


                // =========================================
                // OPEN ADMIN LIVE
                // =========================================

                const liveUrl =
                    "./admin-live.html?tournamentId=" +
                    encodeURIComponent(
                        tournamentId
                    );


                console.log(
                    "🎥 OPENING:",
                    liveUrl
                );


                window.location.href =
                    liveUrl;

            } catch (error) {

                console.error(
                    "❌ GO LIVE ERROR:",
                    error
                );


                alert(
                    "Unable to open Go Live. Check Console."
                );

            }

        }
    );

}


// =====================================================
// SIDEBAR GO LIVE
// =====================================================

const sideGoLive =
    document.getElementById(
        "sideGoLive"
    );


if (sideGoLive) {

    sideGoLive.addEventListener(
        "click",
        async (event) => {

            event.preventDefault();


            console.log(
                "🎥 SIDEBAR GO LIVE CLICKED"
            );


            if (quickGoLive) {

                quickGoLive.click();

            }

        }
    );

}


// =====================================================
// CREATE TOURNAMENT
// =====================================================

function openCreateTournament() {

    window.location.href =
        "./create-tournament.html";

}


if (quickTournament) {

    quickTournament.addEventListener(
        "click",
        openCreateTournament
    );

}


if (createTournamentBtn) {

    createTournamentBtn.addEventListener(
        "click",
        openCreateTournament
    );

}


// =====================================================
// VIEW ALL
// =====================================================

if (viewAllBtn) {

    viewAllBtn.addEventListener(
        "click",
        () => {

            window.location.href =
                "./tournaments.html";

        }
    );

}


// =====================================================
// CREATE TEAM
// =====================================================

if (quickTeam) {

    quickTeam.addEventListener(
        "click",
        () => {

            window.location.href =
                "./teams.html";

        }
    );

}


// =====================================================
// CREATE MATCH
// =====================================================

if (quickMatch) {

    quickMatch.addEventListener(
        "click",
        () => {

            window.location.href =
                "./matches.html";

        }
    );

}


// =====================================================
// LOGOUT
// =====================================================

if (logoutBtn) {

    logoutBtn.addEventListener(
        "click",
        async () => {

            try {

                await signOut(auth);

                localStorage.removeItem(
                    "tournamentId"
                );

                localStorage.removeItem(
                    "crickmateTournamentId"
                );


                console.log(
                    "🚪 LOGGED OUT"
                );


                window.location.href =
                    "./login.html";

            } catch (error) {

                console.error(
                    "❌ LOGOUT ERROR:",
                    error
                );

            }

        }
    );

}


// =====================================================
// HTML ESCAPE
// =====================================================

function escapeHtml(
    value
) {

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE DASHBOARD READY"
);