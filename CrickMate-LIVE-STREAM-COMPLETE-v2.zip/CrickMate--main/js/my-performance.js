// =====================================================
// CRICKMATE - MY PERFORMANCE
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log(
    "🔥 MY PERFORMANCE JS STARTED"
);


// =====================================================
// PARAMETERS
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


let playerId =
    params.get("playerId") ||
    localStorage.getItem("playerId") ||
    localStorage.getItem("currentPlayerId");


let playerName =
    params.get("playerName") ||
    localStorage.getItem("playerName") ||
    localStorage.getItem("currentPlayerName") ||
    "";


// =====================================================
// ELEMENTS
// =====================================================

const tournamentSelect =
    document.getElementById(
        "tournamentSelect"
    );

const playerNameBox =
    document.getElementById(
        "playerName"
    );

const playerTeamBox =
    document.getElementById(
        "playerTeam"
    );

const summaryBox =
    document.getElementById(
        "summary"
    );

const battingBody =
    document.getElementById(
        "battingBody"
    );

const bowlingBody =
    document.getElementById(
        "bowlingBody"
    );

const matchesBox =
    document.getElementById(
        "matches"
    );


// =====================================================
// LOAD TOURNAMENTS
// =====================================================

async function loadTournaments() {

    console.log(
        "🏆 Loading tournaments..."
    );


    try {

        const ref =
            collection(
                db,
                "tournaments"
            );


        const snap =
            await getDocs(ref);


        console.log(
            "🏆 Tournament count:",
            snap.size
        );


        tournamentSelect.innerHTML = `
            <option value="">
                Select Tournament
            </option>
        `;


        if (snap.empty) {

            tournamentSelect.innerHTML = `
                <option value="">
                    No tournaments found
                </option>
            `;

            showEmpty(
                "No tournaments available."
            );

            return;

        }


        snap.forEach(
            docSnap => {

                const data =
                    docSnap.data();


                const name =
                    data.tournamentName ||
                    data.name ||
                    data.title ||
                    "Unnamed Tournament";


                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    docSnap.id;


                option.textContent =
                    name;


                tournamentSelect.appendChild(
                    option
                );

            }
        );


        // =========================================
        // SELECT SAVED TOURNAMENT
        // =========================================

        if (tournamentId) {

            tournamentSelect.value =
                tournamentId;

        }


        // =========================================
        // FIRST TOURNAMENT
        // =========================================

        if (
            !tournamentSelect.value
        ) {

            tournamentId =
                snap.docs[0].id;


            tournamentSelect.value =
                tournamentId;

        }


        localStorage.setItem(
            "tournamentId",
            tournamentId
        );


        localStorage.setItem(
            "currentTournamentId",
            tournamentId
        );


        await findPlayer();

    }
    catch (error) {

        console.error(
            "❌ Tournament error:",
            error
        );


        tournamentSelect.innerHTML = `
            <option>
                Error loading tournaments
            </option>
        `;


        showError(
            error.message
        );

    }

}


// =====================================================
// TOURNAMENT CHANGE
// =====================================================

tournamentSelect.addEventListener(
    "change",
    async function () {

        tournamentId =
            this.value;


        if (!tournamentId) {

            return;

        }


        localStorage.setItem(
            "tournamentId",
            tournamentId
        );


        localStorage.setItem(
            "currentTournamentId",
            tournamentId
        );


        await findPlayer();

    }
);


// =====================================================
// FIND PLAYER
// =====================================================

async function findPlayer() {

    showLoading();


    if (!tournamentId) {

        showEmpty(
            "Tournament ID missing."
        );

        return;

    }


    console.log(
        "🏆 Searching tournament:",
        tournamentId
    );


    try {

        const teamsRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "teams"
            );


        const teamsSnap =
            await getDocs(
                teamsRef
            );


        console.log(
            "👥 Teams found:",
            teamsSnap.size
        );


        let found =
            null;


        // =================================================
        // SEARCH TEAMS
        // =================================================

        for (
            const teamDoc
            of teamsSnap.docs
        ) {

            const team =
                teamDoc.data();


            const teamName =
                team.teamName ||
                team.name ||
                "Unknown Team";


            // =============================================
            // PLAYER SUBCOLLECTION
            // =============================================

            const playersRef =
                collection(
                    db,
                    "tournaments",
                    tournamentId,
                    "teams",
                    teamDoc.id,
                    "players"
                );


            const playersSnap =
                await getDocs(
                    playersRef
                );


            for (
                const playerDoc
                of playersSnap.docs
            ) {

                const player =
                    playerDoc.data();


                const name =
                    player.playerName ||
                    player.name ||
                    player.fullName ||
                    player.player ||
                    player.playerFullName ||
                    "";


                const sameId =
                    playerId &&
                    playerDoc.id ===
                    playerId;


                const sameName =
                    playerName &&
                    name &&
                    String(name)
                        .trim()
                        .toLowerCase() ===
                    String(playerName)
                        .trim()
                        .toLowerCase();


                if (
                    sameId ||
                    sameName
                ) {

                    found = {

                        ...player,

                        playerId:
                            playerDoc.id,

                        teamId:
                            teamDoc.id,

                        teamName:
                            teamName

                    };


                    break;

                }

            }


            if (found) {

                break;

            }

        }


        // =================================================
        // PLAYER NOT FOUND
        // =================================================

        if (!found) {

            console.warn(
                "⚠️ Player not found"
            );


            showEmpty(
                "Player not found. Open My Performance from your player profile."
            );

            return;

        }


        console.log(
            "✅ Player found:",
            found
        );


        playerId =
            found.playerId;


        playerName =
            getName(found);


        localStorage.setItem(
            "playerId",
            playerId
        );


        localStorage.setItem(
            "currentPlayerId",
            playerId
        );


        localStorage.setItem(
            "playerName",
            playerName
        );


        localStorage.setItem(
            "currentPlayerName",
            playerName
        );


        displayPlayer(
            found
        );

    }
    catch (error) {

        console.error(
            "❌ Player error:",
            error
        );


        showError(
            error.message
        );

    }

}


// =====================================================
// DISPLAY PLAYER
// =====================================================

function displayPlayer(
    player
) {

    const name =
        getName(player);


    const team =
        player.teamName ||
        "Unknown Team";


    const matches =
        number(
            player.matches
        );


    const runs =
        number(
            player.runs
        ) ||
        number(
            player.totalRuns
        );


    const wickets =
        number(
            player.wickets
        ) ||
        number(
            player.totalWickets
        );


    const balls =
        number(
            player.balls
        ) ||
        number(
            player.ballsFaced
        );


    const runsConceded =
        number(
            player.runsConceded
        );


    const overs =
        number(
            player.overs
        );


    let strikeRate =
        number(
            player.strikeRate
        );


    let average =
        number(
            player.average
        );


    let economy =
        number(
            player.economy
        );


    // =================================================
    // CALCULATE
    // =================================================

    if (
        strikeRate === 0 &&
        balls > 0
    ) {

        strikeRate =
            (
                runs /
                balls
            ) * 100;

    }


    if (
        average === 0 &&
        matches > 0
    ) {

        average =
            runs /
            matches;

    }


    if (
        economy === 0 &&
        overs > 0
    ) {

        economy =
            runsConceded /
            overs;

    }


    // =================================================
    // PLAYER INFO
    // =================================================

    playerNameBox.textContent =
        name;


    playerTeamBox.textContent =
        team;


    // =================================================
    // SUMMARY
    // =================================================

    summaryBox.innerHTML = `

        <div class="stat">

            <div class="stat-number">
                ${matches}
            </div>

            <div class="stat-label">
                Matches
            </div>

        </div>


        <div class="stat">

            <div class="stat-number">
                ${runs}
            </div>

            <div class="stat-label">
                Runs
            </div>

        </div>


        <div class="stat">

            <div class="stat-number">
                ${wickets}
            </div>

            <div class="stat-label">
                Wickets
            </div>

        </div>


        <div class="stat">

            <div class="stat-number">
                ${strikeRate.toFixed(2)}
            </div>

            <div class="stat-label">
                Strike Rate
            </div>

        </div>

    `;


    // =================================================
    // BATTING
    // =================================================

    battingBody.innerHTML = `

        <tr>

            <td>
                ${matches}
            </td>

            <td>
                ${runs}
            </td>

            <td>
                ${balls}
            </td>

            <td>
                ${average.toFixed(2)}
            </td>

            <td>
                ${strikeRate.toFixed(2)}
            </td>

        </tr>

    `;


    // =================================================
    // BOWLING
    // =================================================

    bowlingBody.innerHTML = `

        <tr>

            <td>
                ${matches}
            </td>

            <td>
                ${wickets}
            </td>

            <td>
                ${runsConceded}
            </td>

            <td>
                ${overs}
            </td>

            <td>
                ${economy.toFixed(2)}
            </td>

        </tr>

    `;


    // =================================================
    // MATCH
    // =================================================

    matchesBox.innerHTML = `

        <strong>
            🏏 ${matches} Matches Played
        </strong>

        <br><br>

        Runs:
        <strong>
            ${runs}
        </strong>

        &nbsp; • &nbsp;

        Wickets:
        <strong>
            ${wickets}
        </strong>

    `;

}


// =====================================================
// HELPERS
// =====================================================

function getName(
    player
) {

    return (
        player.playerName ||
        player.name ||
        player.fullName ||
        player.player ||
        player.playerFullName ||
        "Player"
    );

}


function number(
    value
) {

    const n =
        Number(value);


    return Number.isFinite(n)
        ? n
        : 0;

}


function showLoading() {

    summaryBox.innerHTML = `
        <div class="loading">
            Loading performance...
        </div>
    `;


    battingBody.innerHTML = `
        <tr>
            <td
                colspan="5"
                class="loading"
            >
                Loading...
            </td>
        </tr>
    `;


    bowlingBody.innerHTML = `
        <tr>
            <td
                colspan="5"
                class="loading"
            >
                Loading...
            </td>
        </tr>
    `;


    matchesBox.innerHTML = `
        Loading match performance...
    `;

}


function showEmpty(
    message
) {

    summaryBox.innerHTML = `
        <div class="empty">
            🏏<br><br>
            ${escapeHtml(message)}
        </div>
    `;


    battingBody.innerHTML = `
        <tr>
            <td
                colspan="5"
                class="empty"
            >
                No batting data available.
            </td>
        </tr>
    `;


    bowlingBody.innerHTML = `
        <tr>
            <td
                colspan="5"
                class="empty"
            >
                No bowling data available.
            </td>
        </tr>
    `;


    matchesBox.textContent =
        message;

}


function showError(
    message
) {

    summaryBox.innerHTML = `
        <div class="error">
            ❌ ${escapeHtml(message)}
        </div>
    `;

}


function escapeHtml(
    value
) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


// =====================================================
// START
// =====================================================

loadTournaments();


console.log(
    "✅ MY PERFORMANCE READY"
);