// =====================================================
// CRICKMATE - SCORECARD.JS
// =====================================================

import { db } from "./firebase.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE SCORECARD.JS STARTED");


// =====================================================
// URL
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId");


let matchId =
    params.get("matchId") ||
    params.get("match") ||
    localStorage.getItem("currentMatchId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

}


if (matchId) {

    matchId =
        matchId.trim();

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);

console.log(
    "🏏 Match ID:",
    matchId
);


// =====================================================
// ELEMENTS
// =====================================================

const loading =
    document.getElementById(
        "loading"
    );

const scorecard =
    document.getElementById(
        "scorecard"
    );

const team1NameEl =
    document.getElementById(
        "team1Name"
    );

const team2NameEl =
    document.getElementById(
        "team2Name"
    );

const scoreAEl =
    document.getElementById(
        "scoreA"
    );

const scoreBEl =
    document.getElementById(
        "scoreB"
    );

const matchTitleEl =
    document.getElementById(
        "matchTitle"
    );

const statusEl =
    document.getElementById(
        "status"
    );

const resultEl =
    document.getElementById(
        "result"
    );

const inningsContainer =
    document.getElementById(
        "inningsContainer"
    );

const ballByBallEl =
    document.getElementById(
        "ballByBall"
    );

const commentaryEl =
    document.getElementById(
        "commentary"
    );

const backBtn =
    document.getElementById(
        "backBtn"
    );


// =====================================================
// VALIDATION
// =====================================================

if (!tournamentId) {

    showError(
        "Tournament ID missing."
    );

}
else if (!matchId) {

    showError(
        "Match ID missing."
    );

}
else {

    loadScorecard();

}


// =====================================================
// LOAD MATCH
// =====================================================

async function loadScorecard() {

    console.log(
        "🔥 Loading scorecard..."
    );


    try {

        const matchRef =
            doc(
                db,
                "tournaments",
                tournamentId,
                "matches",
                matchId
            );


        console.log(
            "📂 Firebase path:",
            `tournaments/${tournamentId}/matches/${matchId}`
        );


        const snap =
            await getDoc(
                matchRef
            );


        if (!snap.exists()) {

            showError(
                "Match not found in Firebase."
            );

            return;

        }


        const match =
            snap.data();


        console.log(
            "✅ MATCH FOUND:",
            match
        );


        renderMatch(
            match
        );


        renderInnings(
            match
        );


        renderBalls(
            match
        );


        renderCommentary(
            match
        );


        if (loading) {

            loading.style.display =
                "none";

        }


        if (scorecard) {

            scorecard.style.display =
                "block";

        }


        console.log(
            "✅ CRICKMATE SCORECARD READY"
        );

    }
    catch (error) {

        console.error(
            "❌ SCORECARD ERROR:",
            error
        );


        showError(
            error.message ||
            "Unable to load scorecard."
        );

    }

}


// =====================================================
// TEAM NAME
// =====================================================

function getTeamName(
    match,
    number
) {

    if (number === 1) {

        return (
            match.team1Name ||
            match.teamA ||
            match.team1 ||
            "Team 1"
        );

    }


    return (
        match.team2Name ||
        match.teamB ||
        match.team2 ||
        "Team 2"
    );

}


// =====================================================
// RENDER MATCH
// =====================================================

function renderMatch(
    match
) {

    const team1 =
        getTeamName(
            match,
            1
        );


    const team2 =
        getTeamName(
            match,
            2
        );


    if (team1NameEl) {

        team1NameEl.textContent =
            team1;

    }


    if (team2NameEl) {

        team2NameEl.textContent =
            team2;

    }


    if (scoreAEl) {

        scoreAEl.textContent =
            match.scoreA ||
            match.firstInningsScore ||
            "0/0";

    }


    if (scoreBEl) {

        scoreBEl.textContent =
            match.scoreB ||
            match.secondInningsScore ||
            "0/0";

    }


    if (matchTitleEl) {

        matchTitleEl.textContent =
            match.matchNumber
            ?
            `Match ${match.matchNumber}`
            :
            "Match";

    }


    if (statusEl) {

        statusEl.textContent =
            match.status ||
            "Scheduled";

    }


    if (resultEl) {

        resultEl.textContent =
            match.result ||
            "Match in progress.";

    }


    if (backBtn) {

        backBtn.href =
            `live-score.html?tournamentId=${encodeURIComponent(
                tournamentId
            )}&matchId=${encodeURIComponent(
                matchId
            )}`;

    }

}


// =====================================================
// RENDER INNINGS
// =====================================================

function renderInnings(
    match
) {

    if (!inningsContainer) {
        return;
    }


    const team1 =
        getTeamName(
            match,
            1
        );


    const team2 =
        getTeamName(
            match,
            2
        );


    const score1 =
        match.firstInningsScore ||
        match.scoreA ||
        "0/0";


    const score2 =
        match.secondInningsScore ||
        match.scoreB ||
        "0/0";


    const overs1 =
        match.firstInningsOvers ||
        calculateOvers(
            match,
            1
        );


    const overs2 =
        match.secondInningsOvers ||
        calculateOvers(
            match,
            2
        );


    inningsContainer.innerHTML = `

        <div class="card">

            <div class="innings-title">

                🏏 ${escapeHtml(team1)}
                - 1st Innings

            </div>


            <div class="score-summary">

                <strong>
                    ${escapeHtml(score1)}
                </strong>

                <span>
                    ${escapeHtml(
                        String(overs1)
                    )} Overs
                </span>

            </div>

        </div>


        <div class="card">

            <div class="innings-title">

                🏏 ${escapeHtml(team2)}
                - 2nd Innings

            </div>


            <div class="score-summary">

                <strong>
                    ${escapeHtml(score2)}
                </strong>

                <span>
                    ${escapeHtml(
                        String(overs2)
                    )} Overs
                </span>

            </div>

        </div>

    `;

}


// =====================================================
// CALCULATE OVERS
// =====================================================

function calculateOvers(
    match,
    innings
) {

    const balls =
        Array.isArray(match.balls)
        ?
        match.balls.filter(
            ball =>
                Number(
                    ball.innings
                ) === innings
        )
        :
        [];


    if (!balls.length) {

        return "0.0";

    }


    const legalBalls =
        balls.length;


    const overs =
        Math.floor(
            legalBalls / 6
        );


    const remaining =
        legalBalls % 6;


    return `${overs}.${remaining}`;

}


// =====================================================
// BALL BY BALL
// =====================================================

function renderBalls(
    match
) {

    if (!ballByBallEl) {
        return;
    }


    const balls =
        Array.isArray(match.balls)
        ?
        match.balls
        :
        [];


    if (!balls.length) {

        ballByBallEl.textContent =
            "No balls recorded.";

        return;

    }


    let html = "";


    let currentInnings = null;


    balls.forEach(
        ball => {

            const innings =
                Number(
                    ball.innings || 1
                );


            if (
                innings !==
                currentInnings
            ) {

                currentInnings =
                    innings;


                html += `

                    <div style="
                        margin-top:15px;
                        margin-bottom:8px;
                        font-weight:bold;
                    ">

                        ${
                            innings === 1
                            ?
                            "🏏 1st Innings"
                            :
                            "🏏 2nd Innings"
                        }

                    </div>

                `;

            }


            const runs =
                Number(
                    ball.runs || 0
                );


            let text =
                String(runs);


            let className =
                "ball";


            if (ball.wicket) {

                text =
                    "W";

                className +=
                    " wicket";

            }
            else if (runs === 4) {

                className +=
                    " four";

            }
            else if (runs === 6) {

                className +=
                    " six";

            }


            html += `

                <span
                    class="${className}"
                    title="${escapeHtml(
                        ball.commentary || ""
                    )}"
                >

                    ${escapeHtml(
                        ball.number ||
                        ""
                    )}

                    :

                    ${escapeHtml(
                        text
                    )}

                </span>

            `;

        }
    );


    ballByBallEl.innerHTML =
        html;

}


// =====================================================
// COMMENTARY
// =====================================================

function renderCommentary(
    match
) {

    if (!commentaryEl) {
        return;
    }


    const balls =
        Array.isArray(match.balls)
        ?
        match.balls
        :
        [];


    if (!balls.length) {

        commentaryEl.textContent =
            "No commentary yet.";

        return;

    }


    commentaryEl.innerHTML =
        [...balls]
            .reverse()
            .map(
                ball => {

                    const icon =
                        ball.wicket
                        ?
                        "🟥"
                        :
                        "🏏";


                    return `

                        <div class="commentary">

                            <strong>

                                ${icon}

                                Ball
                                ${escapeHtml(
                                    ball.number ||
                                    ""
                                )}

                            </strong>

                            <br>

                            ${escapeHtml(
                                ball.commentary ||
                                ""
                            )}

                            ${
                                ball.striker
                                ?
                                `
                                <br>
                                🏏 Striker:
                                ${escapeHtml(
                                    ball.striker
                                )}
                                `
                                :
                                ""
                            }

                            ${
                                ball.nonStriker
                                ?
                                `
                                <br>
                                🏏 Non-Striker:
                                ${escapeHtml(
                                    ball.nonStriker
                                )}
                                `
                                :
                                ""
                            }

                            ${
                                ball.bowler
                                ?
                                `
                                <br>
                                🎯 Bowler:
                                ${escapeHtml(
                                    ball.bowler
                                )}
                                `
                                :
                                ""
                            }

                        </div>

                    `;

                }
            )
            .join("");

}


// =====================================================
// ERROR
// =====================================================

function showError(
    text
) {

    if (loading) {

        loading.innerHTML = `

            <div class="error">

                ❌ ${escapeHtml(text)}

            </div>

        `;

    }

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


console.log(
    "🏏 CRICKMATE SCORECARD.JS LOADED"
);