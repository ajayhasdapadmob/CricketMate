// =====================================================
// CRICKMATE - HOME / INDEX.JS
// VIDEO STYLE HOME PAGE
// =====================================================

console.log("🏏 CRICKMATE INDEX.JS STARTED");


// =====================================================
// ELEMENTS
// =====================================================

const menuButton =
    document.getElementById("menuButton");

const drawerOverlay =
    document.getElementById("drawerOverlay");

const closeMenuButton =
    document.getElementById("closeMenuButton");

const languageButton =
    document.getElementById("languageButton");

const languageBox =
    document.getElementById("languageBox");

const languageSelect =
    document.getElementById("languageSelect");

const shareAppButton =
    document.getElementById("shareAppButton");

const searchButton =
    document.getElementById("searchButton");

const messageButton =
    document.getElementById("messageButton");

const notificationButton =
    document.getElementById("notificationButton");

const proButton =
    document.getElementById("proButton");

const startFollowingButton =
    document.getElementById("startFollowingButton");

const forYouTab =
    document.getElementById("forYouTab");

const clubTab =
    document.getElementById("clubTab");
const moreButton = document.getElementById("moreButton");
const moreMenu = document.getElementById("moreMenu");

if (moreButton && moreMenu) {

    moreButton.addEventListener("click", () => {

        if (moreMenu.style.display === "none") {

            moreMenu.style.display = "block";
            moreButton.innerHTML = "➖ More";

        } else {

            moreMenu.style.display = "none";
            moreButton.innerHTML = "➕ More";

        }

    });

}

// =====================================================
// OPEN MENU
// =====================================================

if (menuButton && drawerOverlay) {

    menuButton.addEventListener(
        "click",
        () => {

            drawerOverlay.classList.add("show");

        }
    );

}


// =====================================================
// CLOSE MENU
// =====================================================

if (closeMenuButton && drawerOverlay) {

    closeMenuButton.addEventListener(
        "click",
        () => {

            drawerOverlay.classList.remove("show");

        }
    );

}


// =====================================================
// CLOSE WHEN CLICK OUTSIDE
// =====================================================

if (drawerOverlay) {

    drawerOverlay.addEventListener(
        "click",
        (event) => {

            if (
                event.target ===
                drawerOverlay
            ) {

                drawerOverlay.classList.remove(
                    "show"
                );

            }

        }
    );

}


// =====================================================
// LANGUAGE
// =====================================================

const savedLanguage =
    localStorage.getItem(
        "crickmateLanguage"
    );


if (
    savedLanguage &&
    languageSelect
) {

    languageSelect.value =
        savedLanguage;

}


if (languageButton) {

    languageButton.addEventListener(
        "click",
        () => {

            if (!languageBox) {
                return;
            }


            if (
                languageBox.style.display ===
                "block"
            ) {

                languageBox.style.display =
                    "none";

            }
            else {

                languageBox.style.display =
                    "block";

            }

        }
    );

}


if (languageSelect) {

    languageSelect.addEventListener(
        "change",
        () => {

            const language =
                languageSelect.value;


            localStorage.setItem(
                "crickmateLanguage",
                language
            );


            console.log(
                "🌐 LANGUAGE:",
                language
            );


            alert(
                "✅ Language saved."
            );

        }
    );

}


// =====================================================
// SHARE APP
// =====================================================

if (shareAppButton) {

    shareAppButton.addEventListener(
        "click",
        async () => {

            const shareData = {

                title:
                    "🏏 CrickMate",

                text:
                    "🏏 CrickMate - Your Cricket Companion",

                url:
                    window.location.origin +
                    window.location.pathname

            };


            if (
                navigator.share
            ) {

                try {

                    await navigator.share(
                        shareData
                    );


                    console.log(
                        "✅ CRICKMATE SHARED"
                    );

                }
                catch (error) {

                    console.log(
                        "ℹ️ Share cancelled"
                    );

                }

                return;

            }


            try {

                await navigator.clipboard.writeText(
                    shareData.url
                );


                alert(
                    "✅ CrickMate link copied."
                );

            }
            catch (error) {

                window.prompt(
                    "Copy CrickMate link:",
                    shareData.url
                );

            }

        }
    );

}


// =====================================================
// SEARCH
// =====================================================

if (searchButton) {

    searchButton.addEventListener(
        "click",
        () => {

            const search =
                window.prompt(
                    "🔍 Search CrickMate"
                );


            if (
                search === null
            ) {
                return;
            }


            const value =
                search.trim();


            if (!value) {

                return;

            }


            console.log(
                "🔍 SEARCH:",
                value
            );


            window.location.href =
                `./live-scores.html?search=${encodeURIComponent(
                    value
                )}`;

        }
    );

}


// =====================================================
// MESSAGE
// =====================================================

if (messageButton) {

    messageButton.addEventListener(
        "click",
        () => {

            alert(
                "💬 Messages\n\nCrickMate messaging feature will be available here."
            );

        }
    );

}


// =====================================================
// NOTIFICATIONS
// =====================================================

if (notificationButton) {

    notificationButton.addEventListener(
        "click",
        () => {

            alert(
                "🔔 Notifications\n\nNo new notifications."
            );

        }
    );

}


// =====================================================
// PRO
// =====================================================

if (proButton) {

    proButton.addEventListener(
        "click",
        () => {

            alert(
                "🏏 CrickMate PRO\n\nPRO features will be available soon."
            );

        }
    );

}


// =====================================================
// START FOLLOWING
// =====================================================

if (startFollowingButton) {

    startFollowingButton.addEventListener(
        "click",
        () => {

            window.location.href =
                "./my-cricket.html";

        }
    );

}


// =====================================================
// FOR YOU TAB
// =====================================================

if (forYouTab) {

    forYouTab.addEventListener(
        "click",
        () => {

            forYouTab.classList.add(
                "active"
            );


            if (clubTab) {

                clubTab.classList.remove(
                    "active"
                );

            }

        }
    );

}


// =====================================================
// CLUB TAB
// =====================================================

if (clubTab) {

    clubTab.addEventListener(
        "click",
        () => {

            clubTab.classList.add(
                "active"
            );


            if (forYouTab) {

                forYouTab.classList.remove(
                    "active"
                );

            }


            alert(
                "🏏 PRO Club\n\nClub content will appear here."
            );

        }
    );

}


// =====================================================
// SAVE HOME VISIT
// =====================================================

localStorage.setItem(
    "crickmateLastPage",
    "home"
);


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE HOME READY"
);