// =====================================================
// CRICKMATE - PLAYERS.JS
// =====================================================

import {
    db
} from "./firebase.js";

import {
    doc,
    getDoc,
    collection,
    onSnapshot,
    query,
    orderBy
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log(
    "👥 CRICKMATE PLAYERS.JS STARTED"
);


// =====================================================
// URL PARAMETERS
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


const tournamentId =
    params.get(
        "tournamentId"
    );


const teamId =
    params.get(
        "teamId"
    );


console.log(
    "🏆 Tournament ID:",
    tournamentId
);

console.log(
    "👥 Team ID:",
    teamId
);


// =====================================================
// ELEMENTS
// =====================================================

const playersContainer =
    document.getElementById(
        "playersContainer"
    );


const playerCount =
    document.getElementById(
        "playerCount"
    );


const teamName =
    document.getElementById(
        "teamName"
    );


const addPlayerBtn =
    document.getElementById(
        "addPlayerBtn"
    );


const backBtn =
    document.getElementById(
        "backBtn"
    );


// =====================================================
// CHECK PARAMETERS
// =====================================================

if (
    !tournamentId ||
    !teamId
) {

    playersContainer.innerHTML = `

        <div class="error">

            <h3>
                ⚠️ Team Information Missing
            </h3>

            <p>
                Tournament ID or Team ID is missing.
            </p>

        </div>

    `;

    throw new Error(
        "Tournament ID or Team ID missing"
    );

}


// =====================================================
// LINKS
// =====================================================

addPlayerBtn.href =
    `./create-player.html?tournamentId=${encodeURIComponent(tournamentId)}&teamId=${encodeURIComponent(teamId)}`;


backBtn.href =
    `./teams.html?tournamentId=${encodeURIComponent(tournamentId)}`;


// =====================================================
// LOAD TEAM
// =====================================================

async function loadTeam() {

    try {

        const teamRef =
            doc(
                db,
                "tournaments",
                tournamentId,
                "teams",
                teamId
            );


        const teamSnap =
            await getDoc(
                teamRef
            );


        if (
            teamSnap.exists()
        ) {

            const team =
                teamSnap.data();


            teamName.textContent =
                team.name ||
                "Team";

        }

        else {

            teamName.textContent =
                "Team not found";

        }

    }

    catch (error) {

        console.error(
            "❌ TEAM LOAD ERROR:",
            error
        );

        teamName.textContent =
            "Unable to load team";

    }

}


loadTeam();


// =====================================================
// PLAYERS COLLECTION
// =====================================================

const playersRef =
    collection(
        db,
        "tournaments",
        tournamentId,
        "teams",
        teamId,
        "players"
    );


const playersQuery =
    query(
        playersRef,
        orderBy(
            "createdAt",
            "desc"
        )
    );


// =====================================================
// REALTIME PLAYERS
// =====================================================

onSnapshot(

    playersQuery,

    (snapshot) => {

        console.log(
            "👥 PLAYERS:",
            snapshot.size
        );


        playerCount.textContent =
            `${snapshot.size} Player${snapshot.size === 1 ? "" : "s"}`;


        if (
            snapshot.empty
        ) {

            playersContainer.innerHTML = `

                <div class="empty">

                    <h3>
                        🏏 No Players Yet
                    </h3>

                    <p>
                        Add players to this team.
                    </p>

                </div>

            `;

            return;

        }


        playersContainer.innerHTML =
            "";


        snapshot.forEach(
            (playerDoc) => {

                const player =
                    playerDoc.data();


                const photo =
                    player.photo ||
                    player.photoURL ||
                    "";


                const playerImage =
                    photo
                    ? `
                        <img
                            src="${escapeHtml(photo)}"
                            alt="${escapeHtml(
                                player.name ||
                                "Player"
                            )}"
                        >
                    `
                    : "🏏";


                const card =
                    document.createElement(
                        "div"
                    );


                card.className =
                    "player-card";


                card.innerHTML = `

                    <div class="player-photo">

                        ${playerImage}

                    </div>


                    <div class="player-name">

                        ${escapeHtml(
                            player.name ||
                            "Unnamed Player"
                        )}

                    </div>


                    <div class="player-role">

                        ${escapeHtml(
                            player.role ||
                            "Player"
                        )}

                    </div>


                    ${
                        player.jerseyNumber !==
                        undefined
                        ? `
                            <div class="player-number">
                                #${escapeHtml(
                                    player.jerseyNumber
                                )}
                            </div>
                        `
                        : ""
                    }

                `;


                playersContainer.appendChild(
                    card
                );

            }
        );

    },

    (error) => {

        console.error(
            "❌ PLAYERS LOAD ERROR:",
            error
        );


        playerCount.textContent =
            "Error loading players";


        playersContainer.innerHTML = `

            <div class="error">

                <h3>
                    ❌ Unable to Load Players
                </h3>

                <p>
                    ${escapeHtml(
                        error.message
                    )}
                </p>

            </div>

        `;

    }

);


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    return String(value)
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


console.log(
    "✅ CRICKMATE PLAYERS READY"
);