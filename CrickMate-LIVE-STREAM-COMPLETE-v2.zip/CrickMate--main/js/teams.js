// =====================================================
// CRICKMATE - TEAMS.JS
// =====================================================

import {
db
} from "./firebase.js";

import {
collection,
onSnapshot,
query,
orderBy
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

console.log("👥 CRICKMATE TEAMS.JS STARTED");

// =====================================================
// GET TOURNAMENT ID
// =====================================================

const params = new URLSearchParams(window.location.search);

let tournamentId =
params.get("tournamentId") ||
params.get("id") ||
localStorage.getItem("tournamentId") ||
localStorage.getItem("currentTournamentId");

// =====================================================
// CLEAN TOURNAMENT ID
// =====================================================

if (tournamentId) {

tournamentId = tournamentId.trim();  

// Save for other pages  
localStorage.setItem("tournamentId", tournamentId);  
localStorage.setItem("currentTournamentId", tournamentId);

}

// =====================================================
// LOG
// =====================================================

console.log("🏆 Tournament ID:", tournamentId);

// =====================================================
// PAGE ELEMENTS
// =====================================================

const teamsContainer =
document.getElementById("teamsContainer") ||
document.getElementById("teamsList") ||
document.querySelector(".teams-list") ||
document.querySelector("#teams");

const errorBox =
document.getElementById("errorMessage") ||
document.getElementById("tournamentError");

// =====================================================
// SHOW ERROR
// =====================================================

function showTournamentError() {

console.error("❌ Tournament ID missing");  

if (teamsContainer) {  

    teamsContainer.innerHTML = `  
        <div style="  
            padding:20px;  
            margin:15px 0;  
            background:#fff3cd;  
            border:1px solid #ffe69c;  
            border-radius:12px;  
            color:#664d03;  
            text-align:center;  
        ">  
            <strong>⚠️ Tournament ID Missing</strong>  

            <p style="margin:8px 0 0;">  
                Please open Teams from Tournament Centre.  
            </p>  
        </div>  
    `;  

}  

if (errorBox) {  

    errorBox.textContent =  
        "Tournament ID missing";  

}

}

// =====================================================
// NO TOURNAMENT ID
// =====================================================

if (!tournamentId) {

showTournamentError();

} else {

loadTeams();

}

// =====================================================
// LOAD TEAMS
// =====================================================

function loadTeams() {

console.log("🔥 Loading teams for tournament:", tournamentId);  


const teamsRef = collection(  
db,  
"tournaments",  
tournamentId,  
"teams"

);

const teamsQuery = query(  
    teamsRef,  
    orderBy("createdAt", "asc")  
);  


onSnapshot(  
    teamsQuery,  

    (snapshot) => {  

        console.log(  
            "🏏 Teams found:",  
            snapshot.size  
        );  


        if (!teamsContainer) {  

            console.error(  
                "❌ Teams container not found in HTML"  
            );  

            return;  

        }  


        // =================================================  
        // NO TEAMS  
        // =================================================  

        if (snapshot.empty) {  

            teamsContainer.innerHTML = `  
                <div style="  
                    padding:25px;  
                    text-align:center;  
                    color:#64748b;  
                ">  
                    <div style="  
                        font-size:40px;  
                        margin-bottom:10px;  
                    ">  
                        👥  
                    </div>  

                    <h3>No Teams Yet</h3>  

                    <p>  
                        No teams have been added to this tournament.  
                    </p>  
                </div>  
            `;  

            return;  

        }  


        // =================================================  
        // DISPLAY TEAMS  
        // =================================================  

        teamsContainer.innerHTML = "";  


        snapshot.forEach((docSnap) => {  

            const team =  
                docSnap.data();  

            const teamId =  
                docSnap.id;  

            const teamName =  
                team.teamName ||  
                team.name ||  
                "Unnamed Team";  

            const captain =  
                team.captainName ||  
                team.captain ||  
                "Not Available";  

            const mobile =  
                team.mobile ||  
                team.phone ||  
                "";  

            const logo =  
                team.logo ||  
                team.logoUrl ||  
                "";  


            const card =  
                document.createElement("div");  


            card.className =  
                "team-card";  


            card.innerHTML = `  

                <div class="team-logo">  

                    ${  
                        logo  
                        ?  
                        `  
                        <img  
                            src="${escapeHtml(logo)}"  
                            alt="${escapeHtml(teamName)}"  
                            onerror="this.style.display='none';"  
                        >  
                        `  
                        :  
                        `  
                        <div class="default-team-logo">  
                            🏏  
                        </div>  
                        `  
                    }  

                </div>  


                <div class="team-info">  

                    <h3>  
                        ${escapeHtml(teamName)}  
                    </h3>  

                    <p>  
                        <strong>Captain:</strong>  
                        ${escapeHtml(captain)}  
                    </p>  

                    ${  
                        mobile  
                        ?  
                        `  
                        <p>  
                            <strong>Mobile:</strong>  
                            ${escapeHtml(mobile)}  
                        </p>  
                        `  
                        :  
                        ""  
                    }  

                </div>  


                <div class="team-actions">  

                    <button  
                        class="view-team-btn"  
                        data-team-id="${escapeHtml(teamId)}"  
                    >  
                        View  
                    </button>  

                </div>  

            `;  


            teamsContainer.appendChild(card);  

        });  


        // =================================================  
        // VIEW BUTTONS  
        // =================================================  

        document  
            .querySelectorAll(".view-team-btn")  
            .forEach((button) => {  

                button.addEventListener(  
                    "click",  
                    () => {  

                        const teamId =  
                            button.dataset.teamId;  


                        window.location.href =  
                            `team.html?tournamentId=${encodeURIComponent(tournamentId)}&teamId=${encodeURIComponent(teamId)}`;  

                    }  
                );  

            });  


    },  


    (error) => {  

        console.error(  
            "❌ Error loading teams:",  
            error  
        );  


        if (teamsContainer) {  

            teamsContainer.innerHTML = `  
                <div style="  
                    padding:20px;  
                    background:#fee2e2;  
                    border:1px solid #fecaca;  
                    border-radius:12px;  
                    color:#991b1b;  
                ">  
                    ❌ Failed to load teams.  

                    <br><br>  

                    ${escapeHtml(error.message)}  
                </div>  
            `;  

        }  

    }  

);

}

// =====================================================
// HTML ESCAPE
// =====================================================

function escapeHtml(value) {

if (value === null || value === undefined) {  
    return "";  
}  

return String(value)  
    .replace(/&/g, "&amp;")  
    .replace(/</g, "&lt;")  
    .replace(/>/g, "&gt;")  
    .replace(/"/g, "&quot;")  
    .replace(/'/g, "&#039;");

}

// =====================================================
// DEBUG
// =====================================================

console.log(
"✅ CRICKMATE TEAMS.JS READY"
);