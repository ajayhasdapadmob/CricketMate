// =====================================================
// CRICKMATE - ADMIN TEAMS.JS
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs,
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log(
    "👥 CRICKMATE ADMIN-TEAMS.JS STARTED"
);


// =====================================================
// URL PARAMETERS
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

}


// =====================================================
// ELEMENTS
// =====================================================

const teamList =
    document.getElementById(
        "teamList"
    );

const teamCount =
    document.getElementById(
        "teamCount"
    );

const tournamentInfo =
    document.getElementById(
        "tournamentInfo"
    );


// =====================================================
// VALIDATE
// =====================================================

if (!tournamentId) {

    showError(
        "Tournament ID missing. Open this page with ?tournamentId=..."
    );

}
else {

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

    loadTeams();

}


// =====================================================
// LOAD TEAMS
// =====================================================

async function loadTeams() {

    console.log(
        "🔥 Loading teams..."
    );


    try {

        await loadTournamentInfo();


        const teamsRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "teams"
            );


        const snapshot =
            await getDocs(
                teamsRef
            );


        console.log(
            "👥 TEAM COUNT:",
            snapshot.size
        );


        if (teamCount) {

            teamCount.textContent =
                snapshot.size;

        }


        if (snapshot.empty) {

            teamList.innerHTML = `

                <div class="empty">

                    <div style="font-size:40px;">
                        👥
                    </div>

                    <h3>
                        No Teams Found
                    </h3>

                    <p>
                        No teams have been added to this tournament yet.
                    </p>

                </div>

            `;

            return;

        }


        teamList.innerHTML = "";


        snapshot.forEach(
            (teamDoc) => {

                const team =
                    teamDoc.data();


                renderTeam(
                    teamDoc.id,
                    team
                );

            }
        );


        console.log(
            "✅ TEAMS DISPLAYED"
        );

    }
    catch (error) {

        console.error(
            "❌ Team loading error:",
            error
        );


        showError(
            error.message ||
            "Unable to load teams."
        );

    }

}


// =====================================================
// LOAD TOURNAMENT INFO
// =====================================================

async function loadTournamentInfo() {

    try {

        const tournamentRef =
            doc(
                db,
                "tournaments",
                tournamentId
            );


        const snapshot =
            await getDoc(
                tournamentRef
            );


        if (!snapshot.exists()) {

            if (tournamentInfo) {

                tournamentInfo.textContent =
                    `Tournament ID: ${tournamentId}`;

            }

            return;

        }


        const tournament =
            snapshot.data();


        const name =
            tournament.tournamentName ||
            tournament.name ||
            tournament.title ||
            "Unnamed Tournament";


        if (tournamentInfo) {

            tournamentInfo.textContent =
                `${name} • Tournament ID: ${tournamentId}`;

        }

    }
    catch (error) {

        console.warn(
            "⚠️ Tournament info unavailable:",
            error
        );

    }

}


// =====================================================
// RENDER TEAM
// =====================================================

function renderTeam(
    teamId,
    team
) {

    const teamName =
        team.teamName ||
        team.name ||
        "Unnamed Team";


    const shortName =
        team.shortName ||
        "";


    const captain =
        team.captainName ||
        team.captain ||
        "Not Available";


    const mobile =
        team.mobile ||
        team.phone ||
        "Not Available";


    const email =
        team.email ||
        "Not Available";


    const city =
        team.city ||
        team.area ||
        team.address ||
        "Not Available";


    const logo =
        team.logo ||
        team.logoUrl ||
        team.teamLogo ||
        "";


    const matches =
        Number(
            team.matches || 0
        );


    const wins =
        Number(
            team.wins || 0
        );


    const losses =
        Number(
            team.losses || 0
        );


    const points =
        Number(
            team.points || 0
        );


    const card =
        document.createElement(
            "div"
        );


    card.className =
        "team-card";


    card.innerHTML = `

        <div class="team-header">


            <div class="logo">

                ${
                    logo

                    ?

                    `
                    <img
                        src="${escapeHtml(logo)}"
                        alt="${escapeHtml(teamName)}"
                        onerror="
                            this.style.display='none';
                        "
                    >
                    `

                    :

                    `🏏`

                }

            </div>


            <div>

                <div class="team-name">
                    ${escapeHtml(teamName)}
                </div>

                ${
                    shortName
                    ?
                    `
                    <div class="short-name">
                        ${escapeHtml(shortName)}
                    </div>
                    `
                    :
                    ""
                }

            </div>

        </div>


        <div class="details">


            <div class="detail">

                <span class="detail-label">
                    👑 Captain
                </span>

                <span class="detail-value">
                    ${escapeHtml(captain)}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    📍 City / Area
                </span>

                <span class="detail-value">
                    ${escapeHtml(city)}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    📱 Mobile
                </span>

                <span class="detail-value">
                    ${escapeHtml(mobile)}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    📧 Email
                </span>

                <span class="detail-value">
                    ${escapeHtml(email)}
                </span>

            </div>


        </div>


        <div class="stats">


            <div class="stat">

                <div class="stat-number">
                    ${matches}
                </div>

                <div class="stat-label">
                    Matches
                </div>

            </div>


            <div class="stat">

                <div class="stat-number">
                    ${wins}
                </div>

                <div class="stat-label">
                    Wins
                </div>

            </div>


            <div class="stat">

                <div class="stat-number">
                    ${losses}
                </div>

                <div class="stat-label">
                    Losses
                </div>

            </div>


            <div class="stat">

                <div class="stat-number">
                    ${points}
                </div>

                <div class="stat-label">
                    Points
                </div>

            </div>


        </div>


        <div class="actions">

            <a
                class="btn"
                href="team.html?tournamentId=${encodeURIComponent(
                    tournamentId
                )}&teamId=${encodeURIComponent(
                    teamId
                )}"
            >
                👤 View Team
            </a>

        </div>

    `;


    teamList.appendChild(
        card
    );

}


// =====================================================
// ERROR
// =====================================================

function showError(
    text
) {

    if (!teamList) {
        return;
    }


    teamList.innerHTML = `

        <div class="error">

            ⚠️

            <h3>
                Unable to Load Teams
            </h3>

            <p>
                ${escapeHtml(text)}
            </p>

        </div>

    `;

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE ADMIN-TEAMS.JS READY"
);