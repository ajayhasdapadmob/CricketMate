// =====================================================
// CRICKMATE - GO LIVE
// AUTOMATIC MATCH + WATCH LIVE
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs,
    doc,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🔴 CRICKMATE GO LIVE JS STARTED");


// =====================================================
// ELEMENTS
// =====================================================

const loading =
    document.getElementById("loading");

const matchCard =
    document.getElementById("matchCard");

const matchStatus =
    document.getElementById("matchStatus");

const teamAElement =
    document.getElementById("teamA");

const teamBElement =
    document.getElementById("teamB");

const scoreAElement =
    document.getElementById("scoreA");

const scoreBElement =
    document.getElementById("scoreB");

const oversAElement =
    document.getElementById("oversA");

const oversBElement =
    document.getElementById("oversB");

const tournamentNameElement =
    document.getElementById("tournamentName");

const watchLiveBtn =
    document.getElementById("watchLiveBtn");

const empty =
    document.getElementById("empty");

const errorElement =
    document.getElementById("error");


let currentTournamentId = null;
let currentMatchId = null;


// =====================================================
// GET TOURNAMENT ID
// =====================================================

function getTournamentId() {

    const params =
        new URLSearchParams(
            window.location.search
        );


    const urlId =
        params.get("tournamentId") ||
        params.get("tournament") ||
        params.get("tid");


    if (urlId) {

        localStorage.setItem(
            "tournamentId",
            urlId
        );

        return urlId;

    }


    return (
        localStorage.getItem("tournamentId") ||
        localStorage.getItem("currentTournamentId") ||
        localStorage.getItem("selectedTournamentId") ||
        null
    );

}


// =====================================================
// TEAM A
// =====================================================

function getTeamA(match) {

    return (
        match.teamAName ||
        match.team1Name ||
        match.teamA ||
        match.team1 ||
        match.homeTeam ||
        "Team A"
    );

}


// =====================================================
// TEAM B
// =====================================================

function getTeamB(match) {

    return (
        match.teamBName ||
        match.team2Name ||
        match.teamB ||
        match.team2 ||
        match.awayTeam ||
        "Team B"
    );

}


// =====================================================
// SCORE
// =====================================================

function getScoreA(match) {

    return (
        match.scoreA ||
        match.teamAScore ||
        match.team1Score ||
        match.firstInningsScore ||
        "0/0"
    );

}


function getScoreB(match) {

    return (
        match.scoreB ||
        match.teamBScore ||
        match.team2Score ||
        match.secondInningsScore ||
        "0/0"
    );

}


// =====================================================
// OVERS
// =====================================================

function getOversA(match) {

    return (
        match.oversA ||
        match.teamAOvers ||
        match.team1Overs ||
        ""
    );

}


function getOversB(match) {

    return (
        match.oversB ||
        match.teamBOvers ||
        match.team2Overs ||
        ""
    );

}


// =====================================================
// STATUS
// =====================================================

function getStatus(match) {

    return String(
        match.status ||
        match.matchStatus ||
        match.state ||
        "Scheduled"
    );

}


// =====================================================
// IS LIVE
// =====================================================

function isLive(match) {

    const status =
        getStatus(match)
            .toLowerCase()
            .trim();


    return (
        match.isLive === true ||
        match.live === true ||
        status === "live" ||
        status === "ongoing" ||
        status === "started" ||
        status === "playing" ||
        status === "running" ||
        status === "in progress" ||
        status === "in_progress"
    );

}


// =====================================================
// LOAD TOURNAMENT
// =====================================================

async function loadTournament(
    tournamentId
) {

    const ref =
        collection(
            db,
            "tournaments"
        );


    const snapshot =
        await getDocs(ref);


    const found =
        snapshot.docs.find(
            d =>
                d.id === tournamentId
        );


    if (!found) {

        return null;

    }


    return {

        id: found.id,

        ...found.data()

    };

}


// =====================================================
// LOAD MATCHES
// =====================================================

async function loadMatches(
    tournamentId
) {

    const ref =
        collection(
            db,
            "tournaments",
            tournamentId,
            "matches"
        );


    const snapshot =
        await getDocs(ref);


    console.log(
        "🏏 Matches found:",
        snapshot.size
    );


    const matches = [];


    snapshot.forEach(
        matchDoc => {

            matches.push({

                id: matchDoc.id,

                ...matchDoc.data()

            });

        }
    );


    console.log(
        "🏏 ALL MATCHES:",
        matches
    );


    return matches;

}


// =====================================================
// FIND MATCH
// =====================================================

function findMatch(matches) {

    // First priority = Live

    const liveMatch =
        matches.find(
            match =>
                isLive(match)
        );


    if (liveMatch) {

        console.log(
            "🔴 LIVE MATCH FOUND:",
            liveMatch
        );

        return liveMatch;

    }


    // If only one match exists,
    // show it as preview.

    if (matches.length === 1) {

        console.log(
            "🏏 ONE MATCH FOUND:",
            matches[0]
        );

        return matches[0];

    }


    return null;

}


// =====================================================
// DISPLAY MATCH
// =====================================================

function displayMatch(
    match,
    tournament
) {

    currentMatchId =
        match.id;


    const teamA =
        getTeamA(match);

    const teamB =
        getTeamB(match);

    const scoreA =
        getScoreA(match);

    const scoreB =
        getScoreB(match);

    const oversA =
        getOversA(match);

    const oversB =
        getOversB(match);

    const status =
        getStatus(match);

    const live =
        isLive(match);


    teamAElement.textContent =
        teamA;


    teamBElement.textContent =
        teamB;


    scoreAElement.textContent =
        scoreA;


    scoreBElement.textContent =
        scoreB;


    oversAElement.textContent =
        oversA
            ? `Overs: ${oversA}`
            : "";


    oversBElement.textContent =
        oversB
            ? `Overs: ${oversB}`
            : "";


    // Status

    matchStatus.textContent =
        live
            ? "🔴 LIVE"
            : `🏏 ${status}`;


    matchStatus.classList.toggle(
        "live",
        live
    );


    // Tournament

    tournamentNameElement.textContent =
        `🏆 ${
            tournament.name ||
            tournament.tournamentName ||
            tournament.title ||
            "CrickMate"
        }`;


    // Show card

    loading.style.display =
        "none";

    empty.style.display =
        "none";

    errorElement.style.display =
        "none";

    matchCard.style.display =
        "block";


    console.log(
        "✅ LIVE MATCH DISPLAYED"
    );

}


// =====================================================
// WATCH LIVE BUTTON
// =====================================================

watchLiveBtn.addEventListener(
    "click",
    () => {

        if (
            !currentTournamentId ||
            !currentMatchId
        ) {

            alert(
                "Match information not available."
            );

            return;

        }


        localStorage.setItem(
            "tournamentId",
            currentTournamentId
        );


        localStorage.setItem(
            "matchId",
            currentMatchId
        );


        const url =
            `./live-score.html` +
            `?tournamentId=${encodeURIComponent(
                currentTournamentId
            )}` +
            `&matchId=${encodeURIComponent(
                currentMatchId
            )}`;


        console.log(
            "🔴 WATCH LIVE:",
            url
        );


        window.location.href =
            url;

    }
);


// =====================================================
// REALTIME
// =====================================================

function listenMatch(
    tournamentId,
    matchId,
    tournament
) {

    console.log(
        "📡 Realtime listener:",
        matchId
    );


    const matchRef =
        doc(
            db,
            "tournaments",
            tournamentId,
            "matches",
            matchId
        );


    onSnapshot(
        matchRef,

        snapshot => {

            if (!snapshot.exists()) {

                return;

            }


            const match = {

                id: snapshot.id,

                ...snapshot.data()

            };


            console.log(
                "🔴 LIVE SCORE UPDATE:",
                match
            );


            displayMatch(
                match,
                tournament
            );

        },

        error => {

            console.error(
                "❌ REALTIME ERROR:",
                error
            );

        }
    );

}


// =====================================================
// START
// =====================================================

async function startGoLive() {

    try {

        loading.style.display =
            "block";


        matchCard.style.display =
            "none";


        const tournamentId =
            getTournamentId();


        console.log(
            "🏆 Tournament ID:",
            tournamentId
        );


        if (!tournamentId) {

            loading.style.display =
                "none";

            errorElement.style.display =
                "block";

            errorElement.textContent =
                "⚠️ Tournament ID missing.";

            return;

        }


        currentTournamentId =
            tournamentId;


        // Tournament

        const tournament =
            await loadTournament(
                tournamentId
            );


        if (!tournament) {

            loading.style.display =
                "none";

            errorElement.style.display =
                "block";

            errorElement.textContent =
                "❌ Tournament not found.";

            return;

        }


        console.log(
            "🏆 Tournament:",
            tournament
        );


        // Matches

        const matches =
            await loadMatches(
                tournamentId
            );


        if (
            !matches ||
            matches.length === 0
        ) {

            loading.style.display =
                "none";

            empty.style.display =
                "block";

            empty.textContent =
                "🏏 No matches found.";

            return;

        }


        // Find match

        const match =
            findMatch(matches);


        if (!match) {

            loading.style.display =
                "none";

            empty.style.display =
                "block";

            empty.textContent =
                "🏏 No live match right now.";

            return;

        }


        // Save

        localStorage.setItem(
            "tournamentId",
            tournamentId
        );


        localStorage.setItem(
            "matchId",
            match.id
        );


        // Display

        displayMatch(
            match,
            tournament
        );


        // Realtime

        listenMatch(
            tournamentId,
            match.id,
            tournament
        );


        console.log(
            "🚀 GO LIVE READY"
        );

    }

    catch (error) {

        console.error(
            "❌ GO LIVE ERROR:",
            error
        );


        loading.style.display =
            "none";


        errorElement.style.display =
            "block";


        errorElement.textContent =
            "❌ GO LIVE ERROR: " +
            error.message;

    }

}


// =====================================================
// START
// =====================================================

startGoLive();