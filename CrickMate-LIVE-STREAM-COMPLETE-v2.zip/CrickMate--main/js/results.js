// =====================================================
// CRICKMATE - RESULTS.JS
// MATCH RESULTS + WINNERS
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs,
    doc,
    getDoc,
    query,
    orderBy
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏆 CRICKMATE RESULT.JS STARTED");


// =====================================================
// URL PARAMETERS
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// ELEMENTS
// =====================================================

const resultsContainer =
    document.getElementById(
        "resultsContainer"
    );


const loading =
    document.getElementById(
        "loading"
    );


const message =
    document.getElementById(
        "message"
    );


const backBtn =
    document.getElementById(
        "backBtn"
    );


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "success"
) {

    if (!message) {
        return;
    }

    message.textContent =
        text;

    message.className =
        `message show ${type}`;

}


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            `dashboard.html?tournamentId=${encodeURIComponent(
                tournamentId
            )}`;

    }
    else {

        backBtn.href =
            "dashboard.html";

    }

}


// =====================================================
// VALIDATE
// =====================================================

if (!resultsContainer) {

    console.error(
        "❌ resultsContainer not found"
    );

}
else if (!tournamentId) {

    console.error(
        "❌ Tournament ID missing"
    );

    if (loading) {

        loading.style.display =
            "none";

    }

    showMessage(
        "Tournament ID missing.",
        "error"
    );

}
else {

    loadResults();

}


// =====================================================
// LOAD RESULTS
// =====================================================

async function loadResults() {

    console.log(
        "🚀 RESULT PAGE STARTING..."
    );

    try {

        if (loading) {

            loading.style.display =
                "block";

            loading.textContent =
                "🔄 Loading results...";

        }


        resultsContainer.innerHTML =
            "";


        // =================================================
        // FIRESTORE MATCHES PATH
        // =================================================

        const matchesRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "matches"
            );


        console.log(
            "📂 Loading matches from:",
            `tournaments/${tournamentId}/matches`
        );


        let snapshot;


        try {

            const matchesQuery =
                query(
                    matchesRef,
                    orderBy(
                        "matchDate",
                        "desc"
                    )
                );


            snapshot =
                await getDocs(
                    matchesQuery
                );

        }
        catch (orderError) {

            console.warn(
                "⚠️ orderBy failed. Loading without orderBy.",
                orderError
            );

            snapshot =
                await getDocs(
                    matchesRef
                );

        }


        console.log(
            "🏏 MATCH COUNT:",
            snapshot.size
        );


        if (snapshot.empty) {

            if (loading) {

                loading.style.display =
                    "none";

            }

            resultsContainer.innerHTML = `
                <div class="empty">
                    🏏 No match results available yet.
                </div>
            `;

            return;

        }


        const matches = [];


        snapshot.forEach(
            matchDoc => {

                const data =
                    matchDoc.data();


                matches.push({

                    id:
                        matchDoc.id,

                    ...data

                });

            }
        );


        // =================================================
        // SORT MATCHES
        // =================================================

        matches.sort(
            (a, b) => {

                const dateA =
                    String(
                        a.matchDate ||
                        a.date ||
                        ""
                    );

                const dateB =
                    String(
                        b.matchDate ||
                        b.date ||
                        ""
                    );

                return dateB.localeCompare(
                    dateA
                );

            }
        );


        // =================================================
        // DISPLAY ALL MATCHES
        // =================================================

        matches.forEach(
            (match, index) => {

                renderResult(
                    match,
                    index + 1
                );

            }
        );


        if (loading) {

            loading.style.display =
                "none";

        }


        console.log(
            "✅ RESULTS DISPLAYED:",
            matches.length
        );


        console.log(
            "✅ CRICKMATE RESULT.JS READY"
        );

    }
    catch (error) {

        console.error(
            "❌ RESULTS LOAD ERROR:",
            error
        );


        if (loading) {

            loading.style.display =
                "none";

        }


        resultsContainer.innerHTML = `
            <div class="empty">
                ❌ Results load nahi ho paaye.
                <br><br>
                ${escapeHtml(
                    error.message || ""
                )}
            </div>
        `;


        showMessage(
            error.message ||
            "Unable to load results.",
            "error"
        );

    }

}


// =====================================================
// RENDER RESULT
// =====================================================

function renderResult(
    match,
    index
) {

    if (!resultsContainer) {
        return;
    }


    const team1 =
        match.team1Name ||
        match.teamA ||
        match.team1 ||
        "Team 1";


    const team2 =
        match.team2Name ||
        match.teamB ||
        match.team2 ||
        "Team 2";


    const scoreA =
        formatScore(
            match.scoreA
        );


    const scoreB =
        formatScore(
            match.scoreB
        );


    const result =
        match.result ||
        "";


    const winner =
        match.winner ||
        getWinnerFromResult(
            result,
            team1,
            team2
        );


    const status =
        match.status ||
        (
            winner
            ? "Completed"
            : "Scheduled"
        );


    const date =
        match.matchDate ||
        match.date ||
        "";


    const matchNumber =
        match.matchNumber ||
        index;


    const card =
        document.createElement(
            "div"
        );


    card.className =
        "result-card";


    card.innerHTML = `

        <div class="match-number">
            🏏 Match ${escapeHtml(
                matchNumber
            )}
        </div>


        ${
            date
            ?
            `
            <div class="match-date">
                📅 ${escapeHtml(
                    formatDate(date)
                )}
            </div>
            `
            :
            ""
        }


        <div class="teams">


            <div class="team">

                <div class="team-name">
                    ${escapeHtml(
                        team1
                    )}
                </div>

                <div class="team-score">
                    ${escapeHtml(
                        scoreA
                    )}
                </div>

            </div>


            <div class="vs">
                VS
            </div>


            <div class="team">

                <div class="team-name">
                    ${escapeHtml(
                        team2
                    )}
                </div>

                <div class="team-score">
                    ${escapeHtml(
                        scoreB
                    )}
                </div>

            </div>


        </div>


        <div class="status">
            ${escapeHtml(
                status
            )}
        </div>


        ${
            winner
            ?
            `
            <div class="winner">
                🏆 ${escapeHtml(
                    winner
                )}
            </div>
            `
            :
            ""
        }


        ${
            result
            ?
            `
            <div class="result-text">
                ${escapeHtml(
                    result
                )}
            </div>
            `
            :
            `
            <div class="result-text">
                Result not available
            </div>
            `
        }

    `;


    resultsContainer.appendChild(
        card
    );

}


// =====================================================
// FORMAT SCORE
// =====================================================

function formatScore(
    value
) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "0/0";

    }


    if (
        typeof value === "object"
    ) {

        const runs =
            Number(
                value.runs || 0
            );


        const wickets =
            Number(
                value.wickets || 0
            );


        return `${runs}/${wickets}`;

    }


    return String(
        value
    );

}


// =====================================================
// GET WINNER
// =====================================================

function getWinnerFromResult(
    result,
    team1,
    team2
) {

    if (!result) {
        return "";
    }


    const text =
        String(result);


    if (
        text.toLowerCase()
            .includes(
                team1.toLowerCase()
            ) &&
        text.toLowerCase()
            .includes("won")
    ) {

        return team1;

    }


    if (
        text.toLowerCase()
            .includes(
                team2.toLowerCase()
            ) &&
        text.toLowerCase()
            .includes("won")
    ) {

        return team2;

    }


    if (
        text.toLowerCase()
            .includes("tie")
    ) {

        return "Tie";

    }


    return "";

}


// =====================================================
// FORMAT DATE
// =====================================================

function formatDate(
    value
) {

    if (!value) {
        return "";
    }


    const text =
        String(value);


    const parts =
        text.split("-");


    if (
        parts.length === 3
    ) {

        return `${parts[2]}-${parts[1]}-${parts[0]}`;

    }


    return text;

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}