// =====================================================
// CRICKMATE - LIVE-SCORE.JS
// COMPLETE BALL-BY-BALL SCORING
// Firebase Firestore SDK v12
// =====================================================

import { db } from "./firebase.js";

import {
    doc,
    getDoc,
    updateDoc,
    serverTimestamp,
    arrayUnion,
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE LIVE-SCORE.JS STARTED");


// =====================================================
// URL PARAMETERS
// =====================================================

const params = new URLSearchParams(window.location.search);

let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");

let matchId =
    params.get("matchId") ||
    params.get("match") ||
    localStorage.getItem("currentMatchId");


if (tournamentId) {
    tournamentId = tournamentId.trim();

    localStorage.setItem("tournamentId", tournamentId);
    localStorage.setItem("currentTournamentId", tournamentId);
}

if (matchId) {
    matchId = matchId.trim();

    localStorage.setItem("currentMatchId", matchId);
}


console.log("🏆 Tournament ID:", tournamentId);
console.log("🏏 Match ID:", matchId);


// =====================================================
// HTML ELEMENTS
// =====================================================

const loading = document.getElementById("loading");
const scorePage = document.getElementById("scorePage");
const message = document.getElementById("message");

const team1NameEl = document.getElementById("team1Name");
const team2NameEl = document.getElementById("team2Name");

const scoreAEl = document.getElementById("scoreA");
const scoreBEl = document.getElementById("scoreB");

const matchTitleEl = document.getElementById("matchTitle");
const matchStatusEl = document.getElementById("matchStatus");

const resultEl = document.getElementById("result");
const inningsInfoEl = document.getElementById("inningsInfo");

const currentOverEl = document.getElementById("currentOver");
const commentaryEl = document.getElementById("commentary");

const backBtn = document.getElementById("backBtn");

const strikerSelect = document.getElementById("striker");
const nonStrikerSelect = document.getElementById("nonStriker");
const bowlerSelect = document.getElementById("bowler");

const secondInningsBtn =
    document.getElementById("secondInningsBtn");

const scoreControlsCard =
    document.getElementById("scoreControlsCard");


// =====================================================
// GLOBAL VARIABLES
// =====================================================

let match = null;
let matchRef = null;

let localBalls = [];

let team1Players = [];
let team2Players = [];

let savingBall = false;


// =====================================================
// MESSAGE
// =====================================================

function showMessage(text, type = "success") {

    if (!message) {
        return;
    }

    message.textContent = text;

    message.className =
        "message show " + type;

}


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            "admin-matches.html?tournamentId=" +
            encodeURIComponent(tournamentId);

    } else {

        backBtn.href = "index.html";

    }

}


// =====================================================
// INITIAL VALIDATION
// =====================================================

if (!tournamentId) {

    showMessage(
        "Tournament ID missing.",
        "error"
    );

} else if (!matchId) {

    showMessage(
        "Match ID missing.",
        "error"
    );

} else {

    loadMatch();

}


// =====================================================
// LOAD MATCH
// =====================================================

async function loadMatch() {

    console.log("🔥 Loading match...");

    try {

        matchRef = doc(
            db,
            "tournaments",
            tournamentId,
            "matches",
            matchId
        );

        console.log(
            "📂 Firebase path:",
            "tournaments/" +
            tournamentId +
            "/matches/" +
            matchId
        );

        const snap = await getDoc(matchRef);

        if (!snap.exists()) {

            console.error("❌ MATCH NOT FOUND");

            if (loading) {
                loading.textContent =
                    "❌ Match not found.";
            }

            showMessage(
                "Match not found in Firebase.",
                "error"
            );

            return;
        }

        match = snap.data();

        console.log("✅ MATCH FOUND:", match);


        // ---------------------------------------------
        // LOAD BALLS
        // ---------------------------------------------

        localBalls =
            Array.isArray(match.balls)
                ? [...match.balls]
                : [];


        // ---------------------------------------------
        // RENDER MATCH
        // ---------------------------------------------

        renderMatch();


        // ---------------------------------------------
        // LOAD PLAYERS
        // ---------------------------------------------

        await loadPlayers();


        // ---------------------------------------------
        // HIDE LOADING
        // ---------------------------------------------

        if (loading) {
            loading.style.display = "none";
        }

        if (scorePage) {
            scorePage.style.display = "block";
        }


        console.log(
            "✅ CRICKMATE LIVE-SCORE.JS READY"
        );

    } catch (error) {

        console.error(
            "❌ MATCH LOAD ERROR:",
            error
        );

        showMessage(
            error.message ||
            "Unable to load match.",
            "error"
        );
    }
}


// =====================================================
// GET TEAM NAME
// =====================================================

function getTeamName(teamNumber) {

    if (!match) {
        return teamNumber === 1
            ? "Team 1"
            : "Team 2";
    }

    if (teamNumber === 1) {

        return (
            match.team1Name ||
            match.teamA ||
            match.team1 ||
            "Team 1"
        );

    }

    return (
        match.team2Name ||
        match.teamB ||
        match.team2 ||
        "Team 2"
    );
}


// =====================================================
// GET CURRENT INNINGS
// =====================================================

function getCurrentInnings() {

    if (!match) {
        return 1;
    }

    const innings = Number(
        match.currentInnings ||
        match.innings ||
        1
    );

    return innings >= 2 ? 2 : 1;
}


// =====================================================
// PARSE SCORE
// =====================================================

function parseScore(value) {

    if (
        value &&
        typeof value === "object"
    ) {

        return {
            runs: Number(value.runs || 0),
            wickets: Number(value.wickets || 0)
        };
    }


    const text = String(
        value || "0/0"
    );

    const parts = text.split("/");

    return {
        runs: Number(parts[0]) || 0,
        wickets: Number(parts[1]) || 0
    };
}


// =====================================================
// RENDER MATCH
// =====================================================

function renderMatch() {

    if (!match) {
        return;
    }

    const team1 = getTeamName(1);
    const team2 = getTeamName(2);

    const innings = getCurrentInnings();


    // ---------------------------------------------
    // TEAM NAMES
    // ---------------------------------------------

    if (team1NameEl) {
        team1NameEl.textContent = team1;
    }

    if (team2NameEl) {
        team2NameEl.textContent = team2;
    }


    // ---------------------------------------------
    // MATCH TITLE
    // ---------------------------------------------

    if (matchTitleEl) {

        matchTitleEl.textContent =
            match.matchNumber
                ? "Match " + match.matchNumber
                : "Match";
    }


    // ---------------------------------------------
    // SCORES
    // ---------------------------------------------

    if (scoreAEl) {

        scoreAEl.textContent =
            formatScore(match.scoreA);
    }

    if (scoreBEl) {

        scoreBEl.textContent =
            formatScore(match.scoreB);
    }


    // ---------------------------------------------
    // STATUS
    // ---------------------------------------------

    if (matchStatusEl) {

        matchStatusEl.textContent =
            match.status || "Scheduled";
    }


    // ---------------------------------------------
    // RESULT
    // ---------------------------------------------

    if (resultEl) {

        if (match.result) {

            resultEl.textContent =
                match.result;

        } else {

            resultEl.textContent =
                innings === 2
                    ? getTargetText()
                    : "First innings";
        }
    }


    // ---------------------------------------------
    // INNINGS INFO
    // ---------------------------------------------

    if (inningsInfoEl) {

        inningsInfoEl.textContent =
            "Innings " + innings;
    }


    // ---------------------------------------------
    // DISPLAY
    // ---------------------------------------------

    renderCurrentOver();

    renderCommentary();

    updateSecondInningsButton();

    updateScoreControlsVisibility();
}


// =====================================================
// FORMAT SCORE
// =====================================================

function formatScore(value) {

    const score = parseScore(value);

    return score.runs + "/" + score.wickets;
}


// =====================================================
// TARGET TEXT
// =====================================================

function getTargetText() {

    const firstScore =
        parseScore(match.scoreA);

    const secondScore =
        parseScore(match.scoreB);

    const target =
        firstScore.runs + 1;

    const remaining =
        Math.max(
            0,
            target - secondScore.runs
        );

    if (remaining === 0) {
        return "Target completed";
    }

    return (
        "Target: " +
        target +
        " | Need " +
        remaining +
        " runs"
    );
}


// =====================================================
// LOAD PLAYERS
// =====================================================

async function loadPlayers() {

    console.log("👥 Loading players...");

    team1Players = [];
    team2Players = [];


    try {

        if (match.team1Id) {

            team1Players =
                await loadTeamPlayers(
                    match.team1Id
                );
        }

        if (match.team2Id) {

            team2Players =
                await loadTeamPlayers(
                    match.team2Id
                );
        }


        console.log(
            "🏏 Team 1 Players:",
            team1Players
        );

        console.log(
            "🏏 Team 2 Players:",
            team2Players
        );


        populatePlayers();


        console.log(
            "✅ PLAYER DROPDOWNS POPULATED"
        );

    } catch (error) {

        console.error(
            "❌ PLAYER LOAD ERROR:",
            error
        );

        showMessage(
            "Players load nahi ho paaye.",
            "error"
        );
    }
}


// =====================================================
// LOAD ONE TEAM
// =====================================================

async function loadTeamPlayers(teamId) {

    const players = [];


    if (!teamId) {
        return players;
    }


    console.log(
        "👥 Loading Team:",
        "tournaments/" +
        tournamentId +
        "/teams/" +
        teamId
    );


    // =================================================
    // ADD PLAYER
    // =================================================

    function addPlayer(player, id = "") {

        let name = "";

        if (typeof player === "string") {

            name = player.trim();

        } else if (
            player &&
            typeof player === "object"
        ) {

            name = String(
                player.playerName ||
                player.name ||
                player.fullName ||
                player.displayName ||
                player.player ||
                player.player_name ||
                player.full_name ||
                ""
            ).trim();
        }


        if (!name) {
            return;
        }


        const exists = players.some(
            item =>
                item.name.toLowerCase() ===
                name.toLowerCase()
        );


        if (exists) {
            return;
        }


        players.push({

            id:
                id ||
                "player-" +
                players.length,

            name: name,

            role:
                player &&
                typeof player === "object"
                    ? (
                        player.role ||
                        player.playerRole ||
                        ""
                    )
                    : "",

            mobile:
                player &&
                typeof player === "object"
                    ? (
                        player.mobile ||
                        player.phone ||
                        ""
                    )
                    : ""
        });
    }


    // =================================================
    // TEAM DOCUMENT
    // =================================================

    const teamRef = doc(
        db,
        "tournaments",
        tournamentId,
        "teams",
        teamId
    );

    const teamSnap =
        await getDoc(teamRef);


    if (teamSnap.exists()) {

        const teamData =
            teamSnap.data();

        console.log(
            "📂 TEAM DATA:",
            teamData
        );


        // players[]
        if (Array.isArray(teamData.players)) {

            teamData.players.forEach(
                (player, index) => {

                    addPlayer(
                        player,
                        "array-" + index
                    );
                }
            );
        }


        // playerList[]
        if (Array.isArray(teamData.playerList)) {

            teamData.playerList.forEach(
                (player, index) => {

                    addPlayer(
                        player,
                        "playerList-" + index
                    );
                }
            );
        }


        // playerNames[]
        if (Array.isArray(teamData.playerNames)) {

            teamData.playerNames.forEach(
                (player, index) => {

                    addPlayer(
                        player,
                        "playerNames-" + index
                    );
                }
            );
        }


        // members[]
        if (Array.isArray(teamData.members)) {

            teamData.members.forEach(
                (player, index) => {

                    addPlayer(
                        player,
                        "members-" + index
                    );
                }
            );
        }


        // squad[]
        if (Array.isArray(teamData.squad)) {

            teamData.squad.forEach(
                (player, index) => {

                    addPlayer(
                        player,
                        "squad-" + index
                    );
                }
            );
        }


        // player1 - player15
        for (let i = 1; i <= 15; i++) {

            const key = "player" + i;

            if (teamData[key]) {

                addPlayer(
                    teamData[key],
                    key
                );
            }
        }


        // captain
        if (teamData.captainName) {

            addPlayer(
                {
                    name: teamData.captainName,
                    role: "Captain"
                },
                "captain"
            );
        }


        console.log(
            "👤 PLAYERS FROM TEAM DOCUMENT:",
            players
        );
    }


    // =================================================
    // PLAYERS SUBCOLLECTION
    // =================================================

    try {

        const playersRef = collection(
            db,
            "tournaments",
            tournamentId,
            "teams",
            teamId,
            "players"
        );

        const playersSnap =
            await getDocs(playersRef);


        playersSnap.forEach(
            playerDoc => {

                addPlayer(
                    playerDoc.data(),
                    playerDoc.id
                );
            }
        );


        console.log(
            "👤 PLAYERS AFTER SUBCOLLECTION:",
            players
        );

    } catch (error) {

        console.warn(
            "⚠️ Player subcollection error:",
            error
        );
    }


    return players;
}


// =====================================================
// POPULATE PLAYERS
// =====================================================

function populatePlayers() {

    if (!match) {
        return;
    }

    const innings =
        getCurrentInnings();


    if (innings === 1) {

        fillSelect(
            strikerSelect,
            team1Players,
            "Select Striker"
        );

        fillSelect(
            nonStrikerSelect,
            team1Players,
            "Select Non-Striker"
        );

        fillSelect(
            bowlerSelect,
            team2Players,
            "Select Bowler"
        );

    } else {

        fillSelect(
            strikerSelect,
            team2Players,
            "Select Striker"
        );

        fillSelect(
            nonStrikerSelect,
            team2Players,
            "Select Non-Striker"
        );

        fillSelect(
            bowlerSelect,
            team1Players,
            "Select Bowler"
        );
    }
}


// =====================================================
// FILL SELECT
// =====================================================

function fillSelect(
    select,
    players,
    placeholder
) {

    if (!select) {
        return;
    }

    select.innerHTML = "";


    const firstOption =
        document.createElement("option");

    firstOption.value = "";
    firstOption.textContent =
        placeholder;

    select.appendChild(firstOption);


    players.forEach(player => {

        const option =
            document.createElement("option");

        option.value = player.name;
        option.textContent = player.name;

        select.appendChild(option);
    });
}


// =====================================================
// PLAYER VALIDATION
// =====================================================

function validatePlayers() {

    if (
        strikerSelect &&
        !strikerSelect.value
    ) {

        showMessage(
            "Please select Striker.",
            "error"
        );

        return false;
    }


    if (
        nonStrikerSelect &&
        !nonStrikerSelect.value
    ) {

        showMessage(
            "Please select Non-Striker.",
            "error"
        );

        return false;
    }


    if (
        bowlerSelect &&
        !bowlerSelect.value
    ) {

        showMessage(
            "Please select Bowler.",
            "error"
        );

        return false;
    }


    if (
        strikerSelect &&
        nonStrikerSelect &&
        strikerSelect.value ===
        nonStrikerSelect.value
    ) {

        showMessage(
            "Striker aur Non-Striker same nahi ho sakte.",
            "error"
        );

        return false;
    }


    return true;
}


// =====================================================
// PLAYER CHANGE VALIDATION
// =====================================================

if (strikerSelect) {

    strikerSelect.addEventListener(
        "change",
        function () {

            if (
                nonStrikerSelect &&
                strikerSelect.value &&
                strikerSelect.value ===
                nonStrikerSelect.value
            ) {

                nonStrikerSelect.value = "";

                showMessage(
                    "Striker aur Non-Striker same nahi ho sakte.",
                    "error"
                );
            }
        }
    );
}


if (nonStrikerSelect) {

    nonStrikerSelect.addEventListener(
        "change",
        function () {

            if (
                strikerSelect &&
                nonStrikerSelect.value &&
                strikerSelect.value ===
                nonStrikerSelect.value
            ) {

                nonStrikerSelect.value = "";

                showMessage(
                    "Striker aur Non-Striker same nahi ho sakte.",
                    "error"
                );
            }
        }
    );
}


// =====================================================
// GLOBAL ADD RUNS
// =====================================================

window.addRuns = async function (runs) {

    await saveBall(
        Number(runs),
        false
    );
};


// =====================================================
// GLOBAL WICKET
// =====================================================

window.addWicket = async function () {

    await saveBall(
        0,
        true
    );
};


// =====================================================
// SAVE BALL
// =====================================================

async function saveBall(runs, wicket) {

    if (savingBall) {
        return;
    }

    if (!match || !matchRef) {

        showMessage(
            "Match is not loaded.",
            "error"
        );

        return;
    }


    const status =
        String(match.status || "")
            .toLowerCase()
            .trim();


    if (status === "completed") {

        showMessage(
            "Match is already completed.",
            "error"
        );

        return;
    }


    if (!validatePlayers()) {
        return;
    }


    savingBall = true;


    try {

        runs = Number(runs) || 0;

        const innings =
            getCurrentInnings();


        // =================================================
        // SCORE
        // =================================================

        const scoreField =
            innings === 2
                ? "scoreB"
                : "scoreA";


        const currentScore =
            parseScore(match[scoreField]);


        const newRuns =
            currentScore.runs + runs;


        const newWickets =
            currentScore.wickets +
            (wicket ? 1 : 0);


// =================================================
        // OVER
        // =================================================

        const currentOver =
            Number(match.currentOver || 0);


        const currentBall =
            Number(match.currentBall || 0);


        const ballNumber =
            currentBall + 1;


        const ballDisplay =
            currentOver +
            "." +
            ballNumber;


        let newOver =
            currentOver;


        let newBall =
            ballNumber;


        if (newBall >= 6) {

            newOver =
                currentOver + 1;

            newBall = 0;
        }


        // =================================================
        // BATTING TEAM
        // =================================================

        const battingTeam =
            innings === 2
                ? getTeamName(2)
                : getTeamName(1);


        // =================================================
        // COMMENTARY
        // =================================================

        let commentaryText = "";


        if (wicket) {

            commentaryText =
                battingTeam +
                " - WICKET";

        } else if (runs === 0) {

            commentaryText =
                battingTeam +
                " - Dot ball";

        } else if (runs === 4) {

            commentaryText =
                battingTeam +
                " - FOUR";

        } else if (runs === 6) {

            commentaryText =
                battingTeam +
                " - SIX";

        } else {

            commentaryText =
                battingTeam +
                " - " +
                runs +
                " run" +
                (runs === 1 ? "" : "s");
        }


        // =================================================
        // BALL OBJECT
        // =================================================

        const ballObject = {

            number: ballDisplay,

            over: currentOver,

            ball: ballNumber,

            innings: innings,

            runs: runs,

            wicket: wicket,

            striker:
                strikerSelect
                    ? strikerSelect.value
                    : "",

            nonStriker:
                nonStrikerSelect
                    ? nonStrikerSelect.value
                    : "",

            bowler:
                bowlerSelect
                    ? bowlerSelect.value
                    : "",

            commentary:
                commentaryText,

            timestamp:
                new Date().toISOString()
        };


        // =================================================
        // FIRESTORE DATA
        // =================================================

        const updateData = {

            [scoreField]:
                newRuns +
                "/" +
                newWickets,

            currentOver:
                newOver,

            currentBall:
                newBall,

            status:
                "Live",

            updatedAt:
                serverTimestamp(),

            balls:
                arrayUnion(ballObject)
        };


        // =================================================
        // FIRST INNINGS
        // =================================================

        if (innings === 1) {

            updateData.firstInningsRuns =
                newRuns;

            updateData.firstInningsWickets =
                newWickets;

            updateData.firstInningsScore =
                newRuns +
                "/" +
                newWickets;

            updateData.firstInningsBalls =
                Number(
                    match.firstInningsBalls || 0
                ) + 1;
        }


        // =================================================
        // SECOND INNINGS
        // =================================================

        if (innings === 2) {

            updateData.secondInningsRuns =
                newRuns;

            updateData.secondInningsWickets =
                newWickets;

            updateData.secondInningsScore =
                newRuns +
                "/" +
                newWickets;

            updateData.secondInningsBalls =
                Number(
                    match.secondInningsBalls || 0
                ) + 1;
        }


        // =================================================
        // SAVE FIRESTORE
        // =================================================

        await updateDoc(
            matchRef,
            updateData
        );


// =================================================
        // LOCAL UPDATE
        // =================================================

        match[scoreField] =
            newRuns +
            "/" +
            newWickets;

        match.currentOver =
            newOver;

        match.currentBall =
            newBall;

        match.status =
            "Live";


        if (innings === 1) {

            match.firstInningsRuns =
                newRuns;

            match.firstInningsWickets =
                newWickets;

            match.firstInningsBalls =
                Number(
                    match.firstInningsBalls || 0
                ) + 1;
        }


        if (innings === 2) {

            match.secondInningsRuns =
                newRuns;

            match.secondInningsWickets =
                newWickets;

            match.secondInningsBalls =
                Number(
                    match.secondInningsBalls || 0
                ) + 1;
        }


        localBalls.push(ballObject);


        // =================================================
        // RENDER
        // =================================================

        renderMatch();


        // =================================================
        // SECOND INNINGS CHASE
        // =================================================

        if (innings === 2) {

            const firstScore =
                parseScore(match.scoreA);


            if (
                newRuns >
                firstScore.runs
            ) {

                await finishMatch();

                return;
            }
        }


        // =================================================
        // ALL OUT
        // =================================================

        if (newWickets >= 10) {

            if (innings === 1) {

                showMessage(
                    "🏏 Innings 1 completed. Start second innings.",
                    "success"
                );

            } else {

                await finishMatch();
            }

            return;
        }


        // =================================================
        // SUCCESS MESSAGE
        // =================================================

        if (wicket) {

            showMessage(
                "🟥 Wicket recorded.",
                "success"
            );

        } else {

            showMessage(
                "✅ " +
                runs +
                " run" +
                (runs === 1 ? "" : "s") +
                " recorded.",
                "success"
            );
        }


    } catch (error) {

        console.error(
            "❌ SAVE BALL ERROR:",
            error
        );

        showMessage(
            error.message ||
            "Unable to save ball.",
            "error"
        );

    } finally {

        savingBall = false;
    }
}


// =====================================================
// START SECOND INNINGS
// =====================================================

window.startSecondInnings =
async function () {

    if (!match || !matchRef) {
        return;
    }


    const innings =
        getCurrentInnings();


    if (innings >= 2) {

        showMessage(
            "Second innings already started.",
            "error"
        );

        return;
    }


    if (
        String(match.status || "")
            .toLowerCase() ===
        "completed"
    ) {

        showMessage(
            "Match already completed.",
            "error"
        );

        return;
    }


    const firstScore =
        parseScore(match.scoreA);


    try {

        await updateDoc(
            matchRef,
            {

                currentInnings: 2,

                innings: 2,

                currentOver: 0,

                currentBall: 0,

                scoreB:
                    "0/0",

                secondInningsRuns: 0,

                secondInningsWickets: 0,

                secondInningsBalls: 0,

                status: "Live",

                updatedAt:
                    serverTimestamp()
            }
        );


        match.currentInnings = 2;
        match.innings = 2;

        match.currentOver = 0;
        match.currentBall = 0;

        match.scoreB = "0/0";

        match.secondInningsRuns = 0;
        match.secondInningsWickets = 0;
        match.secondInningsBalls = 0;

        match.status = "Live";


        populatePlayers();

        renderMatch();


        showMessage(
            "🔄 Second innings started. Target: " +
            (firstScore.runs + 1) +
            " runs.",
            "success"
        );


    } catch (error) {

        console.error(
            "❌ SECOND INNINGS ERROR:",
            error
        );

        showMessage(
            error.message ||
            "Unable to start second innings.",
            "error"
        );
    }
};


// =====================================================
// SECOND INNINGS BUTTON
// =====================================================

function updateSecondInningsButton() {

    if (!secondInningsBtn) {
        return;
    }


    const innings =
        getCurrentInnings();


    if (
        innings >= 2 ||
        String(match?.status || "")
            .toLowerCase() ===
        "completed"
    ) {

        secondInningsBtn.style.display =
            "none";

    } else {

        secondInningsBtn.style.display =
            "block";
    }
}


// =====================================================
// FINISH MATCH
// =====================================================

async function finishMatch() {

    if (!match || !matchRef) {
        return;
    }


    const scoreA =
        parseScore(match.scoreA);

    const scoreB =
        parseScore(match.scoreB);


    let winner = "";
    let result = "";


    // =================================================
    // TEAM 2 WON
    // =================================================

    if (scoreB.runs > scoreA.runs) {

        winner =
            getTeamName(2);

        const wicketsRemaining =
            Math.max(
                0,
                10 - scoreB.wickets
            );

        result =
            winner +
            " won by " +
            wicketsRemaining +
            " wickets";


    // =================================================
    // TEAM 1 WON
    // =================================================

    } else if (scoreA.runs > scoreB.runs) {

        winner =
            getTeamName(1);

        result =
            winner +
            " won by " +
            (scoreA.runs - scoreB.runs) +
            " runs";


    // =================================================
    // TIE
    // =================================================

    } else {

        winner = "Tie";

        result =
            "Match tied";
    }


    try {

        await updateDoc(
            matchRef,
            {

                status: "Completed",

                winner: winner,

                result: result,

                updatedAt:
                    serverTimestamp()
            }
        );


        match.status =
            "Completed";

        match.winner =
            winner;

        match.result =
            result;


        renderMatch();


        showMessage(
            "🏆 " + result,
            "success"
        );


    } catch (error) {

        console.error(
            "❌ FINISH MATCH ERROR:",
            error
        );

        showMessage(
            error.message ||
            "Unable to finish match.",
            "error"
        );
    }
}


// =====================================================
// COMPLETE MATCH BUTTON
// =====================================================

window.completeMatch =
async function () {

    if (!match || !matchRef) {
        return;
    }


    const innings =
        getCurrentInnings();


    if (innings === 1) {

        showMessage(
            "Please start second innings before completing the match.",
            "error"
        );

        return;
    }


    await finishMatch();
};


// =====================================================
// UNDO LAST BALL
// =====================================================

window.undoBall =
async function () {

    if (!match || !matchRef) {
        return;
    }


    if (!localBalls.length) {

        showMessage(
            "No ball to undo.",
            "error"
        );

        return;
    }


    if (
        String(match.status || "")
            .toLowerCase() ===
        "completed"
    ) {

        showMessage(
            "Completed match cannot be edited.",
            "error"
        );

        return;
    }


    const lastBall =
        localBalls[
            localBalls.length - 1
        ];


    const innings =
        Number(lastBall.innings || 1);


    const scoreField =
        innings === 2
            ? "scoreB"
            : "scoreA";


    const currentScore =
        parseScore(match[scoreField]);


    const newRuns =
        Math.max(
            0,
            currentScore.runs -
            Number(lastBall.runs || 0)
        );


    const newWickets =
        Math.max(
            0,
            currentScore.wickets -
            (lastBall.wicket ? 1 : 0)
        );


    const remainingBalls =
        localBalls.slice(0, -1);


    // =================================================
    // RECALCULATE INNINGS BALLS
    // =================================================

    const inningsBalls =
        remainingBalls.filter(
            ball =>
                Number(ball.innings) ===
                innings
        );


    let newOver = 0;
    let newBall = 0;


    if (inningsBalls.length) {

        const lastRemaining =
            inningsBalls[
                inningsBalls.length - 1
            ];


        newOver =
            Number(
                lastRemaining.over || 0
            );


        newBall =
            Number(
                lastRemaining.ball || 0
            );


        if (newBall >= 6) {

            newOver += 1;
            newBall = 0;
        }
    }


    try {

        const updateData = {

            [scoreField]:
                newRuns +
                "/" +
                newWickets,

            balls:
                remainingBalls,

            currentOver:
                newOver,

            currentBall:
                newBall,

            status:
                "Live",

            updatedAt:
                serverTimestamp()
        };


        if (innings === 1) {

            updateData.firstInningsRuns =
                newRuns;

            updateData.firstInningsWickets =
                newWickets;

            updateData.firstInningsBalls =
                inningsBalls.length;

        } else {

            updateData.secondInningsRuns =
                newRuns;

            updateData.secondInningsWickets =
                newWickets;

            updateData.secondInningsBalls =
                inningsBalls.length;
        }


        await updateDoc(
            matchRef,
            updateData
        );


        localBalls =
            remainingBalls;


        match[scoreField] =
            newRuns +
            "/" +
            newWickets;


        match.currentOver =
            newOver;

        match.currentBall =
            newBall;

        match.status =
            "Live";


        if (innings === 1) {

            match.firstInningsRuns =
                newRuns;

            match.firstInningsWickets =
                newWickets;

            match.firstInningsBalls =
                inningsBalls.length;

        } else {

            match.secondInningsRuns =
                newRuns;

            match.secondInningsWickets =
                newWickets;

            match.secondInningsBalls =
                inningsBalls.length;
        }


        renderMatch();


        showMessage(
            "↩ Last ball removed.",
            "success"
        );


    } catch (error) {

        console.error(
            "❌ UNDO ERROR:",
            error
        );

        showMessage(
            error.message ||
            "Unable to undo ball.",
            "error"
        );
    }
};


// =====================================================
// CURRENT OVER
// =====================================================

function renderCurrentOver() {

    if (!currentOverEl) {
        return;
    }


    if (!localBalls.length) {

        currentOverEl.textContent =
            "No balls yet.";

        return;
    }


    const innings =
        getCurrentInnings();


    const inningsBalls =
        localBalls.filter(
            ball =>
                Number(ball.innings) ===
                innings
        );


    if (!inningsBalls.length) {

        currentOverEl.textContent =
            "No balls yet.";

        return;
    }


    const lastOver =
        Number(
            inningsBalls[
                inningsBalls.length - 1
            ].over || 0
        );


    const overBalls =
        inningsBalls.filter(
            ball =>
                Number(ball.over || 0) ===
                lastOver
        );


    currentOverEl.innerHTML =
        overBalls
            .map(ball => {

                if (ball.wicket) {
                    return "🟥 W";
                }

                return String(
                    Number(ball.runs || 0)
                );

            })
            .join(" • ");
}


// =====================================================
// COMMENTARY
// =====================================================

function renderCommentary() {

    if (!commentaryEl) {
        return;
    }


    if (!localBalls.length) {

        commentaryEl.textContent =
            "No commentary yet.";

        return;
    }


    commentaryEl.innerHTML =
        [...localBalls]
            .reverse()
            .map(ball => {

                const icon =
                    ball.wicket
                        ? "🟥"
                        : "🏏";


                return `
                    <div style="
                        padding:10px;
                        margin-bottom:8px;
                        background:#f8fafc;
                        border-radius:8px;
                        border:1px solid #e2e8f0;
                    ">

                        <strong>
                            ${icon}
                            Ball ${escapeHtml(ball.number)}
                        </strong>

                        <br>

                        ${escapeHtml(
                            ball.commentary || ""
                        )}

                        ${
                            ball.striker
                            ? `
                                <br>
                                <small>
                                    🏏 Striker:
                                    ${escapeHtml(
                                        ball.striker
                                    )}
                                </small>
                              `
                            : ""
                        }

                        ${
                            ball.nonStriker
                            ? `
                                <br>
                                <small>
                                    🏏 Non-Striker:
                                    ${escapeHtml(
                                        ball.nonStriker
                                    )}
                                </small>
                              `
                            : ""
                        }

                        ${
                            ball.bowler
                            ? `
                                <br>
                                <small>
                                    🎯 Bowler:
                                    ${escapeHtml(
                                        ball.bowler
                                    )}
                                </small>
                              `
                            : ""
                        }

                    </div>
                `;
            })
            .join("");
}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";
    }


    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


// =====================================================
// SCORE CONTROLS VISIBILITY
// =====================================================

function updateScoreControlsVisibility() {

    if (!scoreControlsCard) {
        return;
    }


    const status =
        String(
            match?.status || ""
        )
            .toLowerCase()
            .trim();


    if (status === "completed") {

        scoreControlsCard.style.display =
            "none";

        console.log(
            "🔒 MATCH COMPLETED - SCORE CONTROLS HIDDEN"
        );

    } else {

        scoreControlsCard.style.display =
            "block";

        console.log(
            "🔓 MATCH LIVE - SCORE CONTROLS VISIBLE"
        );
    }
}


// =====================================================
// FINAL LOG
// =====================================================

console.log(
    "✅ CRICKMATE BALL-BY-BALL LIVE-SCORE.JS LOADED"
);