// =====================================================
// CRICKMATE - CREATE MATCH.JS
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs,
    addDoc,
    doc,
    getDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE CREATE-MATCH.JS STARTED");


// =====================================================
// GET TOURNAMENT ID
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// ELEMENTS
// =====================================================

const form =
    document.getElementById("matchForm");

const team1Select =
    document.getElementById("team1");

const team2Select =
    document.getElementById("team2");

const matchNumberInput =
    document.getElementById("matchNumber");

const matchDateInput =
    document.getElementById("matchDate");

const matchTimeInput =
    document.getElementById("matchTime");

const oversInput =
    document.getElementById("overs");

const venueInput =
    document.getElementById("venue");

const createBtn =
    document.getElementById("createBtn");

const message =
    document.getElementById("message");

const tournamentInfo =
    document.getElementById("tournamentInfo");

const backBtn =
    document.getElementById("backBtn");


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            `tournament.html?id=${encodeURIComponent(
                tournamentId
            )}`;

    }
    else {

        backBtn.href =
            "my-tournaments.html";

    }

}


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "info"
) {

    if (!message) {
        return;
    }

    message.className =
        `message ${type}`;

    message.textContent =
        text;

}


// =====================================================
// START
// =====================================================

if (!tournamentId) {

    showMessage(
        "❌ Tournament ID missing. Please open Create Match from Tournament Centre.",
        "error"
    );


    if (createBtn) {

        createBtn.disabled =
            true;

    }

}
else {

    loadTournament();

    loadTeams();

}


// =====================================================
// LOAD TOURNAMENT
// =====================================================

async function loadTournament() {

    try {

        console.log(
            "🔥 Loading tournament:",
            tournamentId
        );


        const tournamentRef =
            doc(
                db,
                "tournaments",
                tournamentId
            );


        const tournamentSnap =
            await getDoc(
                tournamentRef
            );


        if (!tournamentSnap.exists()) {

            console.error(
                "❌ Tournament does not exist"
            );


            showMessage(
                "❌ Tournament not found.",
                "error"
            );


            if (createBtn) {

                createBtn.disabled =
                    true;

            }


            return;

        }


        const tournament =
            tournamentSnap.data();


        console.log(
            "✅ Tournament:",
            tournament
        );


        const tournamentName =
            tournament.tournamentName ||
            tournament.name ||
            "Unnamed Tournament";


        const venue =
            tournament.venue ||
            "";


        if (tournamentInfo) {

            tournamentInfo.innerHTML = `

                🏆
                <strong>
                    ${escapeHtml(
                        tournamentName
                    )}
                </strong>

                <br>

                <small>
                    Tournament ID:
                    ${escapeHtml(
                        tournamentId
                    )}
                </small>

            `;

        }


        if (
            venueInput &&
            !venueInput.value &&
            venue
        ) {

            venueInput.value =
                venue;

        }

    }
    catch (error) {

        console.error(
            "❌ Tournament load error:",
            error
        );


        showMessage(
            error.message ||
            "Unable to load tournament.",
            "error"
        );

    }

}


// =====================================================
// LOAD TEAMS
// =====================================================

async function loadTeams() {

    console.log(
        "👥 Loading teams..."
    );


    try {

        const teamsRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "teams"
            );


        const snapshot =
            await getDocs(
                teamsRef
            );


        console.log(
            "👥 TEAMS FOUND:",
            snapshot.size
        );


        if (
            !team1Select ||
            !team2Select
        ) {

            console.error(
                "❌ Team select elements not found"
            );

            return;

        }


        team1Select.innerHTML = `

            <option value="">
                Select Team 1
            </option>

        `;


        team2Select.innerHTML = `

            <option value="">
                Select Team 2
            </option>

        `;


        if (snapshot.empty) {

            team1Select.innerHTML = `

                <option value="">
                    No teams available
                </option>

            `;


            team2Select.innerHTML = `

                <option value="">
                    No teams available
                </option>

            `;


            if (createBtn) {

                createBtn.disabled =
                    true;

            }


            showMessage(
                "❌ No teams found. Please create at least 2 teams first.",
                "error"
            );


            return;

        }


        snapshot.forEach(
            teamDoc => {

                const team =
                    teamDoc.data();


                const teamId =
                    teamDoc.id;


                const teamName =
                    team.teamName ||
                    team.name ||
                    team.title ||
                    "Unnamed Team";


                // =========================================
                // TEAM 1
                // =========================================

                const option1 =
                    document.createElement(
                        "option"
                    );


                option1.value =
                    teamId;


                option1.textContent =
                    teamName;


                option1.dataset.name =
                    teamName;


                team1Select.appendChild(
                    option1
                );


                // =========================================
                // TEAM 2
                // =========================================

                const option2 =
                    document.createElement(
                        "option"
                    );


                option2.value =
                    teamId;


                option2.textContent =
                    teamName;


                option2.dataset.name =
                    teamName;


                team2Select.appendChild(
                    option2
                );

            }
        );


        if (snapshot.size < 2) {

            showMessage(
                "❌ At least 2 teams are required to create a match.",
                "error"
            );


            if (createBtn) {

                createBtn.disabled =
                    true;

            }

        }
        else {

            if (createBtn) {

                createBtn.disabled =
                    false;

            }

        }

    }
    catch (error) {

        console.error(
            "❌ Team loading error:",
            error
        );


        showMessage(
            error.message ||
            "Unable to load teams.",
            "error"
        );

    }

}


// =====================================================
// PREVENT SAME TEAM
// =====================================================

if (team1Select) {

    team1Select.addEventListener(
        "change",
        () => {

            const selected =
                team1Select.value;


            if (!team2Select) {
                return;
            }


            Array.from(
                team2Select.options
            ).forEach(
                option => {

                    if (
                        option.value &&
                        option.value ===
                        selected
                    ) {

                        option.disabled =
                            true;

                    }
                    else {

                        option.disabled =
                            false;

                    }

                }
            );


            if (
                team2Select.value ===
                selected
            ) {

                team2Select.value =
                    "";

            }

        }
    );

}


// =====================================================
// FORM SUBMIT
// =====================================================

if (form) {

    form.addEventListener(
        "submit",
        async event => {

            event.preventDefault();


            console.log(
                "🏏 CREATE MATCH CLICKED"
            );


            if (!tournamentId) {

                showMessage(
                    "❌ Tournament ID missing.",
                    "error"
                );

                return;

            }


            // =================================================
            // VALUES
            // =================================================

            const team1Id =
                team1Select.value;


            const team2Id =
                team2Select.value;


            const matchNumber =
                Number(
                    matchNumberInput.value
                );


            const matchDate =
                matchDateInput.value;


            const matchTime =
                matchTimeInput.value;


            const overs =
                Number(
                    oversInput.value
                );


            const venue =
                venueInput.value.trim();


            // =================================================
            // VALIDATION
            // =================================================

            if (!team1Id) {

                showMessage(
                    "❌ Please select Team 1.",
                    "error"
                );

                return;

            }


            if (!team2Id) {

                showMessage(
                    "❌ Please select Team 2.",
                    "error"
                );

                return;

            }


            if (
                team1Id ===
                team2Id
            ) {

                showMessage(
                    "❌ Team 1 and Team 2 cannot be the same.",
                    "error"
                );

                return;

            }


            if (
                !matchNumber ||
                matchNumber < 1
            ) {

                showMessage(
                    "❌ Please enter a valid match number.",
                    "error"
                );

                return;

            }


            if (!matchDate) {

                showMessage(
                    "❌ Please select match date.",
                    "error"
                );

                return;

            }


            if (!matchTime) {

                showMessage(
                    "❌ Please select match time.",
                    "error"
                );

                return;

            }


            if (
                !overs ||
                overs < 1
            ) {

                showMessage(
                    "❌ Please enter valid overs.",
                    "error"
                );

                return;

            }


            // =================================================
            // TEAM NAMES
            // =================================================

            const team1Option =
                team1Select.options[
                    team1Select.selectedIndex
                ];


            const team2Option =
                team2Select.options[
                    team2Select.selectedIndex
                ];


            const team1Name =
                team1Option.dataset.name ||
                team1Option.textContent;


            const team2Name =
                team2Option.dataset.name ||
                team2Option.textContent;


            // =================================================
            // DISABLE
            // =================================================

            if (createBtn) {

                createBtn.disabled =
                    true;

                createBtn.textContent =
                    "Creating Match...";

            }


            showMessage(
                "💾 Creating match...",
                "success"
            );


            try {

                // =================================================
                // LOG
                // =================================================

                console.log(
                    "💾 Saving match..."
                );


                console.log(
                    "🏆 Tournament:",
                    tournamentId
                );


                console.log(
                    "👥 Team 1:",
                    team1Id,
                    team1Name
                );


                console.log(
                    "👥 Team 2:",
                    team2Id,
                    team2Name
                );


                // =================================================
                // MATCH DATA
                // =================================================

                const matchData = {

                    tournamentId:
                        tournamentId,

                    matchNumber:
                        matchNumber,

                    team1Id:
                        team1Id,

                    team1Name:
                        team1Name,

                    team2Id:
                        team2Id,

                    team2Name:
                        team2Name,

                    teamA:
                        team1Name,

                    teamB:
                        team2Name,

                    scoreA:
                        "0/0",

                    scoreB:
                        "0/0",

                    date:
                        matchDate,

                    matchDate:
                        matchDate,

                    time:
                        matchTime,

                    matchTime:
                        matchTime,

                    overs:
                        overs,

                    venue:
                        venue,

                    status:
                        "Scheduled",

                    result:
                        "",

                    winner:
                        "",

                    innings:
                        1,

                    currentInnings:
                        1,

                    currentOver:
                        0,

                    currentBall:
                        0,

                    totalRuns:
                        0,

                    totalWickets:
                        0,

                    secondInningsScore:
                        "",

                    secondInningsRuns:
                        0,

                    secondInningsWickets:
                        0,

                    createdAt:
                        serverTimestamp(),

                    updatedAt:
                        serverTimestamp()

                };


                // =================================================
                // FIRESTORE PATH
                // =================================================

                const matchesRef =
                    collection(
                        db,
                        "tournaments",
                        tournamentId,
                        "matches"
                    );


                console.log(
                    "📂 SAVE PATH:",
                    `tournaments/${tournamentId}/matches`
                );


                // =================================================
                // SAVE
                // =================================================

                const newMatch =
                    await addDoc(
                        matchesRef,
                        matchData
                    );


                console.log(
                    "✅ MATCH CREATED:",
                    newMatch.id
                );


                console.log(
                    "📂 FULL MATCH PATH:",
                    `tournaments/${tournamentId}/matches/${newMatch.id}`
                );


                // =================================================
                // VERIFY SAVE
                // =================================================

                const verifyRef =
                    doc(
                        db,
                        "tournaments",
                        tournamentId,
                        "matches",
                        newMatch.id
                    );


                const verifySnap =
                    await getDoc(
                        verifyRef
                    );


                if (!verifySnap.exists()) {

                    throw new Error(
                        "Match was created but could not be verified."
                    );

                }


                console.log(
                    "✅ MATCH SAVE VERIFIED:",
                    verifySnap.data()
                );


                // =================================================
                // SUCCESS
                // =================================================

                showMessage(
                    `✅ Match ${matchNumber} created successfully!`,
                    "success"
                );


// =================================================
                // REDIRECT ADMIN MATCHES
                // =================================================

                setTimeout(
                    () => {

                        window.location.href =
                            `admin-matches.html?tournamentId=${encodeURIComponent(
                                tournamentId
                            )}`;

                    },
                    800
                );

            }
            catch (error) {

                console.error(
                    "❌ MATCH CREATE ERROR:",
                    error
                );


                showMessage(
                    error.message ||
                    "Failed to create match.",
                    "error"
                );


                if (createBtn) {

                    createBtn.disabled =
                        false;

                    createBtn.textContent =
                        "🏏 Create Match";

                }

            }

        }
    );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE CREATE-MATCH.JS READY"
);