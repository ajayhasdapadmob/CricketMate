// =====================================================
// CRICKMATE - CRICKET FEED.JS
// LIVE + COMPLETED + SCHEDULED MATCH FEED
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs,
    query,
    orderBy,
    limit
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("📰 CRICKMATE CRICKET-FEED.JS STARTED");


// =====================================================
// ELEMENTS
// =====================================================

const feedEl =
    document.getElementById("feed");

const loadingEl =
    document.getElementById("loading");

const errorEl =
    document.getElementById("error");


// =====================================================
// URL + LOCAL STORAGE
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// SHOW ERROR
// =====================================================

function showError(text) {

    if (!errorEl) {
        return;
    }

    errorEl.textContent =
        text;

    errorEl.classList.add(
        "show"
    );

}


// =====================================================
// HIDE ERROR
// =====================================================

function hideError() {

    if (!errorEl) {
        return;
    }

    errorEl.textContent = "";

    errorEl.classList.remove(
        "show"
    );

}


// =====================================================
// LOAD FEED
// =====================================================

window.loadFeed =
async function() {

    console.log(
        "📰 Loading cricket feed..."
    );


    hideError();


    if (loadingEl) {

        loadingEl.style.display =
            "block";

        loadingEl.textContent =
            "🔄 Loading cricket feed...";

    }


    if (feedEl) {

        feedEl.innerHTML = "";

    }


    if (!tournamentId) {

        showError(
            "Tournament ID missing."
        );


        if (loadingEl) {

            loadingEl.style.display =
                "none";

        }

        return;

    }


    try {

        const matchesRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "matches"
            );


        const matchesQuery =
            query(
                matchesRef,
                orderBy(
                    "matchDate",
                    "desc"
                ),
                limit(50)
            );


        const snapshot =
            await getDocs(
                matchesQuery
            );


        console.log(
            "🏏 MATCH COUNT:",
            snapshot.size
        );


        const matches = [];


        snapshot.forEach(
            matchDoc => {

                matches.push({

                    id:
                        matchDoc.id,

                    ...matchDoc.data()

                });

            }
        );


        // =================================================
        // SORT MATCHES
        // =================================================

        matches.sort(
            (a, b) => {

                const dateA =
                    getMatchDate(
                        a
                    );

                const dateB =
                    getMatchDate(
                        b
                    );

                return dateB -
                    dateA;

            }
        );


        renderFeed(
            matches
        );


    }
    catch (error) {

        console.error(
            "❌ FEED LOAD ERROR:",
            error
        );


        showError(
            error.message ||
            "Unable to load cricket feed."
        );

    }
    finally {

        if (loadingEl) {

            loadingEl.style.display =
                "none";

        }

    }

};


// =====================================================
// GET MATCH DATE
// =====================================================

function getMatchDate(
    match
) {

    const value =
        match.matchDate ||
        match.date ||
        match.createdAt ||
        match.updatedAt ||
        "";


    if (
        value &&
        typeof value.toDate ===
        "function"
    ) {

        return value.toDate();

    }


    const date =
        new Date(
            value
        );


    if (
        !isNaN(
            date.getTime()
        )
    ) {

        return date;

    }


    return new Date(0);

}


// =====================================================
// RENDER FEED
// =====================================================

function renderFeed(
    matches
) {

    if (!feedEl) {
        return;
    }


    if (!matches.length) {

        feedEl.innerHTML = `
            <div class="card empty">
                🏏 No cricket updates yet.
            </div>
        `;

        return;

    }


    feedEl.innerHTML =
        matches
            .map(
                match =>
                    createFeedItem(
                        match
                    )
            )
            .join("");


    console.log(
        "✅ CRICKET FEED DISPLAYED"
    );

}


// =====================================================
// CREATE FEED ITEM
// =====================================================

function createFeedItem(
    match
) {

    const team1 =
        escapeHtml(
            match.team1Name ||
            match.teamA ||
            "Team 1"
        );


    const team2 =
        escapeHtml(
            match.team2Name ||
            match.teamB ||
            "Team 2"
        );


    const scoreA =
        escapeHtml(
            match.scoreA ||
            "0/0"
        );


    const scoreB =
        escapeHtml(
            match.scoreB ||
            "0/0"
        );


    const status =
        String(
            match.status ||
            "Scheduled"
        );


    const result =
        escapeHtml(
            match.result ||
            ""
        );


    const dateText =
        formatDate(
            match
        );


    const type =
        getFeedType(
            status
        );


    const matchNumber =
        escapeHtml(
            String(
                match.matchNumber ||
                match.matchNo ||
                "Match"
            )
        );


    const tournament =
        escapeHtml(
            match.tournamentName ||
            ""
        );


    return `

        <div class="feed-item">

            <div class="feed-header">

                <div class="feed-type">
                    ${type}
                </div>

                <div class="feed-time">
                    ${dateText}
                </div>

            </div>


            <h3>
                🏏 ${matchNumber}
            </h3>


            ${
                tournament
                ?
                `
                <p style="
                    margin-bottom:10px;
                    color:#64748b;
                ">
                    🏆 ${tournament}
                </p>
                `
                :
                ""
            }


            <div class="score-box">

                <div class="score-row">

                    <span class="team-name">
                        ${team1}
                    </span>

                    <span class="team-score">
                        ${scoreA}
                    </span>

                </div>


                <div class="score-row">

                    <span class="team-name">
                        ${team2}
                    </span>

                    <span class="team-score">
                        ${scoreB}
                    </span>

                </div>


                ${
                    result
                    ?
                    `
                    <div class="result">
                        🏆 ${result}
                    </div>
                    `
                    :
                    `
                    <div style="
                        margin-top:8px;
                        color:#64748b;
                        font-size:13px;
                    ">
                        ${escapeHtml(status)}
                    </div>
                    `
                }

            </div>


            ${
                match.id
                ?
                `
                <button
                    type="button"
                    onclick="openMatch('${encodeURIComponent(match.id)}')"
                    style="
                        width:100%;
                        margin-top:10px;
                    "
                >
                    📊 View Match
                </button>
                `
                :
                ""
            }

        </div>

    `;

}


// =====================================================
// FEED TYPE
// =====================================================

function getFeedType(
    status
) {

    const value =
        String(
            status || ""
        ).toLowerCase();


    if (
        value === "live"
    ) {

        return "🔴 LIVE MATCH";

    }


    if (
        value === "completed"
    ) {

        return "🏆 MATCH RESULT";

    }


    if (
        value === "scheduled"
    ) {

        return "📅 UPCOMING MATCH";

    }


    return "🏏 MATCH UPDATE";

}


// =====================================================
// OPEN MATCH
// =====================================================

window.openMatch =
function(matchId) {

    if (!matchId) {
        return;
    }


    const url =
        `live-score.html?tournamentId=${
            encodeURIComponent(
                tournamentId
            )
        }&matchId=${matchId}`;


    window.location.href =
        url;

};


// =====================================================
// FORMAT DATE
// =====================================================

function formatDate(
    match
) {

    const date =
        getMatchDate(
            match
        );


    if (
        !date ||
        date.getTime() === 0
    ) {

        return "";

    }


    return date.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// START
// =====================================================

loadFeed();


console.log(
    "✅ CRICKMATE CRICKET-FEED.JS READY"
);