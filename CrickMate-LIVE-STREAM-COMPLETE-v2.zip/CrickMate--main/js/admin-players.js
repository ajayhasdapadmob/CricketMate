// =====================================================
// CRICKMATE - ADMIN PLAYERS.JS
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs,
    getDoc,
    doc
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log(
    "👥 CRICKMATE ADMIN-PLAYERS.JS STARTED"
);


// =====================================================
// ELEMENTS
// =====================================================

const tournamentSelect =
    document.getElementById(
        "tournamentSelect"
    );

const teamSelect =
    document.getElementById(
        "teamSelect"
    );

const searchInput =
    document.getElementById(
        "searchInput"
    );

const playersTable =
    document.getElementById(
        "playersTable"
    );

const totalPlayers =
    document.getElementById(
        "totalPlayers"
    );

const captains =
    document.getElementById(
        "captains"
    );

const batsmen =
    document.getElementById(
        "batsmen"
    );

const bowlers =
    document.getElementById(
        "bowlers"
    );

const message =
    document.getElementById(
        "message"
    );

const teamInfo =
    document.getElementById(
        "teamInfo"
    );


// =====================================================
// GLOBAL
// =====================================================

let tournaments = [];

let teams = [];

let players = [];


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "success"
) {

    if (!message) {
        return;
    }

    message.textContent =
        text;

    message.className =
        `message show ${type}`;

}


// =====================================================
// GET TOURNAMENT ID
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem(
        "tournamentId"
    ) ||
    localStorage.getItem(
        "currentTournamentId"
    );


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

}


// =====================================================
// LOAD TOURNAMENTS
// =====================================================

async function loadTournaments() {

    console.log(
        "🏆 Loading tournaments..."
    );


    try {

        const tournamentsRef =
            collection(
                db,
                "tournaments"
            );


        const snapshot =
            await getDocs(
                tournamentsRef
            );


        tournaments = [];


        snapshot.forEach(
            tournamentDoc => {

                tournaments.push({

                    id:
                        tournamentDoc.id,

                    ...tournamentDoc.data()

                });

            }
        );


        console.log(
            "🏆 TOURNAMENTS:",
            tournaments.length
        );


        if (!tournamentSelect) {
            return;
        }


        tournamentSelect.innerHTML = `

            <option value="">
                Select Tournament
            </option>

        `;


        tournaments.forEach(
            tournament => {

                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    tournament.id;


                option.textContent =
                    tournament.tournamentName ||
                    tournament.name ||
                    "Unnamed Tournament";


                tournamentSelect.appendChild(
                    option
                );

            }
        );


        // =================================================
        // SELECT SAVED TOURNAMENT
        // =================================================

        if (tournamentId) {

            const exists =
                tournaments.some(
                    tournament =>
                        tournament.id ===
                        tournamentId
                );


            if (exists) {

                tournamentSelect.value =
                    tournamentId;

                await loadTeams(
                    tournamentId
                );

            }

        }

    }
    catch (error) {

        console.error(
            "❌ Tournament loading error:",
            error
        );


        showMessage(
            error.message ||
            "Unable to load tournaments.",
            "error"
        );

    }

}


// =====================================================
// LOAD TEAMS
// =====================================================

async function loadTeams(
    selectedTournamentId
) {

    if (!teamSelect) {
        return;
    }


    teamSelect.innerHTML = `

        <option value="">
            Loading Teams...
        </option>

    `;


    players = [];


    renderPlayers();


    try {

        const teamsRef =
            collection(
                db,
                "tournaments",
                selectedTournamentId,
                "teams"
            );


        const snapshot =
            await getDocs(
                teamsRef
            );


        teams = [];


        snapshot.forEach(
            teamDoc => {

                teams.push({

                    id:
                        teamDoc.id,

                    ...teamDoc.data()

                });

            }
        );


        console.log(
            "👥 TEAMS:",
            teams.length
        );


        teamSelect.innerHTML = `

            <option value="">
                Select Team
            </option>

        `;


        teams.forEach(
            team => {

                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    team.id;


                option.textContent =
                    team.teamName ||
                    team.name ||
                    "Unnamed Team";


                teamSelect.appendChild(
                    option
                );

            }
        );


    }
    catch (error) {

        console.error(
            "❌ Team loading error:",
            error
        );


        teamSelect.innerHTML = `

            <option value="">
                Unable to load teams
            </option>

        `;


        showMessage(
            error.message ||
            "Unable to load teams.",
            "error"
        );

    }

}


// =====================================================
// LOAD PLAYERS
// =====================================================

async function loadPlayers(
    selectedTournamentId,
    selectedTeamId
) {

    console.log(
        "🔥 Loading players..."
    );


    players = [];


    if (!selectedTournamentId) {

        renderPlayers();

        return;

    }


    if (!selectedTeamId) {

        renderPlayers();

        return;

    }


    try {

        // =================================================
        // TEAM DOCUMENT
        // =================================================

        const teamRef =
            doc(
                db,
                "tournaments",
                selectedTournamentId,
                "teams",
                selectedTeamId
            );


        const teamSnap =
            await getDoc(
                teamRef
            );


        if (!teamSnap.exists()) {

            showMessage(
                "Team not found.",
                "error"
            );

            renderPlayers();

            return;

        }


        const team =
            teamSnap.data();


        const teamName =
            team.teamName ||
            team.name ||
            "Unnamed Team";


        if (teamInfo) {

            teamInfo.textContent =
                `🏏 ${teamName}`;

        }


        // =================================================
        // PLAYERS SUBCOLLECTION
        // =================================================

        try {

            const playersRef =
                collection(
                    db,
                    "tournaments",
                    selectedTournamentId,
                    "teams",
                    selectedTeamId,
                    "players"
                );


            const snapshot =
                await getDocs(
                    playersRef
                );


            console.log(
                "👥 PLAYERS FOUND:",
                snapshot.size
            );


            snapshot.forEach(
                playerDoc => {

                    const player =
                        playerDoc.data();


                    players.push({

                        id:
                            playerDoc.id,

                        name:
                            player.playerName ||
                            player.name ||
                            player.fullName ||
                            `Player ${players.length + 1}`,

                        role:
                            player.role ||
                            player.playerRole ||
                            "Player",

                        mobile:
                            player.mobile ||
                            player.phone ||
                            "",

                        email:
                            player.email ||
                            "",

                        status:
                            player.status ||
                            "Active"

                    });

                }
            );

        }
        catch (subError) {

            console.warn(
                "⚠️ Players subcollection unavailable:",
                subError.message
            );

        }


        // =================================================
        // FALLBACK: TEAM DOCUMENT
        // =================================================

        if (players.length === 0) {

            console.log(
                "🔄 Loading players from team document..."
            );


            for (
                let i = 1;
                i <= 15;
                i++
            ) {

                const playerValue =
                    team[
                        `player${i}`
                    ];


                if (
                    playerValue !== undefined &&
                    playerValue !== null &&
                    String(
                        playerValue
                    ).trim() !== ""
                ) {

                    players.push({

                        id:
                            `player${i}`,

                        name:
                            String(
                                playerValue
                            ),

                        role:
                            i === 1
                            ?
                            "Captain"
                            :
                            "Player",

                        mobile:
                            "",

                        email:
                            "",

                        status:
                            "Active"

                    });

                }

            }


            // =================================================
            // PLAYERS ARRAY
            // =================================================

            if (
                players.length === 0 &&
                Array.isArray(
                    team.players
                )
            ) {

                team.players.forEach(
                    (
                        player,
                        index
                    ) => {

                        if (
                            !player
                        ) {
                            return;
                        }


                        if (
                            typeof player ===
                            "string"
                        ) {

                            players.push({

                                id:
                                    `player-${index}`,

                                name:
                                    player,

                                role:
                                    index === 0
                                    ?
                                    "Captain"
                                    :
                                    "Player",

                                mobile:
                                    "",

                                email:
                                    "",

                                status:
                                    "Active"

                            });

                        }
                        else {

                            players.push({

                                id:
                                    `player-${index}`,

                                name:
                                    player.playerName ||
                                    player.name ||
                                    player.fullName ||
                                    `Player ${index + 1}`,

                                role:
                                    player.role ||
                                    player.playerRole ||
                                    (
                                        index === 0
                                        ?
                                        "Captain"
                                        :
                                        "Player"
                                    ),

                                mobile:
                                    player.mobile ||
                                    player.phone ||
                                    "",

                                email:
                                    player.email ||
                                    "",

                                status:
                                    player.status ||
                                    "Active"

                            });

                        }

                    }
                );

            }

        }


        console.log(
            "👥 TOTAL PLAYERS:",
            players.length
        );


        renderPlayers();


    }
    catch (error) {

        console.error(
            "❌ Player loading error:",
            error
        );


        showMessage(
            error.message ||
            "Unable to load players.",
            "error"
        );


        renderPlayers();

    }

}


// =====================================================
// RENDER PLAYERS
// =====================================================

function renderPlayers() {

    if (!playersTable) {
        return;
    }


    const search =
        searchInput
        ?
        searchInput.value
            .trim()
            .toLowerCase()
        :
        "";


    const filtered =
        players.filter(
            player => {

                const text =
                    `${player.name}
                    ${player.role}
                    ${player.mobile}
                    ${player.email}`
                    .toLowerCase();


                return text.includes(
                    search
                );

            }
        );


    // =================================================
    // STATS
    // =================================================

    if (totalPlayers) {

        totalPlayers.textContent =
            players.length;

    }


    if (captains) {

        captains.textContent =
            players.filter(
                player =>
                    String(
                        player.role
                    )
                    .toLowerCase()
                    .includes("captain")
            ).length;

    }


    if (batsmen) {

        batsmen.textContent =
            players.filter(
                player =>
                    String(
                        player.role
                    )
                    .toLowerCase()
                    .includes("bat")
            ).length;

    }


    if (bowlers) {

        bowlers.textContent =
            players.filter(
                player =>
                    String(
                        player.role
                    )
                    .toLowerCase()
                    .includes("bowl")
            ).length;

    }


    // =================================================
    // EMPTY
    // =================================================

    if (filtered.length === 0) {

        playersTable.innerHTML = `

            <tr>

                <td
                    colspan="6"
                    class="empty"
                >

                    ${
                        players.length === 0
                        ?
                        "👤 No players found."
                        :
                        "🔍 No matching players."
                    }

                </td>

            </tr>

        `;

        return;

    }


// =================================================
    // HTML
    // =================================================

    playersTable.innerHTML =
        filtered
            .map(
                (
                    player,
                    index
                ) => {

                    const role =
                        String(
                            player.role ||
                            "Player"
                        );


                    const isCaptain =
                        role
                            .toLowerCase()
                            .includes(
                                "captain"
                            );


                    return `

                        <tr>

                            <td>

                                <div
                                    class="player-number"
                                >
                                    ${index + 1}
                                </div>

                            </td>


                            <td>

                                <strong>
                                    ${escapeHtml(
                                        player.name
                                    )}
                                </strong>

                            </td>


                            <td>

                                <span
                                    class="
                                        badge
                                        ${
                                            isCaptain
                                            ?
                                            "captain"
                                            :
                                            ""
                                        }
                                    "
                                >

                                    ${
                                        isCaptain
                                        ?
                                        "👑 "
                                        :
                                        ""
                                    }

                                    ${escapeHtml(
                                        role
                                    )}

                                </span>

                            </td>


                            <td>

                                ${
                                    player.mobile
                                    ?
                                    escapeHtml(
                                        player.mobile
                                    )
                                    :
                                    "—"
                                }

                            </td>


                            <td>

                                ${
                                    player.email
                                    ?
                                    escapeHtml(
                                        player.email
                                    )
                                    :
                                    "—"
                                }

                            </td>


                            <td>

                                <span class="badge">
                                    ${escapeHtml(
                                        player.status
                                    )}
                                </span>

                            </td>

                        </tr>

                    `;

                }
            )
            .join("");

}


// =====================================================
// TOURNAMENT CHANGE
// =====================================================

if (tournamentSelect) {

    tournamentSelect.addEventListener(
        "change",
        async () => {

            const selected =
                tournamentSelect.value;


            if (selected) {

                localStorage.setItem(
                    "tournamentId",
                    selected
                );

                localStorage.setItem(
                    "currentTournamentId",
                    selected
                );

            }


            await loadTeams(
                selected
            );

        }
    );

}


// =====================================================
// TEAM CHANGE
// =====================================================

if (teamSelect) {

    teamSelect.addEventListener(
        "change",
        async () => {

            const selectedTeam =
                teamSelect.value;


            if (
                selectedTeam &&
                tournamentSelect.value
            ) {

                localStorage.setItem(
                    "currentTeamId",
                    selectedTeam
                );


                await loadPlayers(
                    tournamentSelect.value,
                    selectedTeam
                );

            }
            else {

                players = [];

                renderPlayers();

            }

        }
    );

}


// =====================================================
// SEARCH
// =====================================================

if (searchInput) {

    searchInput.addEventListener(
        "input",
        () => {

            renderPlayers();

        }
    );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// START
// =====================================================

loadTournaments();


console.log(
    "✅ CRICKMATE ADMIN-PLAYERS.JS READY"
);