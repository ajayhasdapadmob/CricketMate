// =====================================================
// CRICKMATE - MY CRICKET
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs,
    doc,
    getDoc,
    query,
    where
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🔥 CRICKMATE MY CRICKET JS STARTED");


// =====================================================
// HTML ELEMENTS
// =====================================================

const status =
    document.getElementById("status");

const tournamentCard =
    document.getElementById("tournamentCard");

const tournamentName =
    document.getElementById("tournamentName");

const teamCard =
    document.getElementById("teamCard");

const teamName =
    document.getElementById("teamName");

const teamInfo =
    document.getElementById("teamInfo");

const playersCard =
    document.getElementById("playersCard");

const playersList =
    document.getElementById("playersList");


// =====================================================
// GET TOURNAMENT ID
// =====================================================

function getTournamentId() {

    const params =
        new URLSearchParams(
            window.location.search
        );

    const urlId =
        params.get("tournamentId") ||
        params.get("tournament") ||
        params.get("tid");

    if (urlId) {

        localStorage.setItem(
            "tournamentId",
            urlId
        );

        return urlId;
    }

    return (
        localStorage.getItem("tournamentId") ||
        localStorage.getItem("currentTournamentId") ||
        localStorage.getItem("selectedTournamentId") ||
        null
    );
}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


// =====================================================
// LOAD MY CRICKET
// =====================================================

async function loadMyCricket() {

    try {

        const tournamentId =
            getTournamentId();


        console.log(
            "🏆 Tournament ID:",
            tournamentId
        );


        if (!tournamentId) {

            status.innerHTML = `
                ❌ Tournament ID missing.
            `;

            status.className = "error";

            return;
        }


        // =================================================
        // LOAD TOURNAMENT
        // =================================================

        status.innerHTML =
            "⏳ Loading tournament...";


        const tournamentRef =
            doc(
                db,
                "tournaments",
                tournamentId
            );


        const tournamentSnap =
            await getDoc(tournamentRef);


        if (!tournamentSnap.exists()) {

            status.innerHTML = `
                ❌ Tournament not found.
            `;

            status.className = "error";

            return;
        }


        const tournament =
            tournamentSnap.data();


        console.log(
            "🏆 Tournament:",
            tournament
        );


        const tName =
            tournament.name ||
            tournament.tournamentName ||
            tournament.title ||
            "CrickMate Tournament";


        tournamentName.textContent =
            tName;


        tournamentCard.style.display =
            "block";


        // =================================================
        // IMPORTANT:
        // TEAMS ARE NESTED INSIDE TOURNAMENT
        // tournaments/{tournamentId}/teams
        // =================================================

        status.innerHTML =
            "⏳ Loading teams...";


        const teamsRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "teams"
            );


        const teamsSnap =
            await getDocs(teamsRef);


        console.log(
            "👥 Teams found:",
            teamsSnap.size
        );


        if (teamsSnap.empty) {

            status.innerHTML = `
                ⚠️ No teams found.
            `;

            status.className = "error";

            return;
        }


        // =================================================
        // SHOW ALL TEAMS
        // =================================================

        teamCard.style.display =
            "block";


        playersCard.style.display =
            "block";


        teamName.textContent =
            `My Teams (${teamsSnap.size})`;


        teamInfo.textContent =
            "Teams registered in this tournament";


        playersList.innerHTML = "";


        // =================================================
        // LOOP TEAMS
        // =================================================

        let totalPlayers = 0;


        for (
            const teamDoc of teamsSnap.docs
        ) {

            const team =
                teamDoc.data();


            console.log(
                "👥 TEAM:",
                teamDoc.id,
                team
            );


            const currentTeamName =
                team.teamName ||
                team.name ||
                team.title ||
                "Unnamed Team";


            // =================================================
            // TEAM HEADER
            // =================================================

            const teamBox =
                document.createElement("div");


            teamBox.style.marginBottom =
                "20px";


            teamBox.innerHTML = `

                <div style="
                    font-size:18px;
                    font-weight:bold;
                    padding:12px;
                    background:#e2e8f0;
                    border-radius:10px;
                    margin-bottom:8px;
                ">

                    🏏 ${escapeHTML(currentTeamName)}

                </div>

            `;


            playersList.appendChild(
                teamBox
            );


            // =================================================
            // LOAD NESTED PLAYERS
            //
            // tournaments/{tournamentId}
            //      /teams/{teamId}
            //          /players/{playerId}
            // =================================================

            const playersRef =
                collection(
                    db,
                    "tournaments",
                    tournamentId,
                    "teams",
                    teamDoc.id,
                    "players"
                );


            const playersSnap =
                await getDocs(playersRef);


            console.log(
                "🏏 Players in",
                currentTeamName,
                ":",
                playersSnap.size
            );


            if (playersSnap.empty) {

                const noPlayer =
                    document.createElement("div");


                noPlayer.style.padding =
                    "10px";


                noPlayer.style.color =
                    "#64748b";


                noPlayer.textContent =
                    "No players found";


                playersList.appendChild(
                    noPlayer
                );


                return;
            }


            // =================================================
            // DISPLAY PLAYERS
            // =================================================

            let playerNumber = 1;


            playersSnap.forEach(
                playerDoc => {

                    const player =
                        playerDoc.data();


                    console.log(
                        "🏏 PLAYER:",
                        playerDoc.id,
                        player
                    );


                    const playerName =
                        player.name ||
                        player.playerName ||
                        player.fullName ||
                        player.displayName ||
                        player.playerFullName ||
                        player.captainName ||
                        "Unknown Player";


                    const role =
                        player.role ||
                        player.playerType ||
                        player.position ||
                        "";


                    const playerDiv =
                        document.createElement("div");


                    playerDiv.className =
                        "player";


                    playerDiv.innerHTML = `

                        <div class="player-number">
                            ${playerNumber}
                        </div>

                        <div>

                            <div class="player-name">
                                ${escapeHTML(playerName)}
                            </div>

                            ${
                                role
                                ? `
                                <div class="player-role">
                                    ${escapeHTML(role)}
                                </div>
                                `
                                : ""
                            }

                        </div>

                    `;


                    playersList.appendChild(
                        playerDiv
                    );


                    playerNumber++;

                    totalPlayers++;

                }
            );

        }


        // =================================================
        // FINAL STATUS
        // =================================================

        status.innerHTML = `
            ✅ My Cricket loaded<br>
            🏆 Tournament: ${escapeHTML(tName)}<br>
            👥 Teams: ${teamsSnap.size}<br>
            🏏 Players: ${totalPlayers}
        `;


        status.className =
            "loading";


        console.log(
            "✅ MY CRICKET READY"
        );


    } catch (error) {

        console.error(
            "❌ MY CRICKET ERROR:",
            error
        );


        status.innerHTML = `
            ❌ My Cricket Error<br><br>
            ${escapeHTML(error.message)}
        `;


        status.className =
            "error";

    }

}


// =====================================================
// START
// =====================================================

loadMyCricket();