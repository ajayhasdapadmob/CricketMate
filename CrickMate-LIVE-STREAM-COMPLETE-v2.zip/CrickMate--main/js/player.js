// =====================================================
// CRICKMATE - PLAYER.JS
// TEAM PLAYERS MANAGEMENT
// =====================================================

import { db } from "./firebase.js";

import {
    doc,
    getDoc,
    collection,
    getDocs,
    setDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE PLAYER.JS STARTED");


// =====================================================
// URL PARAMETERS
// =====================================================

const params =
    new URLSearchParams(window.location.search);


// =====================================================
// TOURNAMENT ID
// =====================================================

let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


// =====================================================
// TEAM ID
// =====================================================

let teamId =
    params.get("teamId") ||
    localStorage.getItem("currentTeamId");


// =====================================================
// CLEAN IDs
// =====================================================

if (tournamentId) {
    tournamentId = tournamentId.trim();
}

if (teamId) {
    teamId = teamId.trim();
}


// =====================================================
// SAVE IDs
// =====================================================

if (tournamentId) {

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );
}


if (teamId) {

    localStorage.setItem(
        "currentTeamId",
        teamId
    );
}


// =====================================================
// LOG
// =====================================================

console.log(
    "🏆 Tournament ID:",
    tournamentId
);

console.log(
    "👥 Team ID:",
    teamId
);


// =====================================================
// ELEMENTS
// =====================================================

const teamInfo =
    document.getElementById("teamInfo");

const teamIdBox =
    document.getElementById("teamIdBox");

const playersContainer =
    document.getElementById("playersContainer");

const playersForm =
    document.getElementById("playersForm");

const saveBtn =
    document.getElementById("saveBtn");

const message =
    document.getElementById("message");

const backBtn =
    document.getElementById("backBtn");


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "success"
) {

    if (!message) {
        return;
    }

    message.className =
        `message ${type}`;

    message.textContent =
        text;
}


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId && teamId) {

        backBtn.href =
            `team.html?tournamentId=${encodeURIComponent(
                tournamentId
            )}&teamId=${encodeURIComponent(
                teamId
            )}`;

    }
    else if (tournamentId) {

        backBtn.href =
            `teams.html?tournamentId=${encodeURIComponent(
                tournamentId
            )}`;

    }
    else {

        backBtn.href =
            "my-tournaments.html";

    }
}


// =====================================================
// VALIDATION
// =====================================================

if (!tournamentId) {

    showMessage(
        "❌ Tournament ID missing.",
        "error"
    );

    if (saveBtn) {
        saveBtn.disabled = true;
    }

}
else if (!teamId) {

    showMessage(
        "❌ Team ID missing.",
        "error"
    );

    if (saveBtn) {
        saveBtn.disabled = true;
    }

}
else {

    loadTeam();

}


// =====================================================
// LOAD TEAM
// =====================================================

async function loadTeam() {

    console.log("🔥 Loading team...");

    try {

        const teamRef =
            doc(
                db,
                "tournaments",
                tournamentId,
                "teams",
                teamId
            );


        const teamSnap =
            await getDoc(teamRef);


        if (!teamSnap.exists()) {

            showMessage(
                "❌ Team not found.",
                "error"
            );

            return;
        }


        const team =
            teamSnap.data();


        console.log(
            "✅ TEAM FOUND:",
            team
        );


        const teamName =
            team.teamName ||
            team.name ||
            "Unnamed Team";


        const captain =
            team.captainName ||
            team.captain ||
            "Not Available";


        const mobile =
            team.mobile ||
            team.phone ||
            "Not Available";


        const email =
            team.email ||
            "Not Available";


        if (teamInfo) {

            teamInfo.innerHTML = `

                <strong>
                    🏏 ${escapeHtml(teamName)}
                </strong>

                <br><br>

                👑 Captain:
                ${escapeHtml(captain)}

                <br>

                📱 Mobile:
                ${escapeHtml(mobile)}

                <br>

                📧 Email:
                ${escapeHtml(email)}

            `;
        }


        if (teamIdBox) {

            teamIdBox.textContent =
                `Team ID: ${teamId}`;

        }


        localStorage.setItem(
            "currentTeamName",
            teamName
        );


        // Create player fields

        createPlayerFields();


        // Load saved players

        await loadPlayers();


        console.log(
            "✅ PLAYER PAGE READY"
        );

    }
    catch (error) {

        console.error(
            "❌ TEAM LOAD ERROR:",
            error
        );

        showMessage(
            error.message ||
            "Unable to load team.",
            "error"
        );
    }
}


// =====================================================
// CREATE 15 PLAYER FIELDS
// =====================================================

function createPlayerFields() {

    if (!playersContainer) {
        return;
    }


    let html = "";


    for (
        let i = 1;
        i <= 15;
        i++
    ) {

        html += `

        <div
            class="player-card"
            data-player="${i}"
        >

            <div class="player-header">

                <div class="player-number">
                    ${i}
                </div>

                <div>

                    <div class="player-title">
                        Player ${i}
                    </div>

                    <div class="player-subtitle">
                        ${
                            i === 1
                            ? "Captain"
                            : "Team Player"
                        }
                    </div>

                </div>

            </div>


            <div class="form-group">

                <label>
                    Player Name
                </label>

                <input
                    type="text"
                    class="player-name"
                    data-player="${i}"
                    placeholder="Enter player ${i} name"
                >

            </div>


            <div class="row">

                <div class="form-group">

                    <label>
                        Role
                    </label>

                    <select
                        class="player-role"
                        data-player="${i}"
                    >

                        <option value="">
                            Select Role
                        </option>

                        <option value="Captain">
                            Captain
                        </option>

                        <option value="Vice Captain">
                            Vice Captain
                        </option>

                        <option value="Batsman">
                            Batsman
                        </option>

                        <option value="Bowler">
                            Bowler
                        </option>

                        <option value="All Rounder">
                            All Rounder
                        </option>

                        <option value="Wicket Keeper">
                            Wicket Keeper
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        Mobile
                    </label>

                    <input
                        type="tel"
                        class="player-mobile"
                        data-player="${i}"
                        maxlength="10"
                        placeholder="Mobile number"
                    >

                </div>

            </div>

        </div>

        `;
    }


    playersContainer.innerHTML =
        html;
}


// =====================================================
// LOAD SAVED PLAYERS
// =====================================================

async function loadPlayers() {

    console.log(
        "👥 Loading players..."
    );


    try {

        const playersRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "teams",
                teamId,
                "players"
            );


        console.log(
            "📂 PLAYER PATH:",
            `tournaments/${tournamentId}/teams/${teamId}/players`
        );


        const snapshot =
            await getDocs(playersRef);


        console.log(
            "👥 SAVED PLAYERS:",
            snapshot.size
        );


        snapshot.forEach(
            playerDoc => {

                const player =
                    playerDoc.data();


                let number =
                    Number(
                        player.playerNumber ||
                        player.number ||
                        String(
                            playerDoc.id
                        )
                        .replace(
                            "player",
                            ""
                        )
                    );


                if (
                    number < 1 ||
                    number > 15
                ) {
                    return;
                }


                const nameInput =
                    document.querySelector(
                        `.player-name[data-player="${number}"]`
                    );


                const roleInput =
                    document.querySelector(
                        `.player-role[data-player="${number}"]`
                    );


                const mobileInput =
                    document.querySelector(
                        `.player-mobile[data-player="${number}"]`
                    );


                if (nameInput) {

                    nameInput.value =
                        player.playerName ||
                        player.name ||
                        "";
                }


                if (roleInput) {

                    roleInput.value =
                        player.role ||
                        "";
                }


                if (mobileInput) {

                    mobileInput.value =
                        player.mobile ||
                        "";
                }

            }
        );


        console.log(
            "✅ EXISTING PLAYERS LOADED"
        );

    }
    catch (error) {

        console.error(
            "❌ PLAYER LOAD ERROR:",
            error
        );

        showMessage(
            "⚠️ Players could not be loaded. You can still add players.",
            "error"
        );
    }
}


// =====================================================
// SAVE PLAYERS
// =====================================================

if (playersForm) {

    playersForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            console.log(
                "💾 SAVE PLAYERS CLICKED"
            );


            if (
                !tournamentId ||
                !teamId
            ) {

                showMessage(
                    "❌ Tournament ID or Team ID missing.",
                    "error"
                );

                return;
            }


            const players = [];


            // =================================================
            // READ 15 PLAYERS
            // =================================================

            for (
                let i = 1;
                i <= 15;
                i++
            ) {

                const nameInput =
                    document.querySelector(
                        `.player-name[data-player="${i}"]`
                    );


                const roleInput =
                    document.querySelector(
                        `.player-role[data-player="${i}"]`
                    );


                const mobileInput =
                    document.querySelector(
                        `.player-mobile[data-player="${i}"]`
                    );


                const name =
                    nameInput
                    ?
                    nameInput.value.trim()
                    :
                    "";


                const role =
                    roleInput
                    ?
                    roleInput.value
                    :
                    "";


                const mobile =
                    mobileInput
                    ?
                    mobileInput.value.trim()
                    :
                    "";


                if (!name) {
                    continue;
                }


                // =================================================
                // MOBILE VALIDATION
                // =================================================

                if (
                    mobile &&
                    !/^[0-9]{10}$/.test(
                        mobile
                    )
                ) {

                    showMessage(
                        `❌ Player ${i}: Enter valid 10-digit mobile number.`,
                        "error"
                    );

                    return;
                }


                players.push({

                    playerNumber: i,

                    number: i,

                    playerName: name,

                    name: name,

                    role: role,

                    mobile: mobile,

                    tournamentId:
                        tournamentId,

                    teamId:
                        teamId,

                    updatedAt:
                        serverTimestamp(),

                    createdAt:
                        serverTimestamp()

                });

            }


            // =================================================
            // CHECK
            // =================================================

            if (
                players.length === 0
            ) {

                showMessage(
                    "❌ Please enter at least one player.",
                    "error"
                );

                return;
            }


            // =================================================
            // BUTTON
            // =================================================

            if (saveBtn) {

                saveBtn.disabled = true;

                saveBtn.textContent =
                    "⏳ Saving Players...";

            }


            showMessage(
                `Saving ${players.length} player(s)...`,
                "success"
            );


            try {

                const playersRef =
                    collection(
                        db,
                        "tournaments",
                        tournamentId,
                        "teams",
                        teamId,
                        "players"
                    );


                console.log(
                    "📂 SAVING PLAYERS TO:",
                    `tournaments/${tournamentId}/teams/${teamId}/players`
                );


                // =================================================
                // SAVE EACH PLAYER
                // =================================================

                for (
                    const player of players
                ) {

                    const playerId =
                        `player${player.playerNumber}`;


                    const playerRef =
                        doc(
                            playersRef,
                            playerId
                        );


                    await setDoc(
                        playerRef,
                        player,
                        {
                            merge: true
                        }
                    );


                    console.log(
                        `✅ SAVED: ${playerId}`,
                        player.playerName
                    );

                }


                // =================================================
                // UPDATE TEAM
                // =================================================

                const teamRef =
                    doc(
                        db,
                        "tournaments",
                        tournamentId,
                        "teams",
                        teamId
                    );


                await setDoc(
                    teamRef,
                    {

                        playerCount:
                            players.length,

                        updatedAt:
                            serverTimestamp()

                    },
                    {
                        merge: true
                    }
                );


                // =================================================
                // SUCCESS
                // =================================================

                console.log(
                    "🎉 ALL PLAYERS SAVED SUCCESSFULLY"
                );


                showMessage(
                    `✅ ${players.length} player(s) saved successfully!`,
                    "success"
                );


                if (saveBtn) {

                    saveBtn.textContent =
                        "✅ Players Saved";

                }


                // Do NOT redirect immediately.
                // User can verify Firebase first.

            }
            catch (error) {

                console.error(
                    "❌ PLAYER SAVE ERROR:",
                    error
                );


                showMessage(
                    error.message ||
                    "❌ Failed to save players.",
                    "error"
                );


                if (saveBtn) {

                    saveBtn.disabled =
                        false;

                    saveBtn.textContent =
                        "💾 Save Players";

                }

            }

        }
    );
}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";
    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );
}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE PLAYER.JS READY"
);