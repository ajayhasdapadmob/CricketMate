// =====================================================
// CRICKMATE - ADMIN MATCHES.JS
// =====================================================

import {
    db
} from "./firebase.js";

import {
    collection,
    getDocs,
    doc,
    getDoc,
    updateDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

console.log("🔥🔥🔥 LIVE STREAM START");
console.log("✅ FIREBASE DB:", db);


console.log("🏏 CRICKMATE ADMIN-MATCHES.JS STARTED");


// =====================================================
// ELEMENTS
// =====================================================

const tournamentSelect =
    document.getElementById("tournamentSelect");

const statusFilter =
    document.getElementById("statusFilter");

const searchInput =
    document.getElementById("searchInput");

const matchesTable =
    document.getElementById("matchesTable");

const totalMatches =
    document.getElementById("totalMatches");

const scheduledMatches =
    document.getElementById("scheduledMatches");

const liveMatches =
    document.getElementById("liveMatches");

const completedMatches =
    document.getElementById("completedMatches");

const resultsCount =
    document.getElementById("resultsCount");

const message =
    document.getElementById("message");


// =====================================================
// GET TOURNAMENT ID
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// DATA
// =====================================================

let tournaments = [];

let matches = [];


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "info"
) {

    if (!message) {
        return;
    }

    message.textContent =
        text;

    message.className =
        `message show ${type}`;

}


// =====================================================
// LOAD TOURNAMENTS
// =====================================================

async function loadTournaments() {

    console.log(
        "🏆 Loading tournaments..."
    );


    try {

        const tournamentsRef =
            collection(
                db,
                "tournaments"
            );


        const snapshot =
            await getDocs(
                tournamentsRef
            );


        tournaments = [];


        snapshot.forEach(
            tournamentDoc => {

                tournaments.push({

                    id:
                        tournamentDoc.id,

                    ...tournamentDoc.data()

                });

            }
        );


        console.log(
            "🏆 TOURNAMENTS FOUND:",
            tournaments.length
        );


        if (!tournamentSelect) {

            console.error(
                "❌ tournamentSelect not found in HTML"
            );

            return;

        }


        tournamentSelect.innerHTML = `

            <option value="">
                Select Tournament
            </option>

        `;


        tournaments.forEach(
            tournament => {

                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    tournament.id;


                option.textContent =
                    tournament.tournamentName ||
                    tournament.name ||
                    "Unnamed Tournament";


                tournamentSelect.appendChild(
                    option
                );

            }
        );


        // =================================================
        // AUTO SELECT
        // =================================================

        if (tournamentId) {

            const found =
                tournaments.find(
                    tournament =>
                        tournament.id ===
                        tournamentId
                );


            if (found) {

                console.log(
                    "✅ Tournament selected:",
                    found.id
                );


                tournamentSelect.value =
                    tournamentId;


                await loadMatches(
                    tournamentId
                );

            }
            else {

                console.warn(
                    "⚠️ Tournament ID not found:",
                    tournamentId
                );


                showMessage(
                    "Tournament ID not found.",
                    "error"
                );

            }

        }
        else {

            console.log(
                "ℹ️ No tournament selected."
            );


            showMessage(
                "Please select a tournament.",
                "info"
            );

        }

    }
    catch (error) {

        console.error(
            "❌ TOURNAMENT LOAD ERROR:",
            error
        );


        showMessage(
            error.message ||
            "Unable to load tournaments.",
            "error"
        );

    }

}


// =====================================================
// LOAD MATCHES
// =====================================================

async function loadMatches(
    selectedTournamentId
) {

    console.log(
        "🏏 Loading matches:",
        selectedTournamentId
    );


    matches = [];


    renderMatches();


    if (!selectedTournamentId) {

        console.log(
            "ℹ️ No tournament selected."
        );

        return;

    }


    // =================================================
    // EXACT PATH
    // =================================================

    const path =
        `tournaments/${selectedTournamentId}/matches`;


    console.log(
        "📂 MATCH PATH:",
        path
    );


    try {

        const matchesRef =
            collection(
                db,
                "tournaments",
                selectedTournamentId,
                "matches"
            );


        const snapshot =
            await getDocs(
                matchesRef
            );


        console.log(
            "🏏 MATCHES FOUND:",
            snapshot.size
        );


        snapshot.forEach(
            matchDoc => {

                const data =
                    matchDoc.data();


                console.log(
                    "🏏 MATCH DOCUMENT:",
                    matchDoc.id,
                    data
                );


                matches.push({

                    id:
                        matchDoc.id,

                    ...data

                });

            }
        );


        // =================================================
        // SORT
        // =================================================

        matches.sort(
            (a, b) => {

                const aNumber =
                    Number(
                        a.matchNumber || 0
                    );


                const bNumber =
                    Number(
                        b.matchNumber || 0
                    );


                return (
                    aNumber -
                    bNumber
                );

            }
        );


        renderMatches();


        if (matches.length > 0) {

            showMessage(
                `✅ ${matches.length} match(es) loaded.`,
                "success"
            );

        }
        else {

            showMessage(
                "⚠️ No matches found in this tournament.",
                "info"
            );

        }

    }
    catch (error) {

        console.error(
            "❌ MATCH LOAD ERROR:",
            error
        );


        showMessage(
            error.message ||
            "Unable to load matches.",
            "error"
        );


        renderMatches();

    }

}


// =====================================================
// STATUS
// =====================================================

function getStatus(
    match
) {

    const rawStatus =
        String(
            match.status ||
            ""
        )
        .trim()
        .toLowerCase();


    if (
        rawStatus ===
        "live"
    ) {

        return "Live";

    }


    if (
        rawStatus ===
        "completed"
    ) {

        return "Completed";

    }


    if (
        match.winner ||
        match.result
    ) {

        return "Completed";

    }


    return "Scheduled";

}


// =====================================================
// RENDER MATCHES
// =====================================================

function renderMatches() {

    if (!matchesTable) {

        console.error(
            "❌ matchesTable not found"
        );

        return;

    }


    // =================================================
    // STATS
    // =================================================

    const scheduled =
        matches.filter(
            match =>
                getStatus(match) ===
                "Scheduled"
        ).length;


    const live =
        matches.filter(
            match =>
                getStatus(match) ===
                "Live"
        ).length;


    const completed =
        matches.filter(
            match =>
                getStatus(match) ===
                "Completed"
        ).length;


    const results =
        matches.filter(
            match =>
                match.winner ||
                match.result
        ).length;


    if (totalMatches) {

        totalMatches.textContent =
            matches.length;

    }


    if (scheduledMatches) {

        scheduledMatches.textContent =
            scheduled;

    }


    if (liveMatches) {

        liveMatches.textContent =
            live;

    }


    if (completedMatches) {

        completedMatches.textContent =
            completed;

    }


    if (resultsCount) {

        resultsCount.textContent =
            results;

    }


    // =================================================
    // FILTER
    // =================================================

    const selectedStatus =
        statusFilter
        ?
        statusFilter.value
        :
        "";


    const search =
        searchInput
        ?
        searchInput.value
            .trim()
            .toLowerCase()
        :
        "";


    const filtered =
        matches.filter(
            match => {

                const status =
                    getStatus(match);


                if (
                    selectedStatus &&
                    status !==
                    selectedStatus
                ) {

                    return false;

                }


                const searchText = [

                    match.matchNumber,

                    match.team1Name,

                    match.team2Name,

                    match.teamA,

                    match.teamB,

                    match.venue,

                    match.winner,

                    match.result,

                    match.matchDate,

                    match.date

                ]
                .join(" ")
                .toLowerCase();


                return searchText.includes(
                    search
                );

            }
        );


    // =================================================
    // EMPTY
    // =================================================

    if (
        filtered.length ===
        0
    ) {

        matchesTable.innerHTML = `

            <tr>

                <td
                    colspan="10"
                    class="empty"
                >

                    ${
                        matches.length === 0
                        ?
                        "🏏 No matches found."
                        :
                        "🔍 No matching matches."
                    }

                </td>

            </tr>

        `;

        return;

    }


    // =================================================
    // TABLE
    // =================================================

    matchesTable.innerHTML =

        filtered
        .map(
            match => {

                const team1 =
                    match.team1Name ||
                    match.teamA ||
                    "Team 1";


                const team2 =
                    match.team2Name ||
                    match.teamB ||
                    "Team 2";


                const scoreA =
                    match.scoreA ||
                    "0/0";


                const scoreB =
                    match.scoreB ||
                    "0/0";


                const date =
                    match.matchDate ||
                    match.date ||
                    "—";


                const time =
                    match.matchTime ||
                    match.time ||
                    "—";


                const venue =
                    match.venue ||
                    "—";


                const status =
                    getStatus(match);


                const winner =
                    match.winner ||
                    "";


                const result =
                    match.result ||
                    "";


                // =================================================
                // COMMENTARY URL
                // =================================================

                const commentaryUrl =
    `commentary.html?tournamentId=${encodeURIComponent(
        tournamentId
    )}&matchId=${encodeURIComponent(
        match.id
    )}`;


// =================================================
                // LIVE SCORE URL
                // =================================================

                const liveScoreUrl =
                    `live-score.html?tournamentId=${encodeURIComponent(
                        tournamentId
                    )}&matchId=${encodeURIComponent(
                        match.id
                    )}`;


                return `

                    <tr>

                        <!-- MATCH -->

                        <td>

                            <strong>
                                Match
                                ${escapeHtml(
                                    match.matchNumber ||
                                    "—"
                                )}
                            </strong>

                        </td>


                        <!-- TEAMS -->

                        <td>

                            <strong>
                                ${escapeHtml(team1)}
                            </strong>

                            <div class="vs">
                                VS
                            </div>

                            <strong>
                                ${escapeHtml(team2)}
                            </strong>

                        </td>


                        <!-- SCORE -->

                        <td>

                            <div class="score">
                                ${escapeHtml(scoreA)}
                            </div>

                            <div class="vs">
                                vs
                            </div>

                            <div class="score">
                                ${escapeHtml(scoreB)}
                            </div>

                        </td>


                        <!-- DATE -->

                        <td>
                            ${escapeHtml(date)}
                        </td>


                        <!-- TIME -->

                        <td>
                            ${escapeHtml(time)}
                        </td>


                        <!-- VENUE -->

                        <td>
                            ${escapeHtml(venue)}
                        </td>


                        <!-- STATUS -->

                        <td>

                            <span
                                class="
                                    status
                                    status-${status.toLowerCase()}
                                "
                            >

                                ${escapeHtml(status)}

                            </span>

                        </td>


                        <!-- WINNER -->

                        <td>

                            ${
                                winner
                                ?
                                `
                                <span class="winner">
                                    🏆
                                    ${escapeHtml(winner)}
                                </span>
                                `
                                :
                                "—"
                            }

                        </td>


                        <!-- RESULT -->

                        <td>

                            ${
                                result
                                ?
                                escapeHtml(result)
                                :
                                "—"
                            }

                        </td>


                        <!-- ACTIONS -->

                        <td>

                            <div class="action-box">

                                <a
                                    href="${commentaryUrl}"
                                    class="
                                        action-btn
                                        commentary-btn
                                    "
                                >
                                    📝 Commentary
                                </a>


                                <a
                                    href="${liveScoreUrl}"
                                    class="
                                        action-btn
                                        live-btn
                                    "
                                >
                                    🏏 Live Score
                                </a>

                            </div>

                        </td>

                    </tr>

                `;

            }
        )
        .join("");

}


// =====================================================
// TOURNAMENT CHANGE
// =====================================================

if (tournamentSelect) {

    tournamentSelect.addEventListener(
        "change",
        async () => {

            const selected =
                tournamentSelect.value;


            console.log(
                "🏆 TOURNAMENT CHANGED:",
                selected
            );


            if (selected) {

                tournamentId =
                    selected;


                localStorage.setItem(
                    "tournamentId",
                    selected
                );


                localStorage.setItem(
                    "currentTournamentId",
                    selected
                );

            }


            await loadMatches(
                selected
            );

        }
    );

}


// =====================================================
// STATUS FILTER
// =====================================================

if (statusFilter) {

    statusFilter.addEventListener(
        "change",
        () => {

            renderMatches();

        }
    );

}


// =====================================================
// SEARCH
// =====================================================

if (searchInput) {

    searchInput.addEventListener(
        "input",
        () => {

            renderMatches();

        }
    );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// START
// =====================================================

loadTournaments();


console.log(
    "✅ CRICKMATE ADMIN-MATCHES.JS READY"
);