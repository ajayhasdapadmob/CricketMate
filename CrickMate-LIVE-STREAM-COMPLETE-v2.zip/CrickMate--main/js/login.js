import {
    auth
} from "./firebase.js";

import {
    signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";


console.log(
    "🔐 CRICKMATE LOGIN.JS STARTED"
);


const form =
    document.getElementById(
        "loginForm"
    );

const message =
    document.getElementById(
        "loginMessage"
    );

const submitBtn =
    document.getElementById(
        "loginSubmit"
    );


/* =========================================================
   MESSAGE
========================================================= */

function showMessage(
    text,
    type = "error"
) {

    if (!message) return;

    message.textContent = text;

    message.className =
        "auth-message " + type;

}


/* =========================================================
   LOGIN
========================================================= */

if (form) {

    form.addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();


            const email =
                document
                    .getElementById("email")
                    .value
                    .trim();

            const password =
                document
                    .getElementById("password")
                    .value;


            if (!email || !password) {

                showMessage(
                    "Please enter email and password."
                );

                return;

            }


            submitBtn.disabled = true;

            submitBtn.textContent =
                "Logging in...";


            try {

                const result =
                    await signInWithEmailAndPassword(
                        auth,
                        email,
                        password
                    );


                console.log(
                    "✅ Login successful:",
                    result.user.uid
                );


                showMessage(
                    "Login successful! Opening CrickMate...",
                    "success"
                );


                setTimeout(
                    () => {

                        window.location.href =
                            "./dashboard.html";

                    },
                    800
                );


            } catch (error) {

                console.error(
                    "❌ Login error:",
                    error
                );


                let text =
                    "Login failed. Please try again.";


                if (
                    error.code ===
                    "auth/invalid-credential"
                ) {

                    text =
                        "Invalid email or password.";

                } else if (
                    error.code ===
                    "auth/user-not-found"
                ) {

                    text =
                        "No account found with this email.";

                } else if (
                    error.code ===
                    "auth/wrong-password"
                ) {

                    text =
                        "Incorrect password.";

                } else if (
                    error.code ===
                    "auth/invalid-email"
                ) {

                    text =
                        "Please enter a valid email.";

                }


                showMessage(text);


                submitBtn.disabled = false;

                submitBtn.textContent =
                    "Login";

            }

        }
    );

}


console.log(
    "✅ CRICKMATE LOGIN READY"
);