// =====================================================
// CRICKMATE - CREATE TOURNAMENT
// =====================================================

import {
    auth,
    db
} from "./firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    collection,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log(
    "🏆 CRICKMATE CREATE TOURNAMENT JS STARTED"
);


// =====================================================
// ELEMENTS
// =====================================================

const form =
    document.getElementById(
        "tournamentForm"
    );

const createBtn =
    document.getElementById(
        "createBtn"
    );

const message =
    document.getElementById(
        "message"
    );


// =====================================================
// SHOW MESSAGE
// =====================================================

function showMessage(
    text,
    type
) {

    message.textContent =
        text;

    message.className =
        `message show ${type}`;

}


// =====================================================
// AUTH USER
// =====================================================

let currentUser =
    null;


onAuthStateChanged(
    auth,
    (user) => {

        if (!user) {

            console.log(
                "❌ User not logged in"
            );

            showMessage(
                "Please login first to create a tournament.",
                "error"
            );

            createBtn.disabled =
                true;

            return;

        }


        currentUser =
            user;


        console.log(
            "✅ Logged in user:",
            user.uid
        );


        createBtn.disabled =
            false;

    }
);


// =====================================================
// FORM SUBMIT
// =====================================================

form.addEventListener(
    "submit",
    async (event) => {

        event.preventDefault();


        console.log(
            "🚀 CREATE TOURNAMENT SUBMITTED"
        );


        // ---------------------------------------------
        // AUTH CHECK
        // ---------------------------------------------

        if (!currentUser) {

            showMessage(
                "Please login first.",
                "error"
            );

            return;

        }


        // ---------------------------------------------
        // VALUES
        // ---------------------------------------------

        const tournamentName =
            document
                .getElementById(
                    "tournamentName"
                )
                .value
                .trim();


        const shortName =
            document
                .getElementById(
                    "shortName"
                )
                .value
                .trim();


        const tournamentType =
            document
                .getElementById(
                    "tournamentType"
                )
                .value;


        const startDate =
            document
                .getElementById(
                    "startDate"
                )
                .value;


        const endDate =
            document
                .getElementById(
                    "endDate"
                )
                .value;


        const venue =
            document
                .getElementById(
                    "venue"
                )
                .value
                .trim();


        const city =
            document
                .getElementById(
                    "city"
                )
                .value
                .trim();


        const organizer =
            document
                .getElementById(
                    "organizer"
                )
                .value
                .trim();


        const description =
            document
                .getElementById(
                    "description"
                )
                .value
                .trim();


        // ---------------------------------------------
        // VALIDATION
        // ---------------------------------------------

        if (!tournamentName) {

            showMessage(
                "Please enter tournament name.",
                "error"
            );

            return;

        }


        if (!tournamentType) {

            showMessage(
                "Please select tournament type.",
                "error"
            );

            return;

        }


        if (!startDate) {

            showMessage(
                "Please select start date.",
                "error"
            );

            return;

        }


        if (!endDate) {

            showMessage(
                "Please select end date.",
                "error"
            );

            return;

        }


        if (
            endDate <
            startDate
        ) {

            showMessage(
                "End date cannot be before start date.",
                "error"
            );

            return;

        }


        // ---------------------------------------------
        // BUTTON
        // ---------------------------------------------

        createBtn.disabled =
            true;

        createBtn.textContent =
            "⏳ Creating Tournament...";


        showMessage(
            "Creating tournament...",
            "info"
        );


        try {

            // =========================================
            // FIRESTORE
            // =========================================

            const tournamentsRef =
                collection(
                    db,
                    "tournaments"
                );


            const tournamentData = {

                name:
                    tournamentName,

                shortName:
                    shortName,

                type:
                    tournamentType,

                startDate:
                    startDate,

                endDate:
                    endDate,

                venue:
                    venue,

                city:
                    city,

                organizer:
                    organizer,

                description:
                    description,

                ownerId:
                    currentUser.uid,

                ownerEmail:
                    currentUser.email || "",

                status:
                    "active",

                createdAt:
                    serverTimestamp(),

                updatedAt:
                    serverTimestamp()

            };


            // =========================================
            // CREATE TOURNAMENT
            // =========================================

            const tournamentDoc =
                await addDoc(
                    tournamentsRef,
                    tournamentData
                );


            const tournamentId =
                tournamentDoc.id;


            console.log(
                "✅ TOURNAMENT CREATED"
            );

            console.log(
                "🏆 Tournament ID:",
                tournamentId
            );


            // =========================================
            // SUCCESS
            // =========================================

            showMessage(
                `✅ ${tournamentName} created successfully!`,
                "success"
            );


            createBtn.textContent =
                "✅ Tournament Created";


            // =========================================
            // SAVE LAST TOURNAMENT
            // =========================================

            localStorage.setItem(
                "crickmateTournamentId",
                tournamentId
            );


            // =========================================
            // REDIRECT
            // =========================================

            setTimeout(
                () => {

                    window.location.href =
                        `./tournament.html?id=${encodeURIComponent(tournamentId)}`;

                },
                1200
            );


        } catch (error) {

            console.error(
                "❌ CREATE TOURNAMENT ERROR:",
                error
            );

            console.error(
                "❌ ERROR CODE:",
                error.code
            );

            console.error(
                "❌ ERROR MESSAGE:",
                error.message
            );


            let errorText =
                "Unable to create tournament.";


            if (
                error.code ===
                "permission-denied"
            ) {

                errorText =
                    "Firestore permission denied. Please check Firestore Rules.";

            }

            else if (
                error.code ===
                "unauthenticated"
            ) {

                errorText =
                    "Your login session expired. Please login again.";

            }

            else if (
                error.code ===
                "failed-precondition"
            ) {

                errorText =
                    "Firestore is not ready. Please check Firebase setup.";

            }

            else if (
                error.message
            ) {

                errorText =
                    error.message;

            }


            showMessage(
                errorText,
                "error"
            );


            createBtn.disabled =
                false;

            createBtn.textContent =
                "🏆 Create Tournament";

        }

    }
);


console.log(
    "✅ CRICKMATE CREATE TOURNAMENT READY"
);