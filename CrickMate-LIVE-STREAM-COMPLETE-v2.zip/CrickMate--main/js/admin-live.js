// =====================================================
// CRICKMATE - ADMIN LIVE
// Camera + Match Loader
// =====================================================

import {
    auth,
    db
} from "./firebase.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🔥 CRICKMATE ADMIN LIVE START");


// =====================================================
// ELEMENTS
// =====================================================

const matchSelect =
    document.getElementById("matchSelect");

const teamA =
    document.getElementById("teamA");

const teamB =
    document.getElementById("teamB");

const matchInfo =
    document.getElementById("matchInfo");

const cameraPreview =
    document.getElementById("cameraPreview");

const cameraOff =
    document.getElementById("cameraOff");

const streamStatus =
    document.getElementById("streamStatus");

const startLiveBtn =
    document.getElementById("startLiveBtn");

const stopLiveBtn =
    document.getElementById("stopLiveBtn");

const message =
    document.getElementById("message");


// =====================================================
// TOURNAMENT ID
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );

let tournamentId =
    params.get("tournamentId");


if (!tournamentId) {

    tournamentId =
        localStorage.getItem(
            "tournamentId"
        );
}


if (!tournamentId) {

    tournamentId =
        localStorage.getItem(
            "crickmateTournamentId"
        );
}


if (!tournamentId) {

    tournamentId =
        localStorage.getItem(
            "selectedTournamentId"
        );
}


console.log(
    "🏆 TOURNAMENT ID:",
    tournamentId
);


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    error = false
) {

    if (!message) return;

    message.textContent = text;

    message.style.display = "block";

    message.classList.toggle(
        "error",
        error
    );

}


// =====================================================
// AUTH
// =====================================================

onAuthStateChanged(
    auth,
    async (user) => {

        console.log(
            "🔐 CURRENT USER:",
            user
        );


        if (!user) {

            showMessage(
                "Please login first.",
                true
            );

            return;
        }


        console.log(
            "✅ USER LOGGED IN:",
            user.uid
        );


        if (!tournamentId) {

            showMessage(
                "Tournament ID missing.",
                true
            );

            return;
        }


        await loadMatches();

    }
);


// =====================================================
// LOAD MATCHES
// =====================================================

async function loadMatches() {

    console.log(
        "🏏 LOADING MATCHES..."
    );


    try {

        const matchesRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "matches"
            );


        const snapshot =
            await getDocs(
                matchesRef
            );


        console.log(
            "🏏 MATCHES FOUND:",
            snapshot.size
        );


        if (!matchSelect) {

            console.error(
                "❌ matchSelect NOT FOUND"
            );

            return;
        }


        matchSelect.innerHTML = "";


        if (snapshot.empty) {

            const option =
                document.createElement(
                    "option"
                );

            option.value = "";

            option.textContent =
                "No matches found";

            matchSelect.appendChild(
                option
            );

            console.warn(
                "⚠️ NO MATCHES FOUND"
            );

            return;
        }


        const firstOption =
            document.createElement(
                "option"
            );

        firstOption.value = "";

        firstOption.textContent =
            "Select Match";

        matchSelect.appendChild(
            firstOption
        );


        snapshot.forEach(
            (matchDoc) => {

                const data =
                    matchDoc.data();


                console.log(
                    "🏏 MATCH:",
                    matchDoc.id,
                    data
                );


                const match =
                    getMatchTeams(
                        data
                    );


                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    matchDoc.id;


                option.dataset.teamA =
                    match.teamA;


                option.dataset.teamB =
                    match.teamB;


                option.textContent =
                    `${match.teamA} VS ${match.teamB}`;


                matchSelect.appendChild(
                    option
                );

            }
        );


        console.log(
            "✅ MATCH LIST READY"
        );


        // Automatically select first match

        if (snapshot.size === 1) {

            matchSelect.selectedIndex = 1;

            showSelectedMatch();

        }

    } catch (error) {

        console.error(
            "❌ MATCH LOAD ERROR:",
            error
        );


        if (matchSelect) {

            matchSelect.innerHTML = `
                <option value="">
                    Match loading error
                </option>
            `;

        }

        showMessage(
            error.message ||
            "Unable to load matches.",
            true
        );

    }

}


// =====================================================
// GET TEAM NAMES
// =====================================================

function getMatchTeams(data) {

    const teamA =
        data.teamA ||
        data.team1 ||
        data.teamAName ||
        data.team1Name ||
        data.homeTeam ||
        data.homeTeamName ||
        data.battingTeam ||
        "Team A";


    const teamB =
        data.teamB ||
        data.team2 ||
        data.teamBName ||
        data.team2Name ||
        data.awayTeam ||
        data.awayTeamName ||
        data.bowlingTeam ||
        "Team B";


    return {
        teamA: String(teamA),
        teamB: String(teamB)
    };

}


// =====================================================
// MATCH SELECT
// =====================================================

if (matchSelect) {

    matchSelect.addEventListener(
        "change",
        showSelectedMatch
    );

}


function showSelectedMatch() {

    if (!matchSelect) return;


    const option =
        matchSelect.options[
            matchSelect.selectedIndex
        ];


    if (
        !option ||
        !option.value
    ) {

        if (matchInfo) {

            matchInfo.style.display =
                "none";

        }

        return;
    }


    const selectedTeamA =
        option.dataset.teamA ||
        "Team A";


    const selectedTeamB =
        option.dataset.teamB ||
        "Team B";


    if (teamA) {

        teamA.textContent =
            selectedTeamA;

    }


    if (teamB) {

        teamB.textContent =
            selectedTeamB;

    }


    if (matchInfo) {

        matchInfo.style.display =
            "block";

    }


    console.log(
        "🏏 SELECTED MATCH:",
        option.value
    );

}


// =====================================================
// START CAMERA
// =====================================================

if (startLiveBtn) {

    startLiveBtn.addEventListener(
        "click",
        startCamera
    );

}


async function startCamera() {

    console.log(
        "🔴 START LIVE CLICKED"
    );


    const user =
        auth.currentUser;


    if (!user) {

        showMessage(
            "Please login first.",
            true
        );

        return;
    }


    if (!matchSelect ||
        !matchSelect.value) {

        showMessage(
            "Please select a match first.",
            true
        );

        return;
    }


    if (
        !navigator.mediaDevices ||
        !navigator.mediaDevices.getUserMedia
    ) {

        showMessage(
            "Camera is not supported in this browser.",
            true
        );

        return;
    }


    try {

        console.log(
            "📷 REQUESTING CAMERA..."
        );


        const stream =
            await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true
            });


        cameraPreview.srcObject =
            stream;


        cameraPreview.play();


        if (cameraOff) {

            cameraOff.style.display =
                "none";

        }


        if (streamStatus) {

            streamStatus.innerHTML =
                '<span class="live">🔴 CAMERA READY</span>';

        }


        startLiveBtn.style.display =
            "none";


        stopLiveBtn.style.display =
            "block";


        showMessage(
            "Camera started successfully."
        );


        console.log(
            "✅ CAMERA READY"
        );


    } catch (error) {

        console.error(
            "❌ CAMERA ERROR:",
            error
        );


        showMessage(
            "Camera permission denied or camera unavailable.",
            true
        );

    }

}


// =====================================================
// STOP CAMERA
// =====================================================

if (stopLiveBtn) {

    stopLiveBtn.addEventListener(
        "click",
        stopCamera
    );

}


function stopCamera() {

    console.log(
        "⛔ STOP LIVE CLICKED"
    );


    if (
        cameraPreview &&
        cameraPreview.srcObject
    ) {

        const tracks =
            cameraPreview
                .srcObject
                .getTracks();


        tracks.forEach(
            track => track.stop()
        );


        cameraPreview.srcObject =
            null;

    }


    if (cameraOff) {

        cameraOff.style.display =
            "flex";

    }


    if (streamStatus) {

        streamStatus.textContent =
            "Camera is not started";

    }


    startLiveBtn.style.display =
        "block";


    stopLiveBtn.style.display =
        "none";


    showMessage(
        "Camera stopped."
    );

}


// =====================================================
// PAGE READY
// =====================================================

console.log(
    "🚀 CRICKMATE ADMIN LIVE READY"
);