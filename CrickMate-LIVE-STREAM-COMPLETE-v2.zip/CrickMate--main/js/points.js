// =====================================================
// CRICKMATE - POINTS.JS
// AUTOMATIC POINTS TABLE
// =====================================================

import { db } from "./firebase.js";

import {
    doc,
    getDoc,
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🔥 CRICKMATE FIREBASE INITIALIZED");
console.log("🏆 CRICKMATE POINTS.JS STARTED");


// =====================================================
// URL PARAMETERS
// =====================================================

const params =
    new URLSearchParams(window.location.search);


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// ELEMENTS
// =====================================================

const loading =
    document.getElementById("loading");

const pointsPage =
    document.getElementById("pointsPage");

const message =
    document.getElementById("message");

const tournamentNameEl =
    document.getElementById("tournamentName");

const tableBody =
    document.getElementById("pointsTableBody");

const emptyMessage =
    document.getElementById("emptyMessage");

const backBtn =
    document.getElementById("backBtn");


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            `dashboard.html?tournamentId=${encodeURIComponent(
                tournamentId
            )}`;

    }
    else {

        backBtn.href =
            "dashboard.html";

    }

}


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "success"
) {

    if (!message) {
        return;
    }

    message.textContent =
        text;

    message.className =
        `message show ${type}`;

}


// =====================================================
// VALIDATION
// =====================================================

if (!tournamentId) {

    console.error(
        "❌ Tournament ID missing"
    );

    showMessage(
        "Tournament ID missing.",
        "error"
    );

    if (loading) {

        loading.textContent =
            "❌ Tournament ID missing.";

    }

}
else {

    loadPointsTable();

}


// =====================================================
// LOAD POINTS TABLE
// =====================================================

async function loadPointsTable() {

    console.log(
        "🚀 Loading points table..."
    );

    try {

        // =================================================
        // LOAD TOURNAMENT
        // =================================================

        const tournamentRef =
            doc(
                db,
                "tournaments",
                tournamentId
            );


        const tournamentSnap =
            await getDoc(
                tournamentRef
            );


        if (
            tournamentSnap.exists()
        ) {

            const tournament =
                tournamentSnap.data();


            console.log(
                "📂 TOURNAMENT DATA:",
                tournament
            );


            if (tournamentNameEl) {

                tournamentNameEl.textContent =
                    tournament.tournamentName ||
                    tournament.name ||
                    "CrickMate Tournament";

            }

        }
        else {

            if (tournamentNameEl) {

                tournamentNameEl.textContent =
                    "CrickMate Tournament";

            }

        }


        // =================================================
        // LOAD TEAMS
        // =================================================

        console.log(
            "👥 Loading teams..."
        );


        const teamsRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "teams"
            );


        const teamsSnap =
            await getDocs(
                teamsRef
            );


        console.log(
            "🏏 TEAM COUNT:",
            teamsSnap.size
        );


        const teams = [];


        teamsSnap.forEach(
            teamDoc => {

                const data =
                    teamDoc.data();


                teams.push({

                    id:
                        teamDoc.id,

                    ...data

                });

            }
        );


        // =================================================
        // LOAD MATCHES
        // =================================================

        console.log(
            "🏏 Loading matches..."
        );


        const matchesRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "matches"
            );


        const matchesSnap =
            await getDocs(
                matchesRef
            );


        console.log(
            "🏏 MATCH COUNT:",
            matchesSnap.size
        );


        const matches = [];


        matchesSnap.forEach(
            matchDoc => {

                matches.push({

                    id:
                        matchDoc.id,

                    ...matchDoc.data()

                });

            }
        );


        // =================================================
        // CREATE TABLE
        // =================================================

        const standings =
            createStandings(
                teams,
                matches
            );


        // =================================================
        // SORT
        // =================================================

        standings.sort(
            (a, b) => {

                // Points first
                if (
                    b.points !==
                    a.points
                ) {

                    return (
                        b.points -
                        a.points
                    );

                }


                // NRR second
                if (
                    b.nrr !==
                    a.nrr
                ) {

                    return (
                        b.nrr -
                        a.nrr
                    );

                }


                // Wins third
                if (
                    b.won !==
                    a.won
                ) {

                    return (
                        b.won -
                        a.won
                    );

                }


                return 0;

            }
        );


        // =================================================
        // DISPLAY
        // =================================================

        renderTable(
            standings
        );


        if (loading) {

            loading.style.display =
                "none";

        }


        if (pointsPage) {

            pointsPage.style.display =
                "block";

        }


        console.log(
            "✅ POINTS TABLE DISPLAYED"
        );

    }
    catch (error) {

        console.error(
            "❌ POINTS TABLE ERROR:",
            error
        );


        showMessage(
            error.message ||
            "Unable to load points table.",
            "error"
        );


        if (loading) {

            loading.textContent =
                "❌ Unable to load points table.";

        }

    }

}


// =====================================================
// CREATE STANDINGS
// =====================================================

function createStandings(
    teams,
    matches
) {

    const table = {};


    // =================================================
    // ADD ALL TEAMS
    // =================================================

    teams.forEach(
        team => {

            const teamId =
                team.id;


            const teamName =
                team.teamName ||
                team.name ||
                team.team ||
                team.title ||
                "Unknown Team";


            table[teamId] = {

                id:
                    teamId,

                name:
                    teamName,

                played: 0,

                won: 0,

                lost: 0,

                nr: 0,

                points: 0,

                nrr: Number(
                    team.nrr || 0
                ),

                runsFor: Number(
                    team.runsFor || 0
                ),

                runsAgainst: Number(
                    team.runsAgainst || 0
                ),

                ballsFor: Number(
                    team.ballsFor || 0
                ),

                ballsAgainst: Number(
                    team.ballsAgainst || 0
                )

            };

        }
    );


    // =================================================
    // PROCESS MATCHES
    // =================================================

    matches.forEach(
        match => {

            const team1Id =
                match.team1Id ||
                match.teamAId;


            const team2Id =
                match.team2Id ||
                match.teamBId;


            if (
                !team1Id ||
                !team2Id
            ) {

                return;

            }


            // If teams are not in team collection,
            // create them automatically.

            if (!table[team1Id]) {

                table[team1Id] = {

                    id:
                        team1Id,

                    name:
                        match.team1Name ||
                        match.teamA ||
                        "Team 1",

                    played: 0,

                    won: 0,

                    lost: 0,

                    nr: 0,

                    points: 0,

                    nrr: 0,

                    runsFor: 0,

                    runsAgainst: 0,

                    ballsFor: 0,

                    ballsAgainst: 0

                };

            }


            if (!table[team2Id]) {

                table[team2Id] = {

                    id:
                        team2Id,

                    name:
                        match.team2Name ||
                        match.teamB ||
                        "Team 2",

                    played: 0,

                    won: 0,

                    lost: 0,

                    nr: 0,

                    points: 0,

                    nrr: 0,

                    runsFor: 0,

                    runsAgainst: 0,

                    ballsFor: 0,

                    ballsAgainst: 0

                };

            }


            // =================================================
            // ONLY COMPLETED MATCHES
            // =================================================

            const status =
                String(
                    match.status ||
                    ""
                ).toLowerCase();


            const result =
                String(
                    match.result ||
                    ""
                ).toLowerCase();


            const isCompleted =
                status === "completed" ||
                result.includes("won") ||
                result.includes("tie") ||
                result.includes("tied");


            if (!isCompleted) {

                return;

            }


            // =================================================
            // PLAYED
            // =================================================

            table[team1Id].played++;

            table[team2Id].played++;


            // =================================================
            // SCORES
            // =================================================

            const scoreA =
                parseScore(
                    match.scoreA
                );


            const scoreB =
                parseScore(
                    match.scoreB
                );


            table[team1Id].runsFor +=
                scoreA.runs;


            table[team1Id].runsAgainst +=
                scoreB.runs;


            table[team2Id].runsFor +=
                scoreB.runs;


            table[team2Id].runsAgainst +=
                scoreA.runs;


            // =================================================
            // WINNER
            // =================================================

            const winner =
                match.winner;


            if (
                winner &&
                winner !== "Tie"
            ) {

                const winnerId =
                    getWinnerId(
                        winner,
                        team1Id,
                        team2Id,
                        match,
                        table
                    );


                if (
                    winnerId ===
                    team1Id
                ) {

                    table[team1Id].won++;

                    table[team1Id].points += 2;

                    table[team2Id].lost++;

                }
                else if (
                    winnerId ===
                    team2Id
                ) {

                    table[team2Id].won++;

                    table[team2Id].points += 2;

                    table[team1Id].lost++;

                }

            }
            else if (
                result.includes("tie") ||
                result.includes("tied")
            ) {

                table[team1Id].nr++;

                table[team2Id].nr++;

                table[team1Id].points += 1;

                table[team2Id].points += 1;

            }
            else {

                // =================================================
                // FALLBACK RESULT DETECTION
                // =================================================

                if (
                    scoreA.runs >
                    scoreB.runs
                ) {

                    table[team1Id].won++;

                    table[team1Id].points += 2;

                    table[team2Id].lost++;

                }
                else if (
                    scoreB.runs >
                    scoreA.runs
                ) {

                    table[team2Id].won++;

                    table[team2Id].points += 2;

                    table[team1Id].lost++;

                }
                else {

                    table[team1Id].nr++;

                    table[team2Id].nr++;

                    table[team1Id].points += 1;

                    table[team2Id].points += 1;

                }

            }

        }
    );


    // =================================================
    // CALCULATE NRR
    // =================================================

    Object.values(table).forEach(
        team => {

            if (
                team.ballsFor > 0 &&
                team.ballsAgainst > 0
            ) {

                const runRateFor =
                    team.runsFor /
                    oversFromBalls(
                        team.ballsFor
                    );


                const runRateAgainst =
                    team.runsAgainst /
                    oversFromBalls(
                        team.ballsAgainst
                    );


                team.nrr =
                    runRateFor -
                    runRateAgainst;

            }
            else {

                // If match data does not contain
                // ball information, calculate
                // approximate NRR from runs.

                if (
                    team.played > 0
                ) {

                    team.nrr =
                        (
                            team.runsFor -
                            team.runsAgainst
                        ) /
                        Math.max(
                            1,
                            team.played
                        );

                }
                else {

                    team.nrr =
                        Number(
                            team.nrr || 0
                        );

                }

            }

        }
    );


    return Object.values(
        table
    );

}


// =====================================================
// WINNER ID
// =====================================================

function getWinnerId(
    winner,
    team1Id,
    team2Id,
    match,
    table
) {

    const winnerText =
        String(
            winner
        )
        .trim()
        .toLowerCase();


    const team1Name =
        String(
            table[team1Id]?.name ||
            match.team1Name ||
            match.teamA ||
            ""
        )
        .trim()
        .toLowerCase();


    const team2Name =
        String(
            table[team2Id]?.name ||
            match.team2Name ||
            match.teamB ||
            ""
        )
        .trim()
        .toLowerCase();


    if (
        winnerText ===
        team1Name
    ) {

        return team1Id;

    }


    if (
        winnerText ===
        team2Name
    ) {

        return team2Id;

    }


    if (
        winnerText.includes(
            team1Name
        )
    ) {

        return team1Id;

    }


    if (
        winnerText.includes(
            team2Name
        )
    ) {

        return team2Id;

    }


    return null;

}


// =====================================================
// RENDER TABLE
// =====================================================

function renderTable(
    standings
) {

    if (!tableBody) {

        console.error(
            "❌ pointsTableBody not found"
        );

        return;

    }


    tableBody.innerHTML = "";


    if (
        !standings.length
    ) {

        if (emptyMessage) {

            emptyMessage.style.display =
                "block";

        }

        return;

    }


    if (emptyMessage) {

        emptyMessage.style.display =
            "none";

    }


    standings.forEach(
        (team, index) => {

            const row =
                document.createElement(
                    "tr"
                );


            if (
                index === 0
            ) {

                row.classList.add(
                    "rank-1"
                );

            }
            else if (
                index === 1
            ) {

                row.classList.add(
                    "rank-2"
                );

            }
            else if (
                index === 2
            ) {

                row.classList.add(
                    "rank-3"
                );

            }


            const nrrText =
                Number(
                    team.nrr || 0
                ).toFixed(3);


            row.innerHTML = `

                <td class="position">
                    ${index + 1}
                </td>

                <td class="team-name">
                    ${escapeHtml(
                        team.name
                    )}
                </td>

                <td>
                    ${team.played}
                </td>

                <td>
                    ${team.won}
                </td>

                <td>
                    ${team.lost}
                </td>

                <td>
                    ${team.nr}
                </td>

                <td class="nrr">
                    ${nrrText}
                </td>

                <td class="points">
                    ${team.points}
                </td>

            `;


            tableBody.appendChild(
                row
            );

        }
    );

}


// =====================================================
// SCORE PARSER
// =====================================================

function parseScore(
    value
) {

    if (
        typeof value ===
        "object" &&
        value !== null
    ) {

        return {

            runs:
                Number(
                    value.runs || 0
                ),

            wickets:
                Number(
                    value.wickets || 0
                )

        };

    }


    const text =
        String(
            value ||
            "0/0"
        );


    const parts =
        text.split("/");


    return {

        runs:
            Number(
                parts[0]
            ) || 0,

        wickets:
            Number(
                parts[1]
            ) || 0

    };

}


// =====================================================
// OVERS FROM BALLS
// =====================================================

function oversFromBalls(
    balls
) {

    const total =
        Number(
            balls || 0
        );


    const completedOvers =
        Math.floor(
            total / 6
        );


    const remainingBalls =
        total % 6;


    return (
        completedOvers +
        (
            remainingBalls /
            6
        )
    );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


console.log(
    "🚀 CRICKMATE POINTS.JS READY"
);