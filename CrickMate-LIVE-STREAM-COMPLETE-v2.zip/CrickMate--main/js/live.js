// =====================================================
// CRICKMATE - LIVE.JS
// ALL / LIVE / COMPLETED / SCHEDULED MATCHES
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE LIVE.JS STARTED");


// =====================================================
// ELEMENTS
// =====================================================

const loading =
    document.getElementById("loading");

const matchesBox =
    document.getElementById("matches");

const tournamentNameEl =
    document.getElementById("tournamentName");


// =====================================================
// DATA
// =====================================================

let allMatches = [];

let currentFilter = "all";


// =====================================================
// LOAD MATCHES
// =====================================================

async function loadMatches() {

    console.log("🔥 Loading ALL matches...");


    try {

        const tournamentsRef =
            collection(
                db,
                "tournaments"
            );


        const tournamentsSnap =
            await getDocs(
                tournamentsRef
            );


        allMatches = [];


        // =================================================
        // ALL TOURNAMENTS
        // =================================================

        for (
            const tournamentDoc
            of tournamentsSnap.docs
        ) {

            const tournamentId =
                tournamentDoc.id;


            const tournament =
                tournamentDoc.data();


            const tournamentName =
                tournament.name ||
                tournament.tournamentName ||
                tournament.title ||
                "Tournament";


            console.log(
                "🏆 Tournament:",
                tournamentName,
                tournamentId
            );


            // =================================================
            // MATCHES
            // =================================================

            const matchesRef =
                collection(
                    db,
                    "tournaments",
                    tournamentId,
                    "matches"
                );


            const matchesSnap =
                await getDocs(
                    matchesRef
                );


            console.log(
                "🏏 Matches:",
                matchesSnap.size
            );


            matchesSnap.forEach(
                matchDoc => {

                    const match =
                        matchDoc.data();


                    allMatches.push({

                        id:
                            matchDoc.id,

                        tournamentId:
                            tournamentId,

                        tournamentName:
                            tournamentName,

                        ...match

                    });

                }
            );

        }


        console.log(
            "🏏 TOTAL MATCHES:",
            allMatches.length
        );


        if (
            tournamentNameEl &&
            allMatches.length
        ) {

            tournamentNameEl.textContent =
                `🏆 ${allMatches[0].tournamentName}`;

        }
        else if (
            tournamentNameEl
        ) {

            tournamentNameEl.textContent =
                "🏆 CrickMate Matches";

        }


        if (loading) {

            loading.style.display =
                "none";

        }


        renderMatches();


    }
    catch (error) {

        console.error(
            "❌ LOAD MATCH ERROR:",
            error
        );


        if (loading) {

            loading.textContent =
                "❌ " +
                (
                    error.message ||
                    "Unable to load matches."
                );

        }

    }

}


// =====================================================
// FILTER
// =====================================================

window.filterMatches =
function(filter) {

    currentFilter =
        filter;


    // =================================================
    // BUTTON ACTIVE
    // =================================================

    document
        .querySelectorAll(".filter button")
        .forEach(
            button => {

                button.classList.remove(
                    "active"
                );

            }
        );


    const buttonMap = {

        all:
            "allBtn",

        live:
            "liveBtn",

        completed:
            "completedBtn",

        scheduled:
            "scheduledBtn"

    };


    const activeButton =
        document.getElementById(
            buttonMap[filter]
        );


    if (activeButton) {

        activeButton.classList.add(
            "active"
        );

    }


    renderMatches();

};


// =====================================================
// RENDER MATCHES
// =====================================================

function renderMatches() {

    if (!matchesBox) {

        return;

    }


    let filtered =
        [...allMatches];


    // =================================================
    // FILTER STATUS
    // =================================================

    if (
        currentFilter !==
        "all"
    ) {

        filtered =
            filtered.filter(
                match => {

                    const status =
                        String(
                            match.status ||
                            "Scheduled"
                        )
                        .trim()
                        .toLowerCase();


                    if (
                        currentFilter ===
                        "live"
                    ) {

                        return (
                            status === "live" ||
                            status === "playing" ||
                            status === "in progress"
                        );

                    }


                    if (
                        currentFilter ===
                        "completed"
                    ) {

                        return (
                            status === "completed"
                        );

                    }


                    if (
                        currentFilter ===
                        "scheduled"
                    ) {

                        return (
                            status === "scheduled" ||
                            status === "upcoming" ||
                            status === ""
                        );

                    }


                    return true;

                }
            );

    }


    // =================================================
    // EMPTY
    // =================================================

    if (!filtered.length) {

        matchesBox.innerHTML = `

            <div class="empty">

                🏏 No
                ${
                    currentFilter === "all"
                    ? ""
                    : currentFilter
                }
                matches found.

            </div>

        `;

        return;

    }


    // =================================================
    // SORT
    // =================================================

    filtered.sort(
        (a, b) => {

            const dateA =
                String(
                    a.date ||
                    a.matchDate ||
                    ""
                );

            const dateB =
                String(
                    b.date ||
                    b.matchDate ||
                    ""
                );

            return dateB.localeCompare(
                dateA
            );

        }
    );


    // =================================================
    // HTML
    // =================================================

    matchesBox.innerHTML =
        filtered
            .map(
                match => {

                    return createMatchHTML(
                        match
                    );

                }
            )
            .join("");


    console.log(
        "✅ MATCHES DISPLAYED:",
        filtered.length
    );

}


// =====================================================
// CREATE MATCH CARD
// =====================================================

function createMatchHTML(
    match
) {

    const team1 =
        match.team1Name ||
        match.teamA ||
        match.team1 ||
        "Team 1";


    const team2 =
        match.team2Name ||
        match.teamB ||
        match.team2 ||
        "Team 2";


    const scoreA =
        match.scoreA ||
        "0/0";


    const scoreB =
        match.scoreB ||
        "0/0";


    const status =
        String(
            match.status ||
            "Scheduled"
        );


    const statusLower =
        status.toLowerCase();


    let statusClass =
        "scheduled";


    let statusIcon =
        "📅";


    if (
        statusLower ===
            "live" ||
        statusLower ===
            "playing" ||
        statusLower ===
            "in progress"
    ) {

        statusClass =
            "live";

        statusIcon =
            "🔴";

    }
    else if (
        statusLower ===
        "completed"
    ) {

        statusClass =
            "completed";

        statusIcon =
            "✅";

    }


    const matchNumber =
        match.matchNumber ||
        match.matchNo ||
        match.number ||
        "";


    const date =
        match.date ||
        match.matchDate ||
        "";


    const time =
        match.time ||
        match.matchTime ||
        "";


    const venue =
        match.venue ||
        "Venue not available";


    const result =
        match.result ||
        match.winner ||
        "";


    const tournament =
        match.tournamentName ||
        "Tournament";


    const liveScoreURL =
        `live-score.html?tournamentId=${
            encodeURIComponent(
                match.tournamentId
            )
        }&matchId=${
            encodeURIComponent(
                match.id
            )
        }`;


    const commentaryURL =
        `commentary.html?tournamentId=${
            encodeURIComponent(
                match.tournamentId
            )
        }&matchId=${
            encodeURIComponent(
                match.id
            )
        }`;


    return `

        <div class="match-card">

            <div class="match-number">

                ${
                    matchNumber
                    ?
                    `🏏 Match ${escapeHtml(matchNumber)}`
                    :
                    "🏏 Match"
                }

            </div>


            <div class="tournament-name">

                🏆
                ${escapeHtml(tournament)}

            </div>


            <div class="teams">

                <div class="team">

                    ${escapeHtml(team1)}

                    <div class="score">

                        ${escapeHtml(scoreA)}

                    </div>

                </div>


                <div class="vs">

                    VS

                </div>


                <div class="team">

                    ${escapeHtml(team2)}

                    <div class="score">

                        ${escapeHtml(scoreB)}

                    </div>

                </div>

            </div>


            <div>

                <span
                    class="status ${statusClass}"
                >

                    ${statusIcon}
                    ${escapeHtml(status)}

                </span>

            </div>


            ${
                result
                ?
                `
                <div class="result">

                    🏆
                    ${escapeHtml(result)}

                </div>
                `
                :
                ""
            }


            <div class="result">

                📅 ${escapeHtml(date)}

                ${
                    time
                    ?
                    ` &nbsp; ⏰ ${escapeHtml(time)}`
                    :
                    ""
                }

                <br>

                📍 ${escapeHtml(venue)}

            </div>


            <div class="buttons">

                <a
                    class="btn"
                    href="${liveScoreURL}"
                >

                    🏏 Live Score

                </a>


                <a
                    class="btn commentary"
                    href="${commentaryURL}"
                >

                    📝 Commentary

                </a>

            </div>

        </div>

    `;

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// START
// =====================================================

loadMatches();


console.log(
    "✅ CRICKMATE LIVE.JS READY"
);