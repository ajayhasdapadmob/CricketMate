// =====================================================
// CRICKMATE LEADERBOARD
// =====================================================

import {
    db
} from "./firebase.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log(
    "🏆 CRICKMATE LEADERBOARD.JS STARTED"
);


// =====================================================
// ELEMENT
// =====================================================

const container =
    document.getElementById(
        "leaderboardContainer"
    );


// =====================================================
// LOAD LEADERBOARD
// =====================================================

async function loadLeaderboard() {

    if (!container) {

        console.error(
            "❌ leaderboardContainer not found"
        );

        return;

    }


    try {

        container.innerHTML = `
            <div class="loading">
                🔄 Loading leaderboard...
            </div>
        `;


        // =============================================
        // LOAD ALL TOURNAMENTS
        // =============================================

        const tournamentsRef =
            collection(
                db,
                "tournaments"
            );


        const tournamentsSnap =
            await getDocs(
                tournamentsRef
            );


        const playersMap =
            new Map();


        // =============================================
        // LOAD PLAYERS FROM TOURNAMENTS
        // =============================================

        for (
            const tournamentDoc
            of tournamentsSnap.docs
        ) {

            const tournamentId =
                tournamentDoc.id;


            const teamsRef =
                collection(
                    db,
                    "tournaments",
                    tournamentId,
                    "teams"
                );


            const teamsSnap =
                await getDocs(
                    teamsRef
                );


            for (
                const teamDoc
                of teamsSnap.docs
            ) {

                const teamId =
                    teamDoc.id;


                const playersRef =
                    collection(
                        db,
                        "tournaments",
                        tournamentId,
                        "teams",
                        teamId,
                        "players"
                    );


                const playersSnap =
                    await getDocs(
                        playersRef
                    );


                playersSnap.forEach(
                    playerDoc => {

                        const data =
                            playerDoc.data();


                        const name =
                            data.playerName ||
                            data.name ||
                            data.fullName ||
                            data.displayName ||
                            "";


                        if (!name) {
                            return;
                        }


                        const key =
                            name
                                .trim()
                                .toLowerCase();


                        if (
                            !playersMap.has(key)
                        ) {

                            playersMap.set(
                                key,
                                {
                                    name:
                                        name.trim(),

                                    runs:
                                        Number(
                                            data.runs || 0
                                        ),

                                    wickets:
                                        Number(
                                            data.wickets || 0
                                        ),

                                    matches:
                                        Number(
                                            data.matches || 0
                                        )
                                }
                            );

                        }

                        else {

                            const player =
                                playersMap.get(
                                    key
                                );


                            player.runs +=
                                Number(
                                    data.runs || 0
                                );


                            player.wickets +=
                                Number(
                                    data.wickets || 0
                                );


                            player.matches +=
                                Number(
                                    data.matches || 0
                                );

                        }

                    }
                );

            }

        }


        // =============================================
        // SORT BY RUNS
        // =============================================

        const players =
            Array.from(
                playersMap.values()
            )
            .sort(
                (a, b) =>
                    b.runs - a.runs
            );


        // =============================================
        // EMPTY
        // =============================================

        if (
            players.length === 0
        ) {

            container.innerHTML = `
                <div class="empty">
                    🏏 No player statistics available yet.
                </div>
            `;

            return;

        }


        // =============================================
        // DISPLAY
        // =============================================

        container.innerHTML = "";


        players
            .slice(0, 50)
            .forEach(
                (player, index) => {

                    const card =
                        document.createElement(
                            "div"
                        );


                    card.className =
                        "leaderboard-card";


                    let rankIcon =
                        `#${index + 1}`;


                    if (index === 0) {
                        rankIcon = "🥇";
                    }

                    else if (index === 1) {
                        rankIcon = "🥈";
                    }

                    else if (index === 2) {
                        rankIcon = "🥉";
                    }


                    card.innerHTML = `

                        <div class="rank">
                            ${rankIcon}
                        </div>

                        <div>

                            <div class="player-name">
                                ${escapeHtml(
                                    player.name
                                )}
                            </div>

                            <div class="player-info">
                                🏏 ${player.matches} Matches
                                &nbsp; • &nbsp;
                                🎯 ${player.wickets} Wickets
                            </div>

                        </div>

                        <div class="player-score">

                            ${player.runs} Runs

                            <span>
                                Runs
                            </span>

                        </div>

                    `;


                    container.appendChild(
                        card
                    );

                }
            );


        console.log(
            "✅ LEADERBOARD DISPLAYED:",
            players.length
        );

    }

    catch (error) {

        console.error(
            "❌ LEADERBOARD ERROR:",
            error
        );


        container.innerHTML = `
            <div class="empty">
                ❌ Leaderboard load nahi ho saka.
            </div>
        `;

    }

}


// =====================================================
// HTML ESCAPE
// =====================================================

function escapeHtml(
    value
) {

    return String(value)
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// START
// =====================================================

loadLeaderboard();