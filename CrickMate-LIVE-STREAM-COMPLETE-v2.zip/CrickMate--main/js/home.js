import {
    db,
    auth
} from "./firebase.js";


console.log(
    "🏏 CRICKMATE HOME.JS STARTED"
);


/* =========================================================
   FIREBASE STATUS
========================================================= */

const firebaseStatus =
    document.getElementById(
        "firebaseStatus"
    );

if (firebaseStatus) {

    firebaseStatus.textContent =
        "CrickMate is connected to Firebase";

}


/* =========================================================
   LOGIN BUTTON
========================================================= */

const loginBtn =
    document.getElementById(
        "loginBtn"
    );

if (loginBtn) {

    loginBtn.addEventListener(
        "click",
        () => {

            window.location.href =
                "./login.html";

        }
    );

}


/* =========================================================
   LIVE BUTTON
========================================================= */

const liveBtn =
    document.getElementById(
        "liveBtn"
    );

if (liveBtn) {

    liveBtn.addEventListener(
        "click",
        () => {

            window.location.href =
                "./live.html";

        }
    );

}


/* =========================================================
   TOURNAMENT BUTTON
========================================================= */

const tournamentBtn =
    document.getElementById(
        "tournamentBtn"
    );

if (tournamentBtn) {

    tournamentBtn.addEventListener(
        "click",
        () => {

            window.location.href =
                "./tournaments.html";

        }
    );

}


console.log(
    "✅ CrickMate HOME READY"
);