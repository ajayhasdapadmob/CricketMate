// =====================================================
// CRICKMATE - MATCHES.JS
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    onSnapshot,
    query,
    orderBy
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE MATCHES.JS STARTED");


// =====================================================
// GET TOURNAMENT ID
// =====================================================

const params =
    new URLSearchParams(window.location.search);

let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


// =====================================================
// CLEAN + SAVE TOURNAMENT ID
// =====================================================

if (tournamentId) {

    tournamentId = tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// HTML ELEMENTS
// =====================================================

const matchesContainer =
    document.getElementById("matchesContainer");

const matchCount =
    document.getElementById("matchCount");

const backBtn =
    document.getElementById("backBtn");


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            `tournament.html?id=${encodeURIComponent(tournamentId)}`;

    } else {

        backBtn.href =
            "my-tournaments.html";

    }

}


// =====================================================
// VALIDATE TOURNAMENT
// =====================================================

if (!tournamentId) {

    showError(
        "Tournament ID missing. Please open Matches from Tournament Centre."
    );

} else {

    loadMatches();

}


// =====================================================
// LOAD MATCHES
// =====================================================

function loadMatches() {

    console.log(
        "🔥 Loading matches for tournament:",
        tournamentId
    );

    console.log(
        "📂 Firebase path:",
        `tournaments/${tournamentId}/matches`
    );


    if (!matchesContainer) {

        console.error(
            "❌ matchesContainer not found in HTML"
        );

        return;

    }


    const matchesRef =
        collection(
            db,
            "tournaments",
            tournamentId,
            "matches"
        );


    const matchesQuery =
        query(
            matchesRef,
            orderBy(
                "createdAt",
                "desc"
            )
        );


    onSnapshot(

        matchesQuery,

        (snapshot) => {

            console.log(
                "🏏 MATCH COUNT:",
                snapshot.size
            );


            if (matchCount) {

                matchCount.textContent =
                    `${snapshot.size} match${snapshot.size === 1 ? "" : "es"}`;

            }


            matchesContainer.innerHTML = "";


            // =================================================
            // NO MATCHES
            // =================================================

            if (snapshot.empty) {

                matchesContainer.innerHTML = `

                    <div class="empty">

                        <div style="
                            font-size:48px;
                            margin-bottom:10px;
                        ">
                            🏏
                        </div>

                        <h3>
                            No Matches Yet
                        </h3>

                        <p>
                            No matches have been created
                            for this tournament.
                        </p>

                    </div>

                `;

                return;

            }


            // =================================================
            // DISPLAY MATCHES
            // =================================================

            snapshot.forEach((docSnap) => {

                const match =
                    docSnap.data();

                const matchId =
                    docSnap.id;


                console.log(
                    "🏏 MATCH:",
                    matchId,
                    match
                );


                const card =
                    createMatchCard(
                        match,
                        matchId
                    );


                matchesContainer.appendChild(
                    card
                );

            });

        },

        (error) => {

            console.error(
                "❌ Error loading matches:",
                error
            );


            showError(
                error.message ||
                "Failed to load matches."
            );

        }

    );

}


// =====================================================
// CREATE MATCH CARD
// =====================================================

function createMatchCard(
    match,
    matchId
) {

    const card =
        document.createElement("div");

    card.className =
        "match-card";


    // =================================================
    // MATCH DATA
    // =================================================

    const matchNumber =
        match.matchNumber ??
        match.matchNo ??
        match.number ??
        "";


    const team1 =
        match.team1Name ||
        match.teamA ||
        "Team 1";


    const team2 =
        match.team2Name ||
        match.teamB ||
        "Team 2";


    const score1 =
        match.scoreA ||
        "—";


    const score2 =
        match.scoreB ||
        "—";


    const winner =
        match.winner ||
        "";


    const result =
        match.result ||
        "";


    const date =
        match.matchDate ||
        match.date ||
        "";


    const time =
        match.matchTime ||
        match.time ||
        "";


    const venue =
        match.venue ||
        "";


    const status =
        match.status ||
        "";


    // =================================================
    // DETERMINE STATUS
    // =================================================

    let statusText =
        "Upcoming";

    let statusClass =
        "status-upcoming";


    const statusLower =
        String(status)
            .toLowerCase()
            .trim();


    if (
        statusLower === "completed" ||
        winner ||
        result
    ) {

        statusText =
            "Completed";

        statusClass =
            "status-completed";

    }
    else if (
        statusLower === "live" ||
        statusLower === "ongoing"
    ) {

        statusText =
            "LIVE";

        statusClass =
            "status-live";

    }


    // =================================================
    // WINNER CHECK
    // =================================================

    const team1Winner =
        winner &&
        String(winner)
            .trim()
            .toLowerCase() ===
        String(team1)
            .trim()
            .toLowerCase();


    const team2Winner =
        winner &&
        String(winner)
            .trim()
            .toLowerCase() ===
        String(team2)
            .trim()
            .toLowerCase();


    // =================================================
    // CARD
    // =================================================

    card.innerHTML = `

        <div class="match-header">

            <div class="match-number">

                ${
                    matchNumber !== ""
                    ?
                    `Match ${escapeHtml(matchNumber)}`
                    :
                    "Match"
                }

            </div>


            <div class="status ${statusClass}">

                ${statusText}

            </div>

        </div>


        <div class="teams">


            <!-- TEAM 1 -->

            <div class="
                team
                ${team1Winner ? "winner" : ""}
            ">

                <div class="team-name">

                    ${escapeHtml(team1)}

                </div>


                <div class="score">

                    ${escapeHtml(score1)}

                </div>


                ${
                    team1Winner
                    ?
                    `
                    <div style="
                        margin-top:5px;
                        font-size:12px;
                        font-weight:bold;
                    ">
                        🏆 WINNER
                    </div>
                    `
                    :
                    ""
                }

            </div>


            <!-- VS -->

            <div class="vs">

                VS

            </div>


            <!-- TEAM 2 -->

            <div class="
                team
                ${team2Winner ? "winner" : ""}
            ">

                <div class="team-name">

                    ${escapeHtml(team2)}

                </div>


                <div class="score">

                    ${escapeHtml(score2)}

                </div>


                ${
                    team2Winner
                    ?
                    `
                    <div style="
                        margin-top:5px;
                        font-size:12px;
                        font-weight:bold;
                    ">
                        🏆 WINNER
                    </div>
                    `
                    :
                    ""
                }

            </div>


        </div>


        ${
            result
            ?
            `
            <div class="result">

                🏆 ${escapeHtml(result)}

            </div>
            `
            :
            ""
        }


        <div class="match-info">


            ${
                date
                ?
                `
                <span>
                    📅 ${escapeHtml(date)}
                </span>
                `
                :
                ""
            }


            ${
                time
                ?
                `
                <span>
                    ⏰ ${escapeHtml(time)}
                </span>
                `
                :
                ""
            }


            ${
                venue
                ?
                `
                <span>
                    📍 ${escapeHtml(venue)}
                </span>
                `
                :
                ""
            }


        </div>


        <div class="actions">

            <a
                class="view-btn"
                href="live-score.html?tournamentId=${encodeURIComponent(tournamentId)}&matchId=${encodeURIComponent(matchId)}"
            >
                📊 View Score
            </a>

        </div>

    `;


    return card;

}


// =====================================================
// SHOW ERROR
// =====================================================

function showError(message) {

    console.error(
        "❌",
        message
    );


    if (matchCount) {

        matchCount.textContent =
            "Unable to load matches";

    }


    if (!matchesContainer) {
        return;
    }


    matchesContainer.innerHTML = `

        <div class="error">

            <div style="
                font-size:45px;
                margin-bottom:10px;
            ">
                ❌
            </div>

            <h3>
                Failed to Load Matches
            </h3>

            <p>
                ${escapeHtml(message)}
            </p>

        </div>

    `;

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE MATCHES.JS READY"
);