// =====================================================
// CRICKMATE - ADMIN TOURNAMENTS.JS
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log(
    "🏆 CRICKMATE ADMIN-TOURNAMENTS.JS STARTED"
);


// =====================================================
// ELEMENTS
// =====================================================

const tournamentList =
    document.getElementById(
        "tournamentList"
    );

const tournamentCount =
    document.getElementById(
        "tournamentCount"
    );


// =====================================================
// LOAD TOURNAMENTS
// =====================================================

async function loadTournaments() {

    console.log(
        "🏆 Loading ALL tournaments..."
    );


    if (!tournamentList) {
        return;
    }


    try {

        const tournamentsRef =
            collection(
                db,
                "tournaments"
            );


        const snapshot =
            await getDocs(
                tournamentsRef
            );


        console.log(
            "🏆 TOURNAMENT COUNT:",
            snapshot.size
        );


        if (tournamentCount) {

            tournamentCount.textContent =
                snapshot.size;

        }


        if (snapshot.empty) {

            tournamentList.innerHTML = `

                <div class="empty">

                    <div style="font-size:40px;">
                        🏆
                    </div>

                    <h3>
                        No Tournaments Found
                    </h3>

                    <p>
                        Create a tournament first.
                    </p>

                </div>

            `;

            return;

        }


        tournamentList.innerHTML = "";


        snapshot.forEach(
            (tournamentDoc) => {

                const tournament =
                    tournamentDoc.data();


                const tournamentId =
                    tournamentDoc.id;


                renderTournament(
                    tournamentId,
                    tournament
                );

            }
        );


        console.log(
            "✅ TOURNAMENTS DISPLAYED"
        );

    }
    catch (error) {

        console.error(
            "❌ Tournament loading error:",
            error
        );


        tournamentList.innerHTML = `

            <div class="error">

                ❌ Unable to load tournaments.

                <br><br>

                ${escapeHtml(
                    error.message ||
                    "Unknown error"
                )}

            </div>

        `;

    }

}


// =====================================================
// RENDER TOURNAMENT
// =====================================================

function renderTournament(
    tournamentId,
    tournament
) {

    const name =
        tournament.tournamentName ||
        tournament.name ||
        tournament.title ||
        "Unnamed Tournament";


    const venue =
        tournament.venue ||
        "Not specified";


    const status =
        tournament.status ||
        "Active";


    const winnerPrize =
        tournament.winnerPrize ??
        tournament.prizeMoney ??
        tournament.winnerPrizeMoney ??
        0;


    const runnerPrize =
        tournament.runnerPrize ??
        tournament.runnerUpPrize ??
        0;


    const entryFee =
        tournament.entryFee ??
        0;


    const teamsCount =
        tournament.teamsCount ??
        tournament.teamCount ??
        0;


    const card =
        document.createElement(
            "div"
        );


    card.className =
        "tournament-card";


    card.innerHTML = `

        <div class="tournament-top">

            <div>

                <div class="tournament-name">
                    ${escapeHtml(name)}
                </div>

                <div class="tournament-id">
                    ID: ${escapeHtml(tournamentId)}
                </div>

            </div>


            <div class="status">
                ${escapeHtml(status)}
            </div>

        </div>


        <div class="details">


            <div class="detail">

                <span class="detail-label">
                    📍 Venue
                </span>

                <span class="detail-value">
                    ${escapeHtml(venue)}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    💰 Entry Fee
                </span>

                <span class="detail-value">
                    ₹${formatNumber(entryFee)}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    🥇 Winner Prize
                </span>

                <span class="detail-value">
                    ₹${formatNumber(winnerPrize)}
                </span>

            </div>


            <div class="detail">

                <span class="detail-label">
                    🥈 Runner-up Prize
                </span>

                <span class="detail-value">
                    ₹${formatNumber(runnerPrize)}
                </span>

            </div>


        </div>


        <div class="actions">


            <a
                class="btn btn-main"
                href="tournament.html?id=${encodeURIComponent(tournamentId)}"
            >
                🏆 Open Tournament
            </a>


            <a
                class="btn btn-team"
                href="teams.html?tournamentId=${encodeURIComponent(tournamentId)}"
            >
                👥 Teams
            </a>


            <a
                class="btn btn-match"
                href="matches.html?tournamentId=${encodeURIComponent(tournamentId)}"
            >
                🏏 Matches
            </a>


            <a
                class="btn btn-point"
                href="points.html?tournamentId=${encodeURIComponent(tournamentId)}"
            >
                📊 Points
            </a>


        </div>

    `;


    tournamentList.appendChild(
        card
    );

}


// =====================================================
// FORMAT NUMBER
// =====================================================

function formatNumber(value) {

    const number =
        Number(value);


    if (
        Number.isNaN(number)
    ) {

        return "0";

    }


    return number.toLocaleString(
        "en-IN"
    );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// START
// =====================================================

loadTournaments();


console.log(
    "✅ CRICKMATE ADMIN-TOURNAMENTS.JS READY"
);