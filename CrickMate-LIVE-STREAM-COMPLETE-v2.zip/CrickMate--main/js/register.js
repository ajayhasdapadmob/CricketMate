// =====================================================
// CRICKMATE - REGISTER.JS
// =====================================================

import {
    auth,
    db
} from "./firebase.js";

import {
    createUserWithEmailAndPassword,
    updateProfile
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    doc,
    setDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🔥 CRICKMATE REGISTER.JS STARTED");


// =====================================================
// ELEMENTS
// =====================================================

const form =
    document.getElementById("registerForm");

const submitBtn =
    document.getElementById("submitBtn");

const messageBox =
    document.getElementById("message");


const nameInput =
    document.getElementById("fullName");

const emailInput =
    document.getElementById("email");

const passwordInput =
    document.getElementById("password");

const confirmPasswordInput =
    document.getElementById("confirmPassword");


// =====================================================
// CHECK ELEMENTS
// =====================================================

console.log("🧩 Register form:", form);
console.log("🧩 Submit button:", submitBtn);


// =====================================================
// IF FORM ID IS DIFFERENT
// =====================================================

if (!form) {

    console.error(
        "❌ registerForm not found."
    );

    showMessage(
        "Registration form could not be found.",
        "error"
    );

}


// =====================================================
// REGISTER
// =====================================================

if (form) {

    form.addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();


            console.log(
                "🚀 Registration submitted"
            );


            // -----------------------------------------
            // GET VALUES
            // -----------------------------------------

            const fullName =
                nameInput
                    ? nameInput.value.trim()
                    : "";

            const email =
                emailInput
                    ? emailInput.value.trim()
                    : "";

            const password =
                passwordInput
                    ? passwordInput.value
                    : "";

            const confirmPassword =
                confirmPasswordInput
                    ? confirmPasswordInput.value
                    : "";


            // -----------------------------------------
            // VALIDATION
            // -----------------------------------------

            if (!fullName) {

                showMessage(
                    "Please enter your full name.",
                    "error"
                );

                return;

            }


            if (!email) {

                showMessage(
                    "Please enter your email address.",
                    "error"
                );

                return;

            }


            if (!password) {

                showMessage(
                    "Please enter a password.",
                    "error"
                );

                return;

            }


            if (password.length < 6) {

                showMessage(
                    "Password must be at least 6 characters.",
                    "error"
                );

                return;

            }


            if (
                password !==
                confirmPassword
            ) {

                showMessage(
                    "Passwords do not match.",
                    "error"
                );

                return;

            }


            // -----------------------------------------
            // BUTTON
            // -----------------------------------------

            if (submitBtn) {

                submitBtn.disabled =
                    true;

                submitBtn.textContent =
                    "Creating Account...";

            }


            showMessage(
                "Creating your CrickMate account...",
                "info"
            );


            try {

                // =====================================
                // FIREBASE AUTH
                // =====================================

                console.log(
                    "🔥 Creating Firebase account..."
                );


                const credential =
                    await createUserWithEmailAndPassword(
                        auth,
                        email,
                        password
                    );


                const user =
                    credential.user;


                console.log(
                    "✅ Firebase Auth account created:",
                    user.uid
                );


                // =====================================
                // UPDATE DISPLAY NAME
                // =====================================

                await updateProfile(
                    user,
                    {
                        displayName:
                            fullName
                    }
                );


                console.log(
                    "✅ Display name updated"
                );


                // =====================================
                // FIRESTORE USER PROFILE
                // =====================================

                await setDoc(
                    doc(
                        db,
                        "users",
                        user.uid
                    ),
                    {

                        uid:
                            user.uid,

                        name:
                            fullName,

                        email:
                            user.email,

                        role:
                            "user",

                        createdAt:
                            serverTimestamp(),

                        updatedAt:
                            serverTimestamp()

                    }
                );


                console.log(
                    "✅ User profile saved to Firestore"
                );


                // =====================================
                // SUCCESS
                // =====================================

                showMessage(
                    "Account created successfully! Redirecting...",
                    "success"
                );


                // =====================================
                // DASHBOARD
                // =====================================

                setTimeout(
                    () => {

                        window.location.href =
                            "./dashboard.html";

                    },
                    1000
                );


            } catch (error) {

                console.error(
                    "❌ REGISTRATION ERROR:",
                    error
                );

                console.error(
                    "❌ ERROR CODE:",
                    error.code
                );

                console.error(
                    "❌ ERROR MESSAGE:",
                    error.message
                );


                let text =
                    "Registration failed. Please try again.";


                // =====================================
                // AUTH ERRORS
                // =====================================

                if (
                    error.code ===
                    "auth/email-already-in-use"
                ) {

                    text =
                        "This email is already registered. Please login.";

                }

                else if (
                    error.code ===
                    "auth/invalid-email"
                ) {

                    text =
                        "Please enter a valid email address.";

                }

                else if (
                    error.code ===
                    "auth/weak-password"
                ) {

                    text =
                        "Password is too weak. Use at least 6 characters.";

                }

                else if (
                    error.code ===
                    "auth/operation-not-allowed"
                ) {

                    text =
                        "Email/Password login is not enabled in Firebase Authentication.";

                }

                else if (
                    error.code ===
                    "auth/network-request-failed"
                ) {

                    text =
                        "Network error. Please check your internet connection.";

                }

                else if (
                    error.code ===
                    "auth/api-key-not-valid"
                ) {

                    text =
                        "Firebase API key is invalid. Please check firebase.js.";

                }

                else if (
                    error.code ===
                    "auth/invalid-api-key"
                ) {

                    text =
                        "Firebase API key is invalid. Please check firebase.js.";

                }

                else if (
                    error.code ===
                    "permission-denied"
                ) {

                    text =
                        "Account authentication succeeded, but Firestore permission was denied.";

                }

                else if (
                    error.code ===
                    "failed-precondition"
                ) {

                    text =
                        "Firestore is not configured correctly.";

                }

                else if (
                    error.message
                ) {

                    text =
                        error.message;

                }


                showMessage(
                    text,
                    "error"
                );


                if (submitBtn) {

                    submitBtn.disabled =
                        false;

                    submitBtn.textContent =
                        "Create Account";

                }

            }

        }
    );

}


// =====================================================
// SHOW MESSAGE
// =====================================================

function showMessage(
    text,
    type = "error"
) {

    if (!messageBox) {

        console.log(
            `[${type}]`,
            text
        );

        return;

    }


    messageBox.textContent =
        text;


    messageBox.className =
        `message ${type}`;

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE REGISTER READY"
);