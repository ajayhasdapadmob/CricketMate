// =====================================================
// CRICKMATE - COMMENTRY.JS
// LIVE MATCH COMMENTARY
// =====================================================

import { db } from "./firebase.js";

import {
    doc,
    getDoc,
    collection,
    getDocs,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE COMMENTRY.JS STARTED");


// =====================================================
// URL PARAMETERS
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");

let matchId =
    params.get("matchId") ||
    params.get("match") ||
    localStorage.getItem("currentMatchId");

console.log("🏆 URL Tournament ID:", tournamentId);
console.log("🏏 URL Match ID:", matchId);

if (tournamentId) {

    tournamentId =
        String(tournamentId).trim();

}


if (matchId) {

    matchId =
        String(matchId).trim();

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);

console.log(
    "🏏 Match ID:",
    matchId
);


// =====================================================
// ELEMENTS
// =====================================================

const matchLoading =
    document.getElementById(
        "matchLoading"
    );


const matchBox =
    document.getElementById(
        "matchBox"
    );


const commentaryBox =
    document.getElementById(
        "commentary"
    );


const ballCount =
    document.getElementById(
        "ballCount"
    );


const backBtn =
    document.getElementById(
        "backBtn"
    );


// =====================================================
// SAVE IDs
// =====================================================

if (tournamentId) {

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


if (matchId) {

    localStorage.setItem(
        "currentMatchId",
        matchId
    );

}


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            `admin-matches.html?tournamentId=${encodeURIComponent(
                tournamentId
            )}`;

    }
    else {

        backBtn.href =
            "admin-matches.html";

    }

}


// =====================================================
// ERROR
// =====================================================

function showError(text) {

    console.error(
        "❌",
        text
    );


    if (matchLoading) {

        matchLoading.style.display =
            "block";

        matchLoading.innerHTML = `
            <div class="error">
                ❌ ${escapeHtml(text)}
            </div>
        `;

    }


    if (commentaryBox) {

        commentaryBox.innerHTML = `
            <div class="error">
                ❌ ${escapeHtml(text)}
            </div>
        `;

    }

}


// =====================================================
// VALIDATE IDs
// =====================================================

if (!tournamentId) {

    showError(
        "Tournament ID missing."
    );

}
else if (!matchId) {

    showError(
        "Match ID missing."
    );

}
else {

    loadMatch();

}


// =====================================================
// MATCH PATH
// =====================================================

function getMatchRef() {

    return doc(
        db,
        "tournaments",
        tournamentId,
        "matches",
        matchId
    );

}


// =====================================================
// LOAD MATCH
// =====================================================

async function loadMatch() {

    console.log(
        "🔥 Loading match..."
    );


    console.log(
        "📂 MATCH PATH:",
        `tournaments/${tournamentId}/matches/${matchId}`
    );


    try {

        const matchRef =
            getMatchRef();


        const matchSnap =
            await getDoc(
                matchRef
            );


        console.log(
            "📦 Match exists:",
            matchSnap.exists()
        );


        if (!matchSnap.exists()) {

            showError(
                "Match not found in Firebase."
            );

            return;

        }


        const match =
            matchSnap.data();


        console.log(
            "✅ MATCH FOUND:",
            match
        );


        displayMatch(
            match
        );


        await loadCommentary(
            match
        );


        // =================================================
        // REAL-TIME MATCH UPDATE
        // =================================================

        onSnapshot(
            matchRef,
            async (snapshot) => {

                if (!snapshot.exists()) {
                    return;
                }


                const updatedMatch =
                    snapshot.data();


                console.log(
                    "🔄 MATCH UPDATED"
                );


                displayMatch(
                    updatedMatch
                );


                await loadCommentary(
                    updatedMatch
                );

            },
            (error) => {

                console.error(
                    "❌ LIVE MATCH ERROR:",
                    error
                );

            }
        );

    }
    catch (error) {

        console.error(
            "❌ MATCH LOAD ERROR:",
            error
        );


        showError(
            error.message ||
            "Unable to load match."
        );

    }

}


// =====================================================
// DISPLAY MATCH
// =====================================================

function displayMatch(match) {

    const team1 =
        match.team1Name ||
        match.teamA ||
        match.team1 ||
        "Team 1";


    const team2 =
        match.team2Name ||
        match.teamB ||
        match.team2 ||
        "Team 2";


    const score1 =
        match.scoreA ||
        "0/0";


    const score2 =
        match.scoreB ||
        "0/0";


    const status =
        match.status ||
        "Scheduled";


    const matchNumber =
        match.matchNumber ||
        "—";


    const date =
        match.matchDate ||
        match.date ||
        "";


    const team1Name =
        document.getElementById(
            "team1Name"
        );


    const team2Name =
        document.getElementById(
            "team2Name"
        );


    const team1Score =
        document.getElementById(
            "team1Score"
        );


    const team2Score =
        document.getElementById(
            "team2Score"
        );


    const matchTeams =
        document.getElementById(
            "matchTeams"
        );


    const matchNumberEl =
        document.getElementById(
            "matchNumber"
        );


    const matchDate =
        document.getElementById(
            "matchDate"
        );


    const matchStatus =
        document.getElementById(
            "matchStatus"
        );


    if (team1Name) {

        team1Name.textContent =
            team1;

    }


    if (team2Name) {

        team2Name.textContent =
            team2;

    }


    if (team1Score) {

        team1Score.textContent =
            formatScore(score1);

    }


    if (team2Score) {

        team2Score.textContent =
            formatScore(score2);

    }


    if (matchTeams) {

        matchTeams.textContent =
            `${team1} vs ${team2}`;

    }


    if (matchNumberEl) {

        matchNumberEl.textContent =
            `Match ${matchNumber}`;

    }


    if (matchDate) {

        matchDate.textContent =
            formatDate(date);

    }


    if (matchStatus) {

        matchStatus.textContent =
            status;

    }


    if (matchLoading) {

        matchLoading.style.display =
            "none";

    }


    if (matchBox) {

        matchBox.style.display =
            "block";

    }

}


// =====================================================
// LOAD COMMENTARY
// =====================================================

async function loadCommentary(match) {

    console.log(
        "📝 Loading commentary..."
    );


    let balls = [];


    // =================================================
    // METHOD 1
    // MATCH.balls
    // =================================================

    if (
        Array.isArray(
            match.balls
        )
    ) {

        console.log(
            "🏏 Match balls:",
            match.balls.length
        );


        balls =
            match.balls.map(
                (ball, index) =>
                    normalizeBall(
                        ball,
                        index
                    )
            );

    }


    // =================================================
    // METHOD 2
    // BALLS SUBCOLLECTION
    // =================================================

    if (
        balls.length === 0
    ) {

        try {

            const ballsRef =
                collection(
                    db,
                    "tournaments",
                    tournamentId,
                    "matches",
                    matchId,
                    "balls"
                );


            const ballsSnap =
                await getDocs(
                    ballsRef
                );


            console.log(
                "🏏 BALL DOCUMENTS:",
                ballsSnap.size
            );


            ballsSnap.forEach(
                ballDoc => {

                    balls.push(
                        normalizeBall(
                            ballDoc.data(),
                            balls.length
                        )
                    );

                }
            );

        }
        catch (error) {

            console.warn(
                "⚠️ Balls collection:",
                error.message
            );

        }

    }


    // =================================================
    // METHOD 3
    // COMMENTARY ARRAY
    // =================================================

    if (
        balls.length === 0 &&
        Array.isArray(
            match.commentary
        )
    ) {

        console.log(
            "📝 Commentary array:",
            match.commentary.length
        );


        balls =
            match.commentary.map(
                (item, index) =>
                    normalizeBall(
                        item,
                        index
                    )
            );

    }


    renderCommentary(
        balls
    );

}


// =====================================================
// NORMALIZE BALL
// =====================================================

function normalizeBall(
    ball,
    index
) {

    if (
        ball === null ||
        ball === undefined
    ) {

        return {

            number:
                index + 1,

            text:
                "Ball played",

            runs:
                ""

        };

    }


    if (
        typeof ball === "string"
    ) {

        return {

            number:
                index + 1,

            text:
                ball,

            runs:
                ""

        };

    }


    const over =
        ball.over ??
        ball.overNumber ??
        ball.overNo ??
        "";


    const ballNumber =
        ball.ball ??
        ball.ballNumber ??
        ball.delivery ??
        "";


    let number;


    if (
        over !== "" &&
        ballNumber !== ""
    ) {

        number =
            `${over}.${ballNumber}`;

    }
    else {

        number =
            ball.number ??
            index + 1;

    }


    const batsman =
        ball.batsman ||
        ball.batter ||
        "";


    const bowler =
        ball.bowler ||
        "";


    const runs =
        ball.runs ??
        ball.totalRuns ??
        "";


    const wicket =
        ball.wicket ||
        ball.isWicket ||
        false;


    let text =
        ball.commentary ||
        ball.comment ||
        ball.description ||
        ball.text ||
        ball.message ||
        "";


    if (!text) {

        if (wicket) {

            text =
                `${batsman || "Batter"} OUT`;

        }
        else if (runs !== "") {

            text =
                `${batsman || "Batter"} scored ${runs} run(s)`;

        }
        else if (bowler) {

            text =
                `${bowler} delivered the ball`;

        }
        else {

            text =
                "Ball played";

        }

    }


    return {

        number:
            number,

        text:
            text,

        runs:
            runs

    };

}


// =====================================================
// RENDER COMMENTARY
// =====================================================

function renderCommentary(
    balls
) {

    if (!commentaryBox) {
        return;
    }


    if (
        !balls ||
        balls.length === 0
    ) {

        commentaryBox.innerHTML = `

            <div class="empty">

                📝 No commentary available yet.

                <br><br>

                <small>
                    Commentary will appear here when
                    balls are recorded.
                </small>

            </div>

        `;


        if (ballCount) {

            ballCount.textContent =
                "0 balls";

        }


        return;

    }


    // =================================================
    // NEWEST FIRST
    // =================================================

    const displayBalls =
        [...balls].reverse();


    commentaryBox.innerHTML =
        displayBalls
            .map(
                ball => {

                    const runs =
                        ball.runs !== "" &&
                        ball.runs !== null &&
                        ball.runs !== undefined
                        ?

                        `
                        <span class="runs">
                            ${escapeHtml(
                                ball.runs
                            )} runs
                        </span>
                        `

                        :

                        "";


                    return `

                        <div class="ball">

                            <div class="ball-number">

                                Ball
                                ${escapeHtml(
                                    ball.number
                                )}

                            </div>

                            <div class="ball-text">

                                ${escapeHtml(
                                    ball.text
                                )}

                                ${runs}

                            </div>

                        </div>

                    `;

                }
            )
            .join("");


    if (ballCount) {

        ballCount.textContent =
            `${balls.length} balls`;

    }


    console.log(
        "✅ COMMENTARY DISPLAYED:",
        balls.length
    );

}


// =====================================================
// SCORE FORMAT
// =====================================================

function formatScore(
    value
) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "0/0";

    }


    if (
        typeof value === "object"
    ) {

        const runs =
            value.runs ?? 0;


        const wickets =
            value.wickets ?? 0;


        return `${runs}/${wickets}`;

    }


    return String(
        value
    );

}


// =====================================================
// DATE FORMAT
// =====================================================

function formatDate(
    value
) {

    if (!value) {
        return "—";
    }


    try {

        if (
            value &&
            typeof value.toDate ===
            "function"
        ) {

            return value
                .toDate()
                .toLocaleString();

        }


        const date =
            new Date(value);


        if (
            !isNaN(
                date.getTime()
            )
        ) {

            return date.toLocaleString();

        }

    }
    catch (error) {

        console.warn(
            "⚠️ Date error:",
            error
        );

    }


    return String(value);

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE COMMENTRY.JS READY"
);