// =====================================================
// CRICKMATE - CREATE TEAM.JS
// FINAL CLEAN VERSION
// TEAM + CAPTAIN + CONTACT + 15 PLAYERS
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    addDoc,
    serverTimestamp,
    getDoc,
    doc
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("👥 CRICKMATE CREATE-TEAM.JS STARTED");


// =====================================================
// URL
// =====================================================

const params = new URLSearchParams(
    window.location.search
);


// =====================================================
// TOURNAMENT ID
// =====================================================

let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId = tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// ELEMENTS
// =====================================================

const form =
    document.getElementById("teamForm");

const teamNameInput =
    document.getElementById("teamName");

const shortNameInput =
    document.getElementById("shortName");

const cityInput =
    document.getElementById("city");

const logoInput =
    document.getElementById("logo");

const descriptionInput =
    document.getElementById("description");

const captainNameInput =
    document.getElementById("captainName");

const mobileInput =
    document.getElementById("mobile");

const emailInput =
    document.getElementById("email");

const saveBtn =
    document.getElementById("saveBtn");

const message =
    document.getElementById("message");

const tournamentIdText =
    document.getElementById("tournamentIdText");

const backBtn =
    document.getElementById("backBtn");


// =====================================================
// PLAYER INPUTS
// =====================================================

const playerInputs = [];

for (let i = 1; i <= 15; i++) {

    playerInputs.push(
        document.getElementById(`player${i}`)
    );

}


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "success"
) {

    if (!message) {
        return;
    }

    message.textContent = text;

    message.className =
        `message show ${type}`;

}


// =====================================================
// TOURNAMENT ID DISPLAY
// =====================================================

if (tournamentIdText) {

    tournamentIdText.textContent =
        tournamentId || "Missing";

}


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            `tournament.html?id=${encodeURIComponent(
                tournamentId
            )}`;

    }
    else {

        backBtn.href =
            "my-tournaments.html";

    }

}


// =====================================================
// NO TOURNAMENT ID
// =====================================================

if (!tournamentId) {

    showMessage(
        "❌ Tournament ID missing. Please open Create Team from Tournament Centre.",
        "error"
    );

    if (saveBtn) {
        saveBtn.disabled = true;
    }

}
else {

    verifyTournament();

}


// =====================================================
// VERIFY TOURNAMENT
// =====================================================

async function verifyTournament() {

    try {

        console.log(
            "🔥 Verifying tournament..."
        );


        const tournamentRef =
            doc(
                db,
                "tournaments",
                tournamentId
            );


        const tournamentSnap =
            await getDoc(
                tournamentRef
            );


        if (!tournamentSnap.exists()) {

            showMessage(
                "❌ Tournament not found.",
                "error"
            );

            if (saveBtn) {
                saveBtn.disabled = true;
            }

            return;

        }


        console.log(
            "✅ Tournament verified"
        );


        if (saveBtn) {
            saveBtn.disabled = false;
        }


        showMessage(
            "✅ Tournament ready. You can create your team.",
            "success"
        );

    }
    catch (error) {

        console.error(
            "❌ TOURNAMENT VERIFY ERROR:",
            error
        );


        showMessage(
            error.message ||
            "Unable to verify tournament.",
            "error"
        );

        if (saveBtn) {
            saveBtn.disabled = true;
        }

    }

}


// =====================================================
// FORM SUBMIT
// =====================================================

if (form) {

    form.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            console.log(
                "👥 CREATE TEAM CLICKED"
            );


            if (!tournamentId) {

                showMessage(
                    "❌ Tournament ID missing.",
                    "error"
                );

                return;

            }


            // =================================================
            // TEAM INFORMATION
            // =================================================

            const teamName =
                teamNameInput?.value.trim() || "";

            const shortName =
                shortNameInput?.value
                    .trim()
                    .toUpperCase() || "";

            const city =
                cityInput?.value.trim() || "";

            const logo =
                logoInput?.value.trim() || "";

            const description =
                descriptionInput?.value.trim() || "";


            // =================================================
            // CAPTAIN / CONTACT
            // =================================================

            const captainName =
                captainNameInput?.value.trim() || "";

            const mobile =
                mobileInput?.value.trim() || "";

            const email =
                emailInput?.value.trim() || "";


            // =================================================
            // VALIDATION
            // =================================================

            if (!teamName) {

                showMessage(
                    "Please enter team name.",
                    "error"
                );

                return;

            }


            if (!shortName) {

                showMessage(
                    "Please enter short name.",
                    "error"
                );

                return;

            }


            if (shortName.length > 8) {

                showMessage(
                    "Short name must be maximum 8 characters.",
                    "error"
                );

                return;

            }


            if (!captainName) {

                showMessage(
                    "Please enter captain name.",
                    "error"
                );

                return;

            }


            if (!/^[0-9]{10}$/.test(mobile)) {

                showMessage(
                    "Please enter a valid 10-digit mobile number.",
                    "error"
                );

                return;

            }


            if (
                !email ||
                !email.includes("@") ||
                !email.includes(".")
            ) {

                showMessage(
                    "Please enter a valid email ID.",
                    "error"
                );

                return;

            }


            // =================================================
            // COLLECT PLAYERS
            // =================================================

            const players = [];


            for (
                let i = 0;
                i < playerInputs.length;
                i++
            ) {

                const input =
                    playerInputs[i];


                if (!input) {
                    continue;
                }


                const playerName =
                    input.value.trim();


                // PLAYER 1 REQUIRED

                if (
                    i === 0 &&
                    !playerName
                ) {

                    showMessage(
                        "Please enter Player 1 / Captain name.",
                        "error"
                    );

                    return;

                }


                if (playerName) {

                    players.push({

                        playerNumber:
                            i + 1,

                        playerName:
                            playerName,

                        name:
                            playerName,

                        role:
                            i === 0
                                ? "Captain"
                                : "Player"

                    });

                }

            }


            if (!players.length) {

                showMessage(
                    "Please add at least one player.",
                    "error"
                );

                return;

            }


            console.log(
                "🏏 PLAYERS:",
                players
            );


            // =================================================
            // DISABLE BUTTON
            // =================================================

            if (saveBtn) {

                saveBtn.disabled = true;

                saveBtn.textContent =
                    "Creating Team...";

            }


            showMessage(
                "Creating team...",
                "success"
            );


            try {

                // =================================================
                // TEAM DATA
                // =================================================

                const teamData = {

                    tournamentId,

                    teamName,

                    name:
                        teamName,

                    shortName,

                    city,

                    area:
                        city,

                    logo,

                    logoUrl:
                        logo,

                    description,

                    captainName,

                    captain:
                        captainName,

                    mobile,

                    phone:
                        mobile,

                    email,


                    // =================================================
                    // PLAYER 1 - 15
                    // =================================================

                    player1:
                        players[0]?.playerName || "",

                    player2:
                        players[1]?.playerName || "",

                    player3:
                        players[2]?.playerName || "",

                    player4:
                        players[3]?.playerName || "",

                    player5:
                        players[4]?.playerName || "",

                    player6:
                        players[5]?.playerName || "",

                    player7:
                        players[6]?.playerName || "",

                    player8:
                        players[7]?.playerName || "",

                    player9:
                        players[8]?.playerName || "",

                    player10:
                        players[9]?.playerName || "",

                    player11:
                        players[10]?.playerName || "",

                    player12:
                        players[11]?.playerName || "",

                    player13:
                        players[12]?.playerName || "",

                    player14:
                        players[13]?.playerName || "",

                    player15:
                        players[14]?.playerName || "",


                    // =================================================
                    // PLAYERS ARRAY
                    // =================================================

                    players,


                    // =================================================
                    // TEAM STATS
                    // =================================================

                    matches: 0,

                    wins: 0,

                    losses: 0,

                    draws: 0,

                    noResult: 0,

                    points: 0,

                    runsFor: 0,

                    runsAgainst: 0,

                    ballsFor: 0,

                    ballsAgainst: 0,

                    nrr: 0,


                    createdAt:
                        serverTimestamp(),

                    updatedAt:
                        serverTimestamp()

                };


                // =================================================
                // CREATE TEAM DOCUMENT
                // =================================================

                console.log(
                    "💾 Creating team..."
                );


                const teamsCollection =
                    collection(
                        db,
                        "tournaments",
                        tournamentId,
                        "teams"
                    );


                const teamDoc =
                    await addDoc(
                        teamsCollection,
                        teamData
                    );


                const teamId =
                    teamDoc.id;


                console.log(
                    "✅ TEAM CREATED:",
                    teamId
                );


                // =================================================
                // CREATE PLAYERS SUBCOLLECTION
                // IMPORTANT:
                // playersCollection ONLY declared once
                // =================================================

                const playersCollection =
                    collection(
                        db,
                        "tournaments",
                        tournamentId,
                        "teams",
                        teamId,
                        "players"
                    );


                console.log(
                    "🔥 Saving players..."
                );


                for (
                    let i = 0;
                    i < players.length;
                    i++
                ) {

                    const player =
                        players[i];


                    const playerData = {

                        tournamentId,

                        teamId,

                        teamName,

                        playerNumber:
                            player.playerNumber,

                        playerName:
                            player.playerName,

                        name:
                            player.playerName,

                        role:
                            player.role,

                        captain:
                            player.playerNumber === 1,

                        runs: 0,

                        wickets: 0,

                        matches: 0,

                        balls: 0,

                        fours: 0,

                        sixes: 0,

                        createdAt:
                            serverTimestamp(),

                        updatedAt:
                            serverTimestamp()

                    };


                    const playerDoc =
                        await addDoc(
                            playersCollection,
                            playerData
                        );


                    console.log(
                        `✅ PLAYER ${player.playerNumber} CREATED:`,
                        playerDoc.id
                    );

                }


                // =================================================
                // LOCAL STORAGE
                // =================================================

                localStorage.setItem(
                    "currentTeamId",
                    teamId
                );

                localStorage.setItem(
                    "currentTeamName",
                    teamName
                );


                // =================================================
                // SUCCESS
                // =================================================

                showMessage(
                    `✅ Team created successfully! ${players.length} players added.`,
                    "success"
                );


                console.log(
                    "🎉 TEAM CREATION COMPLETE"
                );


                // =================================================
                // REDIRECT
                // =================================================

                setTimeout(
                    function() {

                        window.location.href =
                            `teams.html?tournamentId=${encodeURIComponent(
                                tournamentId
                            )}`;

                    },
                    1200
                );

            }
            catch (error) {

                console.error(
                    "❌ TEAM CREATE ERROR:",
                    error
                );


                showMessage(
                    error.message ||
                    "Failed to create team.",
                    "error"
                );


                if (saveBtn) {

                    saveBtn.disabled = false;

                    saveBtn.textContent =
                        "➕ Create Team";

                }

            }

        }
    );

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE CREATE-TEAM.JS READY"
);