// =====================================================
// CRICKMATE - PLAYER-STATS.JS
// PLAYER STATISTICS
// =====================================================

import { db } from "./firebase.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";


console.log("🏏 CRICKMATE PLAYER-STATS.JS STARTED");


// =====================================================
// URL
// =====================================================

const params =
    new URLSearchParams(
        window.location.search
    );


let tournamentId =
    params.get("tournamentId") ||
    params.get("id") ||
    localStorage.getItem("tournamentId") ||
    localStorage.getItem("currentTournamentId");


if (tournamentId) {

    tournamentId =
        tournamentId.trim();

    localStorage.setItem(
        "tournamentId",
        tournamentId
    );

    localStorage.setItem(
        "currentTournamentId",
        tournamentId
    );

}


console.log(
    "🏆 Tournament ID:",
    tournamentId
);


// =====================================================
// ELEMENTS
// =====================================================

const loading =
    document.getElementById(
        "loading"
    );

const statsPage =
    document.getElementById(
        "statsPage"
    );

const statsBody =
    document.getElementById(
        "statsBody"
    );

const message =
    document.getElementById(
        "message"
    );

const backBtn =
    document.getElementById(
        "backBtn"
    );


// =====================================================
// MESSAGE
// =====================================================

function showMessage(
    text,
    type = "error"
) {

    if (!message) {
        return;
    }

    message.textContent =
        text;

    message.className =
        `message show ${type}`;

}


// =====================================================
// BACK BUTTON
// =====================================================

if (backBtn) {

    if (tournamentId) {

        backBtn.href =
            `dashboard.html?tournamentId=${encodeURIComponent(
                tournamentId
            )}`;

    }
    else {

        backBtn.href =
            "index.html";

    }

}


// =====================================================
// VALIDATE
// =====================================================

if (!tournamentId) {

    if (loading) {

        loading.style.display =
            "none";

    }

    showMessage(
        "Tournament ID missing."
    );

}
else {

    loadPlayerStats();

}


// =====================================================
// LOAD PLAYER STATS
// =====================================================

async function loadPlayerStats() {

    console.log(
        "🔥 Loading player statistics..."
    );

    try {

        const matchesRef =
            collection(
                db,
                "tournaments",
                tournamentId,
                "matches"
            );


        const snapshot =
            await getDocs(
                matchesRef
            );


        console.log(
            "🏏 MATCH COUNT:",
            snapshot.size
        );


        const players =
            {};


        // =================================================
        // PROCESS MATCHES
        // =================================================

        snapshot.forEach(
            docSnap => {

                const match =
                    docSnap.data();


                const balls =
                    Array.isArray(
                        match.balls
                    )
                    ?
                    match.balls
                    :
                    [];


                if (!balls.length) {
                    return;
                }


                const teams = {

                    1:
                        match.team1Name ||
                        match.teamA ||
                        "Team 1",

                    2:
                        match.team2Name ||
                        match.teamB ||
                        "Team 2"

                };


                const seenTeams =
                    {};


                balls.forEach(
                    ball => {

                        const innings =
                            Number(
                                ball.innings ||
                                1
                            );


                        const team =
                            teams[innings] ||
                            "Unknown";


                        /*
                         * Current scoring system stores
                         * batting team in commentary.
                         *
                         * Extract player only when
                         * player information exists.
                         */


                        const playerName =
                            ball.playerName ||
                            ball.batterName ||
                            ball.batsmanName;


                        if (!playerName) {

                            return;

                        }


                        const key =
                            `${playerName}___${team}`;


                        if (!players[key]) {

                            players[key] = {

                                player:
                                    playerName,

                                team:
                                    team,

                                matches:
                                    0,

                                runs:
                                    0,

                                wickets:
                                    0,

                                balls:
                                    0

                            };

                        }


                        players[key].runs +=
                            Number(
                                ball.runs ||
                                0
                            );


                        players[key].balls += 1;


                        if (
                            ball.wicket &&
                            ball.bowlerName ===
                            playerName
                        ) {

                            players[key].wickets +=
                                1;

                        }


                        seenTeams[team] =
                            true;

                    }

                );


                /*
                 * Match count is added after
                 * processing the match.
                 */

                Object.keys(
                    seenTeams
                ).forEach(
                    team => {

                        Object.keys(
                            players
                        ).forEach(
                            key => {

                                if (
                                    players[key].team ===
                                    team
                                ) {

                                    players[key].matches +=
                                        1;

                                }

                            }
                        );

                    }
                );

            }
        );


        const list =
            Object.values(
                players
            );


        console.log(
            "📊 PLAYER COUNT:",
            list.length
        );


        // =================================================
        // SORT BY RUNS
        // =================================================

        list.sort(
            (a, b) =>
                b.runs - a.runs
        );


        renderStats(
            list
        );


        if (loading) {

            loading.style.display =
                "none";

        }


        if (statsPage) {

            statsPage.style.display =
                "block";

        }


    }
    catch (error) {

        console.error(
            "❌ PLAYER STATS ERROR:",
            error
        );


        if (loading) {

            loading.textContent =
                "❌ Unable to load player statistics.";

        }


        showMessage(
            error.message ||
            "Unable to load player statistics."
        );

    }

}


// =====================================================
// RENDER
// =====================================================

function renderStats(
    players
) {

    if (!statsBody) {
        return;
    }


    if (!players.length) {

        statsBody.innerHTML = `

            <tr>

                <td
                    colspan="7"
                    class="empty"
                >

                    🏏 No player statistics
                    available yet.

                    <br><br>

                    Player statistics will
                    appear when player-level
                    scoring data is available.

                </td>

            </tr>

        `;

        return;

    }


    statsBody.innerHTML =
        players
            .map(
                player => {

                    const strikeRate =
                        player.balls > 0
                        ?
                        (
                            player.runs /
                            player.balls *
                            100
                        ).toFixed(2)
                        :
                        "0.00";


                    return `

                        <tr>

                            <td>

                                <span
                                    class="player-name"
                                >
                                    ${escapeHtml(
                                        player.player
                                    )}
                                </span>

                            </td>


                            <td>

                                <span
                                    class="badge"
                                >
                                    ${escapeHtml(
                                        player.team
                                    )}
                                </span>

                            </td>


                            <td>
                                ${player.matches}
                            </td>


                            <td>
                                ${player.runs}
                            </td>


                            <td>
                                ${player.wickets}
                            </td>


                            <td>
                                ${player.balls}
                            </td>


                            <td>
                                ${strikeRate}
                            </td>

                        </tr>

                    `;

                }
            )
            .join("");

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHtml(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// READY
// =====================================================

console.log(
    "✅ CRICKMATE PLAYER-STATS.JS READY"
);