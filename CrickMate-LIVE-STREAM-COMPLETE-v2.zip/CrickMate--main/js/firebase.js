// =====================================================
// CRICKMATE - FIREBASE.JS
// Firebase Project: apl-tournament-platform
// =====================================================

import {
    initializeApp
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";

import {
    getAuth
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    getFirestore
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

import {
    getStorage
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-storage.js";


// =====================================================
// FIREBASE CONFIG
// =====================================================

const firebaseConfig = {

    apiKey:
        "AIzaSyCEkiHDayUu5NF9g5EOsQL-Dwyg6XYz57k",

    authDomain:
        "apl-tournament-platform.firebaseapp.com",

    projectId:
        "apl-tournament-platform",

    storageBucket:
        "apl-tournament-platform.firebasestorage.app",

    messagingSenderId:
        "915381266456",

    appId:
        "1:915381266456:web:947236a5a210fa11bfbb6d",

    measurementId:
        "G-J3YWBRWVN0"

};


// =====================================================
// INITIALIZE FIREBASE
// =====================================================

const app = initializeApp(firebaseConfig);


// =====================================================
// FIREBASE SERVICES
// =====================================================

const auth = getAuth(app);

const db = getFirestore(app);

const storage = getStorage(app);


// =====================================================
// EXPORT
// =====================================================

export {
    app,
    auth,
    db,
    storage
};


// =====================================================
// CONSOLE
// =====================================================

console.log("=================================");
console.log("🔥 CRICKMATE FIREBASE INITIALIZED");
console.log("🔥 PROJECT:", firebaseConfig.projectId);
console.log("🔥 AUTH READY");
console.log("🔥 FIRESTORE READY");
console.log("🔥 STORAGE READY");
console.log("=================================");