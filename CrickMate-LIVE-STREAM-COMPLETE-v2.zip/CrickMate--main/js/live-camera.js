// =====================================================
// CRICKMATE - LIVE CAMERA V2
// WebRTC broadcaster with multi-viewer Firestore signaling
// =====================================================
import { auth, db } from "./firebase.js";
import { signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";
import { collection, doc, getDocs, setDoc, deleteDoc, onSnapshot, addDoc, updateDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

console.log("🎥 CRICKMATE LIVE CAMERA V2");

const $ = id => document.getElementById(id);
const loginCard=$("loginCard"), userCard=$("userCard"), controlCard=$("controlCard"), cameraCard=$("cameraCard");
const email=$("email"), password=$("password"), loginBtn=$("loginBtn"), logoutBtn=$("logoutBtn"), loginStatus=$("loginStatus"), loginMessage=$("loginMessage"), userEmail=$("userEmail");
const matchSelect=$("matchSelect"), matchInfo=$("matchInfo"), teamA=$("teamA"), teamB=$("teamB"), status=$("status"), cameraPreview=$("cameraPreview"), cameraOff=$("cameraOff"), startCameraBtn=$("startCameraBtn"), startLiveBtn=$("startLiveBtn"), stopLiveBtn=$("stopLiveBtn"), watchLiveBtn=$("watchLiveBtn");

const params=new URLSearchParams(location.search);
let tournamentId=params.get("tournamentId") || localStorage.getItem("tournamentId") || localStorage.getItem("crickmateTournamentId") || localStorage.getItem("selectedTournamentId") || "AQufq4Iss61ew4HRTnmM";
localStorage.setItem("tournamentId",tournamentId);
localStorage.setItem("crickmateTournamentId",tournamentId);
localStorage.setItem("selectedTournamentId",tournamentId);

const rtcConfig={
  iceServers:[
    {urls:"stun:stun.l.google.com:19302"},
    {urls:"stun:stun1.l.google.com:19302"}
    // Production note: add a TURN server here for reliable mobile-data/NAT traversal.
    // Example shape:
    // {urls:"turn:YOUR_TURN_HOST:3478", username:"YOUR_USER", credential:"YOUR_PASSWORD"}
  ],
  iceCandidatePoolSize:10
};

let currentUser=null, currentMatchId=null, localStream=null, streamRef=null;
let viewerListenerUnsub=null;
const viewerPeers=new Map();

function setStatus(text,type="") { if(!status)return; status.textContent=text; status.className="status"; if(type)status.classList.add(type); }
function setLoginStatus(text,type="") { if(!loginStatus)return; loginStatus.textContent=text; loginStatus.className="status"; if(type)loginStatus.classList.add(type); }
function getTeamA(d){return d.teamAName||d.teamA||d.team1Name||d.team1||d.homeTeam||d.homeTeamName||"Team A";}
function getTeamB(d){return d.teamBName||d.teamB||d.team2Name||d.team2||d.awayTeam||d.awayTeamName||"Team B";}
function randomId(){return crypto.randomUUID?.() || (Date.now().toString(36)+Math.random().toString(36).slice(2));}

startLiveBtn.disabled=true;
stopLiveBtn.style.display="none";

loginBtn?.addEventListener("click",loginUser);
async function loginUser(){
  const e=email?.value.trim(), p=password?.value||"";
  if(!e)return setLoginStatus("❌ Email enter kijiye.","error");
  if(!p)return setLoginStatus("❌ Password enter kijiye.","error");
  loginBtn.disabled=true; setLoginStatus("⏳ Logging in...");
  try{await signInWithEmailAndPassword(auth,e,p);setLoginStatus("✅ Login successful.","live");}
  catch(err){console.error(err);setLoginStatus("❌ "+(err.code==="auth/invalid-credential"?"Email ya password galat hai.":err.message||"Login failed."),"error");}
  finally{loginBtn.disabled=false;}
}

onAuthStateChanged(auth,async user=>{
  currentUser=user;
  if(user){
    loginCard?.classList.add("hidden"); userCard?.classList.remove("hidden"); controlCard?.classList.remove("hidden"); cameraCard?.classList.remove("hidden");
    if(userEmail)userEmail.textContent=user.email||"-"; if(loginMessage)loginMessage.textContent="✅ You are logged in.";
    setLoginStatus("✅ Logged in","live"); await loadMatches();
  }else{showLoggedOut();}
});
function showLoggedOut(){loginCard?.classList.remove("hidden");userCard?.classList.add("hidden");controlCard?.classList.add("hidden");cameraCard?.classList.add("hidden");}
logoutBtn?.addEventListener("click",async()=>{await stopLive();await signOut(auth);});

async function loadMatches(){
  try{
    matchSelect.innerHTML='<option value="">⏳ Loading matches...</option>';
    const snap=await getDocs(collection(db,"tournaments",tournamentId,"matches"));
    matchSelect.innerHTML='<option value="">Select a match</option>';
    snap.forEach(s=>{const d=s.data(),o=document.createElement("option");o.value=s.id;o.textContent=`${getTeamA(d)} VS ${getTeamB(d)}`;o.dataset.teamA=getTeamA(d);o.dataset.teamB=getTeamB(d);matchSelect.appendChild(o);});
    if(snap.empty)matchSelect.innerHTML='<option value="">No matches found</option>';
  }catch(err){console.error(err);matchSelect.innerHTML='<option value="">Unable to load matches</option>';setStatus("❌ Match load error","error");}
}
matchSelect?.addEventListener("change",()=>{currentMatchId=matchSelect.value;const o=matchSelect.options[matchSelect.selectedIndex];if(!currentMatchId){matchInfo?.classList.add("hidden");return;}teamA.textContent=o.dataset.teamA||"Team A";teamB.textContent=o.dataset.teamB||"Team B";matchInfo?.classList.remove("hidden");});

startCameraBtn?.addEventListener("click",startCamera);
async function startCamera(){
  if(!currentUser)return setStatus("❌ Please login first.","error");
  if(!navigator.mediaDevices?.getUserMedia)return setStatus("❌ Camera API available nahi hai. HTTPS/localhost use kijiye.","error");
  try{
    setStatus("📷 Starting camera...");
    localStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1280},height:{ideal:720}},audio:true});
    cameraPreview.srcObject=localStream; cameraPreview.muted=true; cameraPreview.playsInline=true; cameraPreview.autoplay=true; await cameraPreview.play();
    cameraOff?.classList.add("hidden"); startCameraBtn.disabled=true; startLiveBtn.disabled=false; setStatus("📷 Camera is ready.","live");
  }catch(err){console.error(err);setStatus("❌ Camera error: "+err.message,"error");}
}

startLiveBtn?.addEventListener("click",startLive);
async function startLive(){
  if(!currentUser)return setStatus("❌ Please login first.","error");
  if(!currentMatchId)return setStatus("❌ Pehle match select kijiye.","error");
  if(!localStream)return setStatus("❌ Pehle START CAMERA dabaiye.","error");
  try{
    startLiveBtn.disabled=true; setStatus("🎥 Starting live...");
    streamRef=doc(db,"tournaments",tournamentId,"matches",currentMatchId,"stream","live");
    const viewersRef=collection(streamRef,"viewers");
    // Remove old viewer sessions so a new broadcast starts cleanly.
    const old=await getDocs(viewersRef); await Promise.all(old.docs.map(d=>deleteDoc(d.ref)));
    const sessionId=randomId();
    await setDoc(streamRef,{active:true,sessionId,tournamentId,matchId:currentMatchId,createdBy:currentUser.uid,broadcasterEmail:currentUser.email||"",createdAt:serverTimestamp()});
    listenForViewers(sessionId);
    startLiveBtn.style.display="none"; stopLiveBtn.style.display="block"; setStatus("🔴 LIVE • Waiting for viewers...","live");
  }catch(err){console.error(err);startLiveBtn.disabled=false;setStatus("❌ Start live error: "+err.message,"error");}
}

function listenForViewers(sessionId){
  viewerListenerUnsub?.();
  viewerListenerUnsub=onSnapshot(collection(streamRef,"viewers"),snap=>{
    snap.docChanges().forEach(change=>{
      const data=change.doc.data(), id=change.doc.id;
      if(data.sessionId!==sessionId || data.active===false)return;
      if(change.type==="added" || (change.type==="modified" && data.offer && !viewerPeers.has(id))) handleViewer(id,data).catch(console.error);
      if(change.type==="removed") closeViewer(id);
    });
  },err=>{console.error(err);setStatus("❌ Viewer signaling error: "+err.message,"error");});
}

async function handleViewer(viewerId,data){
  if(viewerPeers.has(viewerId))return;
  const viewerRef=doc(streamRef,"viewers",viewerId);
  const pc=new RTCPeerConnection(rtcConfig);
  const state={pc,offerUnsub:null,answerCandidateUnsub:null,remoteReady:false,pending:[]};
  viewerPeers.set(viewerId,state);
  localStream.getTracks().forEach(track=>pc.addTrack(track,localStream));
  pc.onicecandidate=async e=>{if(e.candidate)await addDoc(collection(viewerRef,"answerCandidates"),e.candidate.toJSON()).catch(console.error);};
  pc.onconnectionstatechange=()=>{
    const s=pc.connectionState; console.log("🔗 Viewer",viewerId,s);
    if(s==="connected")setStatus(`🔴 LIVE • ${viewerPeers.size} viewer${viewerPeers.size>1?"s":""}`,"live");
    if(s==="failed"||s==="closed")closeViewer(viewerId);
  };
  state.offerUnsub=onSnapshot(collection(viewerRef,"offerCandidates"),async snap=>{
    for(const c of snap.docChanges())if(c.type==="added"){const cand=new RTCIceCandidate(c.doc.data());if(state.remoteReady){try{await pc.addIceCandidate(cand);}catch(e){console.warn(e);}}else state.pending.push(cand);}
  });
  state.answerCandidateUnsub=()=>{};
  try{
    await pc.setRemoteDescription(new RTCSessionDescription(data.offer)); state.remoteReady=true;
    for(const c of state.pending)await pc.addIceCandidate(c).catch(()=>{}); state.pending=[];
    const answer=await pc.createAnswer(); await pc.setLocalDescription(answer);
    await setDoc(viewerRef,{answer:{type:answer.type,sdp:answer.sdp},active:true,sessionId,answeredAt:serverTimestamp()},{merge:true});
  }catch(err){console.error("Viewer setup",err);closeViewer(viewerId);}
}
function closeViewer(id){const s=viewerPeers.get(id);if(!s)return;s.offerUnsub?.();s.answerCandidateUnsub?.();try{s.pc.close();}catch{}viewerPeers.delete(id);}

stopLiveBtn?.addEventListener("click",stopLive);
async function stopLive(){
  viewerListenerUnsub?.(); viewerListenerUnsub=null;
  for(const id of [...viewerPeers.keys()])closeViewer(id);
  if(localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null;}
  if(streamRef){try{const viewers=await getDocs(collection(streamRef,"viewers"));await Promise.all(viewers.docs.map(d=>deleteDoc(d.ref)));await updateDoc(streamRef,{active:false,stoppedAt:serverTimestamp()});}catch(e){console.warn(e);} }
  streamRef=null; cameraPreview.srcObject=null; cameraOff?.classList.remove("hidden"); startCameraBtn.disabled=false; startLiveBtn.style.display="block"; startLiveBtn.disabled=true; stopLiveBtn.style.display="none"; setStatus("Camera is not started");
}
watchLiveBtn?.addEventListener("click",e=>{e.preventDefault();if(!currentMatchId)return setStatus("❌ Pehle match select kijiye.","error");location.href=`./watch-live.html?tournamentId=${encodeURIComponent(tournamentId)}&matchId=${encodeURIComponent(currentMatchId)}`;});
window.addEventListener("beforeunload",()=>{localStream?.getTracks().forEach(t=>t.stop());viewerPeers.forEach(v=>{try{v.pc.close()}catch{}});});
console.log("🚀 CRICKMATE LIVE CAMERA V2 READY");
