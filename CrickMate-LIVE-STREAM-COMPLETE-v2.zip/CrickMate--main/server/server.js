// =====================================================
// CRICKMATE STREAMING SERVER
// PART 2 - SERVER
// =====================================================

import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();

const PORT = process.env.PORT || 3000;

// =====================================================
// MIDDLEWARE
// =====================================================

app.use(
    cors({
        origin: "*",
        methods: ["GET", "POST", "OPTIONS"],
        allowedHeaders: ["Content-Type", "Authorization"]
    })
);

app.use(express.json());

// =====================================================
// SERVER INFO
// =====================================================

app.get("/", (req, res) => {

    res.json({
        success: true,
        service: "CrickMate Streaming Server",
        status: "online",
        version: "1.0.0"
    });

});

// =====================================================
// HEALTH CHECK
// =====================================================

app.get("/health", (req, res) => {

    res.json({
        success: true,
        status: "healthy",
        timestamp: new Date().toISOString()
    });

});

// =====================================================
// STREAM STATUS
// =====================================================

let streamStatus = {

    active: false,

    tournamentId: null,

    matchId: null,

    startedAt: null

};

// =====================================================
// GET STREAM STATUS
// =====================================================

app.get("/api/stream/status", (req, res) => {

    res.json({
        success: true,
        stream: streamStatus
    });

});

// =====================================================
// START STREAM
// =====================================================

app.post("/api/stream/start", (req, res) => {

    const {
        tournamentId,
        matchId
    } = req.body || {};

    if (!tournamentId) {

        return res.status(400).json({

            success: false,

            error: "Tournament ID is required."

        });

    }

    if (!matchId) {

        return res.status(400).json({

            success: false,

            error: "Match ID is required."

        });

    }

    streamStatus = {

        active: true,

        tournamentId,

        matchId,

        startedAt: new Date().toISOString()

    };

    console.log(
        "🔴 CRICKMATE STREAM STARTED"
    );

    console.log(
        "🏆 Tournament:",
        tournamentId
    );

    console.log(
        "🏏 Match:",
        matchId
    );

    res.json({

        success: true,

        message: "Stream session started.",

        stream: streamStatus

    });

});

// =====================================================
// STOP STREAM
// =====================================================

app.post("/api/stream/stop", (req, res) => {

    streamStatus = {

        active: false,

        tournamentId: null,

        matchId: null,

        startedAt: null

    };

    console.log(
        "⛔ CRICKMATE STREAM STOPPED"
    );

    res.json({

        success: true,

        message: "Stream session stopped."

    });

});

// =====================================================
// 404
// =====================================================

app.use((req, res) => {

    res.status(404).json({

        success: false,

        error: "API endpoint not found."

    });

});

// =====================================================
// ERROR HANDLER
// =====================================================

app.use((error, req, res, next) => {

    console.error(
        "❌ SERVER ERROR:",
        error
    );

    res.status(500).json({

        success: false,

        error: "Internal server error."

    });

});

// =====================================================
// START SERVER
// =====================================================

app.listen(
    PORT,
    () => {

        console.log(
            "================================="
        );

        console.log(
            "🔥 CRICKMATE STREAMING SERVER"
        );

        console.log(
            "================================="
        );

        console.log(
            `🚀 Server running on port ${PORT}`
        );

        console.log(
            `🌐 http://localhost:${PORT}`
        );

        console.log(
            "================================="
        );

    }
);